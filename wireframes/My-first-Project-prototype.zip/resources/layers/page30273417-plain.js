rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page30273417-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page30273417" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page30273417-layer-image536120567" style="position: absolute; left: 0px; top: 0px; width: 1365px; height: 768px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image536120567" data-review-reference-id="image536120567">\
            <div class="stencil-wrapper" style="width: 1365px; height: 768px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 768px;width:1365px;" width="1365" height="768" viewBox="0 0 1365 768">\
                     <svg:g width="1365" height="768">\
                        <svg:rect x="0" y="0" width="1365" height="768" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="1365" y2="768" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="768" x2="1365" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page30273417-layer-text704560720" style="position: absolute; left: 295px; top: 260px; width: 754px; height: 112px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text704560720" data-review-reference-id="text704560720">\
            <div class="stencil-wrapper" style="width: 754px; height: 112px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p style="text-align: center;"><span style="font-size: 32px;">Welcome to the Official Media Body of NIT Rourkela <br /><br\
                        />Monday Morning</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page30273417-layer-iphoneButton659516054" style="position: absolute; left: 485px; top: 465px; width: 375px; height: 70px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton659516054" data-review-reference-id="iphoneButton659516054">\
            <div class="stencil-wrapper" style="width: 375px; height: 70px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 70px;width:375px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="375" height="70" viewBox="0 0 375 70">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,69.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-60 0.5,-2 1,-1 1,-1 2,-0.5 365,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,60 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="187.5" y="35" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Enlighten</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 375px; height: 70px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page30273417-layer-iphoneButton659516054\', \'interaction553589109\', {"button":"left","id":"action453740607","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction806970735","target":null,"type":"showOverlay"}\
					]\
				);\
			});\
		</script><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page30273417-layer-iphoneButton659516054\', \'762312835\', {"button":"left","id":"458150524","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction845321022","options":"reloadOnly","target":"page353048828","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page30273417"] .border-wrapper, body[data-current-page-id="page30273417"] .simulation-container{\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page30273417"] .border-wrapper, body.has-frame[data-current-page-id="page30273417"]\
         .simulation-container{\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="page30273417"] .svg-border-1366-768{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page30273417"] .border-wrapper .border-div{\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page30273417",\
      			"name": "landing",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');