rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page331142030-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page331142030" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page331142030-layer-rect738176241" style="position: absolute; left: 125px; top: 75px; width: 335px; height: 440px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect738176241" data-review-reference-id="rect738176241">\
            <div class="stencil-wrapper" style="width: 335px; height: 440px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 440px;width:335px;" width="335" height="440">\
                     <svg:g width="335" height="440"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.34, 1.26, 22.69, 1.56 Q 33.03, 1.59, 43.38, 2.00 Q 53.72, 2.02,\
                        64.06, 2.11 Q 74.41, 1.93, 84.75, 2.63 Q 95.09, 1.41, 105.44, 2.21 Q 115.78, 2.31, 126.12, 2.54 Q 136.47, 2.73, 146.81, 1.73\
                        Q 157.16, 2.68, 167.50, 2.48 Q 177.84, 1.91, 188.19, 0.94 Q 198.53, 1.70, 208.88, 2.20 Q 219.22, 2.67, 229.56, 2.86 Q 239.91,\
                        2.67, 250.25, 2.35 Q 260.59, 2.02, 270.94, 3.41 Q 281.28, 1.80, 291.62, 1.22 Q 301.97, 1.48, 312.31, 1.66 Q 322.66, 1.22,\
                        333.27, 1.73 Q 333.24, 12.30, 333.14, 22.74 Q 333.73, 33.09, 333.84, 43.50 Q 333.03, 53.90, 333.10, 64.28 Q 333.91, 74.66,\
                        334.04, 85.05 Q 333.89, 95.43, 333.88, 105.81 Q 333.55, 116.19, 332.89, 126.57 Q 333.54, 136.95, 333.35, 147.33 Q 333.31,\
                        157.71, 334.20, 168.10 Q 334.15, 178.48, 334.70, 188.86 Q 334.20, 199.24, 332.58, 209.62 Q 333.04, 220.00, 334.37, 230.38\
                        Q 334.23, 240.76, 333.90, 251.14 Q 334.03, 261.52, 334.53, 271.90 Q 334.87, 282.29, 334.78, 292.67 Q 334.80, 303.05, 335.00,\
                        313.43 Q 335.14, 323.81, 335.12, 334.19 Q 334.67, 344.57, 334.81, 354.95 Q 334.84, 365.33, 334.60, 375.71 Q 334.45, 386.10,\
                        335.06, 396.48 Q 334.83, 406.86, 334.25, 417.24 Q 332.74, 427.62, 332.76, 437.76 Q 322.64, 437.96, 312.37, 438.41 Q 302.03,\
                        438.87, 291.68, 439.85 Q 281.31, 439.56, 270.95, 439.31 Q 260.60, 439.30, 250.25, 439.17 Q 239.91, 439.20, 229.56, 439.25\
                        Q 219.22, 439.42, 208.88, 438.77 Q 198.53, 437.91, 188.19, 437.85 Q 177.84, 438.48, 167.50, 438.85 Q 157.16, 439.70, 146.81,\
                        439.59 Q 136.47, 438.90, 126.12, 439.67 Q 115.78, 439.85, 105.44, 439.56 Q 95.09, 439.37, 84.75, 439.11 Q 74.41, 439.25, 64.06,\
                        440.20 Q 53.72, 439.84, 43.38, 439.99 Q 33.03, 439.25, 22.69, 438.02 Q 12.34, 436.91, 2.34, 437.66 Q 2.24, 427.54, 1.44, 417.32\
                        Q 0.62, 406.95, 1.07, 396.51 Q 0.81, 386.11, 1.60, 375.72 Q 1.57, 365.33, 1.98, 354.95 Q 1.79, 344.57, 0.93, 334.19 Q 0.86,\
                        323.81, 0.41, 313.43 Q 0.52, 303.05, 0.42, 292.67 Q 0.58, 282.29, 0.59, 271.90 Q 1.02, 261.52, 0.82, 251.14 Q 0.97, 240.76,\
                        0.08, 230.38 Q 0.06, 220.00, 0.15, 209.62 Q -0.04, 199.24, 0.92, 188.86 Q 1.04, 178.48, 0.82, 168.10 Q 0.55, 157.71, 0.58,\
                        147.33 Q 1.10, 136.95, 1.19, 126.57 Q 1.63, 116.19, 1.65, 105.81 Q 1.67, 95.43, 0.74, 85.05 Q 0.77, 74.67, 0.84, 64.29 Q 0.91,\
                        53.90, 0.69, 43.52 Q 0.54, 33.14, 1.35, 22.76 Q 2.00, 12.38, 2.00, 2.00" style=" fill:white;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-724618498" style="position: absolute; left: 795px; top: 75px; width: 335px; height: 440px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="724618498" data-review-reference-id="724618498">\
            <div class="stencil-wrapper" style="width: 335px; height: 440px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 440px;width:335px;" width="335" height="440">\
                     <svg:g width="335" height="440"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.34, -0.45, 22.69, -0.46 Q 33.03, -0.00, 43.38, 0.30 Q 53.72,\
                        0.75, 64.06, 1.27 Q 74.41, 1.92, 84.75, 1.47 Q 95.09, 1.01, 105.44, 1.25 Q 115.78, 1.40, 126.12, 1.80 Q 136.47, 1.52, 146.81,\
                        3.37 Q 157.16, 3.03, 167.50, 1.96 Q 177.84, 1.18, 188.19, 1.57 Q 198.53, 2.12, 208.88, 2.08 Q 219.22, 2.05, 229.56, 1.86 Q\
                        239.91, 2.58, 250.25, 2.23 Q 260.59, 2.24, 270.94, 0.98 Q 281.28, 2.04, 291.62, 2.56 Q 301.97, 2.26, 312.31, 2.14 Q 322.66,\
                        1.17, 333.33, 1.67 Q 333.49, 12.22, 334.44, 22.56 Q 335.07, 33.00, 334.54, 43.47 Q 334.04, 53.89, 334.21, 64.28 Q 334.02,\
                        74.66, 334.39, 85.04 Q 334.45, 95.43, 334.58, 105.81 Q 333.47, 116.19, 334.20, 126.57 Q 333.87, 136.95, 333.42, 147.33 Q 334.07,\
                        157.71, 334.47, 168.10 Q 334.32, 178.48, 333.41, 188.86 Q 333.19, 199.24, 334.55, 209.62 Q 334.60, 220.00, 333.50, 230.38\
                        Q 332.58, 240.76, 333.40, 251.14 Q 333.26, 261.52, 333.24, 271.90 Q 332.41, 282.29, 332.68, 292.67 Q 332.66, 303.05, 333.33,\
                        313.43 Q 334.33, 323.81, 334.53, 334.19 Q 334.89, 344.57, 334.56, 354.95 Q 334.90, 365.33, 335.06, 375.71 Q 335.07, 386.10,\
                        335.21, 396.48 Q 335.23, 406.86, 334.23, 417.24 Q 334.72, 427.62, 333.70, 438.70 Q 323.05, 439.18, 312.52, 439.42 Q 302.06,\
                        439.37, 291.64, 438.40 Q 281.29, 438.38, 270.94, 438.69 Q 260.60, 439.05, 250.25, 439.15 Q 239.91, 439.55, 229.56, 439.38\
                        Q 219.22, 438.25, 208.87, 437.55 Q 198.53, 437.99, 188.19, 438.18 Q 177.84, 438.38, 167.50, 438.50 Q 157.16, 439.00, 146.81,\
                        438.90 Q 136.47, 439.78, 126.12, 439.62 Q 115.78, 439.70, 105.44, 439.24 Q 95.09, 439.22, 84.75, 439.36 Q 74.41, 438.64, 64.06,\
                        439.25 Q 53.72, 438.95, 43.38, 438.76 Q 33.03, 439.94, 22.69, 440.24 Q 12.34, 440.25, 0.83, 439.17 Q 0.22, 428.21, 1.30, 417.34\
                        Q 1.55, 406.89, 1.37, 396.50 Q 0.51, 386.12, 0.36, 375.73 Q 0.64, 365.34, 0.82, 354.95 Q 0.63, 344.57, 0.84, 334.19 Q 2.02,\
                        323.81, 1.69, 313.43 Q 1.33, 303.05, 1.06, 292.67 Q 1.14, 282.29, 1.50, 271.90 Q 1.78, 261.52, 2.26, 251.14 Q 0.93, 240.76,\
                        1.33, 230.38 Q 1.03, 220.00, 0.92, 209.62 Q 0.58, 199.24, 0.13, 188.86 Q 0.37, 178.48, 0.98, 168.10 Q 0.69, 157.71, 0.47,\
                        147.33 Q 0.39, 136.95, 0.26, 126.57 Q 0.25, 116.19, 0.23, 105.81 Q 0.43, 95.43, 0.32, 85.05 Q 0.27, 74.67, 0.21, 64.29 Q 0.42,\
                        53.90, 1.39, 43.52 Q 1.06, 33.14, 1.34, 22.76 Q 2.00, 12.38, 2.00, 2.00" style=" fill:white;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-icon416546166" style="position: absolute; left: 585px; top: 220px; width: 64px; height: 64px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon416546166" data-review-reference-id="icon416546166">\
            <div class="stencil-wrapper" style="width: 64px; height: 64px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:64px;height:64px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e191" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e191</title>\
<path class="path1" d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM277.357 531.417q0 6.99 4.926 11.756t11.915 4.846h150.92v152.907q0 6.911 4.846 11.915t11.756 4.926h100.559q6.99 0 11.915-4.926t5.004-11.915v-152.907h150.601q6.911 0 11.915-4.846t4.926-11.756v-100.559q0-6.99-4.926-11.756t-11.915-4.846h-150.601v-150.92q0-6.911-5.004-11.915t-11.915-4.926h-100.559q-6.99 0-11.756 4.926t-4.846 11.915v150.92h-150.92q-6.911 0-11.915 4.846t-4.926 11.756v100.559z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e368" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e368</title>\
<path class="path1" d="M181.008 679.716v-364.035q0-54.969 38.921-93.729t93.491-38.682h364.035q54.969 0 93.729 38.682t38.682 93.729v364.035q0 54.969-38.682 93.65t-93.729 38.762h-364.035q-54.57 0-93.491-38.762t-38.921-93.65zM247.255 712.839q0 13.583 9.77 23.273t23.273 9.77h430.281q13.583 0 23.353-9.77t9.77-23.273v-430.281q0-13.583-9.77-23.353t-23.353-9.77h-430.281q-13.502 0-23.273 9.77t-9.77 23.353v430.281zM345.513 425.852q4.291-10.883 17.554-10.883h264.745q13.264 0 17.554 11.36t-3.972 22.4l-126.375 175.384q-7.944 10.961-19.539 11.756t-19.539-10.089l-126.455-178.086q-8.262-10.883-3.972-21.844z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path class="path1" d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e046" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e046</title>\
<path class="path1" d="M114.842 845.172v-529.492h761.193v529.492q0 13.583-9.77 23.353t-23.273 9.77h-695.028q-13.583 0-23.353-9.77t-9.77-23.353zM114.842 282.557v-99.289q0-13.583 9.77-23.353t23.353-9.77h66.167v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.044q13.583 0 23.353 9.77t9.77 23.353v33.044h364.035v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.124q13.583 0 23.273 9.77t9.77 23.353v33.044h66.246q13.583 0 23.273 9.77t9.77 23.353v99.289h-761.193zM181.008 812.128h99.289v-99.289h-99.289v99.289zM181.008 679.716h99.289v-99.289h-99.289v99.289zM181.008 547.303h99.289v-99.289h-99.289v99.289zM313.421 812.128h99.289v-99.289h-99.289v99.289zM313.421 679.716h99.289v-99.289h-99.289v99.289zM313.421 547.303h99.289v-99.289h-99.289v99.289zM445.833 812.128h99.289v-99.289h-99.289v99.289zM445.833 679.716h99.289v-99.289h-99.289v99.289zM445.833 547.303h99.289v-99.289h-99.289v99.289zM578.167 812.128h99.289v-99.289h-99.289v99.289zM578.167 679.716h99.289v-99.289h-99.289v99.289zM578.167 547.303h99.289v-99.289h-99.289v99.289zM710.579 812.128h99.289v-99.289h-99.289v99.289zM710.579 679.716h99.289v-99.289h-99.289v99.289zM710.579 547.303h99.289v-99.289h-99.289v99.289z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e212" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e212</title>\
<path class="path1" d="M181.008 563.586v-164.821q0-6.674 5.163-11.756t11.756-5.163h280.95v-171.413q0-6.99 3.972-8.817t9.294 2.463l345.208 266.812q5.639 4.291 5.639 10.247t-5.639 10.247l-344.893 267.129q-5.639 3.972-9.612 2.145t-3.972-8.817v-171.413h-280.95q-6.592 0-11.756-5.164t-5.163-11.677z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e212-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e212"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-text841539962" style="position: absolute; left: 265px; top: 90px; width: 59px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text841539962" data-review-reference-id="text841539962">\
            <div class="stencil-wrapper" style="width: 59px; height: 37px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Poll<br /></span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-359278996" style="position: absolute; left: 870px; top: 90px; width: 187px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="359278996" data-review-reference-id="359278996">\
            <div class="stencil-wrapper" style="width: 187px; height: 37px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Poll Analysis<br /></span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-text576882179" style="position: absolute; left: 160px; top: 165px; width: 148px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text576882179" data-review-reference-id="text576882179">\
            <div class="stencil-wrapper" style="width: 148px; height: 20px">\
               <div title="" style="width:153px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span class="bold" style="font-size: 18px;">Question of poll </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-radiobutton499775967" style="position: absolute; left: 180px; top: 250px; width: 81px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton499775967" data-review-reference-id="radiobutton499775967">\
            <div class="stencil-wrapper" style="width: 81px; height: 20px">\
               <div class="">\
                  <div style="font-size:1.17em;" xml:space="preserve" title="" class="label" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton499775967_input\');">\
                     				\
                     				<input id="__containerId__-page331142030-layer-radiobutton499775967_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" name="group1" value="__containerId__-page331142030-layer-radiobutton499775967" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page331142030-layer-radiobutton499775967_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page331142030-layer-radiobutton499775967_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-page331142030-layer-radiobutton499775967_input\', \'__containerId__-page331142030-layer-radiobutton499775967_input_svgChecked\');" />\
                     				\
                     				\
                     				\
                     					+1 option\
                     					\
                     				\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:81px;cursor: pointer;" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton499775967_input\');">\
                        <svg:g id="__containerId__-page331142030-layer-radiobutton499775967_input_svg" x="0" y="1.0199999999999996" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton499775967_input\');"><svg:path id="__containerId__-page331142030-layer-radiobutton499775967_input_svg_border" class=" svg_unselected_element" d="M\
                           17.00, 10.00 Q 18.80, 10.73, 16.76, 14.34 Q 13.08, 16.43, 8.96, 16.29 Q 5.59, 13.94, 4.88, 9.91 Q 5.73, 6.13, 9.00, 3.74 Q\
                           13.07, 3.74, 16.45, 6.05 Q 17.00, 10.10, 15.79, 13.61" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-page331142030-layer-radiobutton499775967_input_svgChecked" x="0" y="1.0199999999999996" width="81" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton499775967_input\');" visibility="hidden"><svg:path class=" svg_unselected_element" d="M 13.00, 10.00 Q 13.82, 10.32, 13.38, 11.79 Q 11.75, 12.27, 10.28, 12.34 Q 9.23,\
                           11.28, 8.94, 9.97 Q 9.04, 8.60, 10.31, 7.86 Q 11.69, 7.90, 12.56, 8.93 Q 13.00, 10.03, 12.60, 11.20" style=""/>\
                        </svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-radiobutton918403260" style="position: absolute; left: 180px; top: 330px; width: 73px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton918403260" data-review-reference-id="radiobutton918403260">\
            <div class="stencil-wrapper" style="width: 73px; height: 20px">\
               <div class="">\
                  <div style="font-size:1.17em;" xml:space="preserve" title="" class="label" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton918403260_input\');">\
                     				\
                     				<input id="__containerId__-page331142030-layer-radiobutton918403260_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" name="group1" value="__containerId__-page331142030-layer-radiobutton918403260" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page331142030-layer-radiobutton918403260_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page331142030-layer-radiobutton918403260_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-page331142030-layer-radiobutton918403260_input\', \'__containerId__-page331142030-layer-radiobutton918403260_input_svgChecked\');" />\
                     				\
                     				\
                     				\
                     					0 option\
                     					\
                     				\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:73px;cursor: pointer;" width="73" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton918403260_input\');">\
                        <svg:g id="__containerId__-page331142030-layer-radiobutton918403260_input_svg" x="0" y="1.0199999999999996" width="73" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton918403260_input\');"><svg:path id="__containerId__-page331142030-layer-radiobutton918403260_input_svg_border" class=" svg_unselected_element" d="M\
                           17.00, 10.00 Q 17.57, 10.30, 15.99, 13.76 Q 12.83, 15.91, 9.00, 16.02 Q 5.75, 13.78, 4.41, 9.98 Q 5.69, 6.11, 8.84, 3.41 Q\
                           13.14, 3.37, 16.50, 6.01 Q 17.00, 10.10, 15.79, 13.61" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-page331142030-layer-radiobutton918403260_input_svgChecked" x="0" y="1.0199999999999996" width="73" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton918403260_input\');" visibility="hidden"><svg:path class=" svg_unselected_element" d="M 13.00, 10.00 Q 13.25, 10.12, 13.06, 11.55 Q 11.97, 12.73, 10.12, 13.44 Q 8.43,\
                           12.09, 7.43, 10.20 Q 8.02, 8.05, 9.70, 6.58 Q 11.98, 6.38, 13.42, 8.12 Q 13.00, 10.03, 12.60, 11.20" style=""/>\
                        </svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-radiobutton812686936" style="position: absolute; left: 180px; top: 405px; width: 77px; height: 20px" data-interactive-element-type="default.radiobutton" class="radiobutton stencil mobile-interaction-potential-trigger " data-stencil-id="radiobutton812686936" data-review-reference-id="radiobutton812686936">\
            <div class="stencil-wrapper" style="width: 77px; height: 20px">\
               <div class="">\
                  <div style="font-size:1.17em;" xml:space="preserve" title="" class="label" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton812686936_input\');">\
                     				\
                     				<input id="__containerId__-page331142030-layer-radiobutton812686936_input" xml:space="default" type="radio" style="padding-right:8px" class="hidden_class" name="group1" value="__containerId__-page331142030-layer-radiobutton812686936" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-page331142030-layer-radiobutton812686936_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-page331142030-layer-radiobutton812686936_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.radioButtonClicked, \'__containerId__-page331142030-layer-radiobutton812686936_input\', \'__containerId__-page331142030-layer-radiobutton812686936_input_svgChecked\');" />\
                     				\
                     				\
                     				\
                     					-1 option\
                     					\
                     				\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute;  top: 1.0199999999999996px; height: 20px;width:77px;cursor: pointer;" width="77" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton812686936_input\');">\
                        <svg:g id="__containerId__-page331142030-layer-radiobutton812686936_input_svg" x="0" y="1.0199999999999996" width="77" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton812686936_input\');"><svg:path id="__containerId__-page331142030-layer-radiobutton812686936_input_svg_border" class=" svg_unselected_element" d="M\
                           17.00, 10.00 Q 18.70, 10.69, 17.18, 14.66 Q 13.29, 16.86, 8.93, 16.44 Q 5.74, 13.79, 4.29, 10.00 Q 5.74, 6.14, 8.95, 3.63\
                           Q 13.06, 3.75, 16.31, 6.19 Q 17.00, 10.10, 15.79, 13.61" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-page331142030-layer-radiobutton812686936_input_svgChecked" x="0" y="1.0199999999999996" width="77" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-page331142030-layer-radiobutton812686936_input\');" visibility="hidden"><svg:path class=" svg_unselected_element" d="M 13.00, 10.00 Q 13.56, 10.23, 12.91, 11.44 Q 11.72, 12.19, 10.32, 12.09 Q 9.21,\
                           11.30, 8.35, 10.06 Q 9.00, 8.58, 10.33, 7.91 Q 11.67, 8.01, 12.30, 9.17 Q 13.00, 10.03, 12.60, 11.20" style=""/>\
                        </svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-group448296371" style="position: absolute; left: 835px; top: 250px; width: 265px; height: 50px" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group448296371" data-review-reference-id="group448296371">\
            <div class="stencil-wrapper" style="width: 265px; height: 50px">\
               <div id="group448296371-rect60974309" style="position: absolute; left: 0px; top: 0px; width: 205px; height: 50px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect60974309" data-review-reference-id="rect60974309">\
                  <div class="stencil-wrapper" style="width: 205px; height: 50px">\
                     <div title="">\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 50px;width:205px;" width="205" height="50">\
                           <svg:g width="205" height="50"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.05, 2.60, 22.10, 1.70 Q 32.15, 1.04, 42.20, 0.53 Q 52.25, 1.66,\
                              62.30, 0.96 Q 72.35, 0.59, 82.40, 1.01 Q 92.45, 1.58, 102.50, 2.41 Q 112.55, 2.65, 122.60, 1.48 Q 132.65, 1.68, 142.70, 0.44\
                              Q 152.75, 1.35, 162.80, 1.22 Q 172.85, 1.21, 182.90, 1.37 Q 192.95, 1.03, 203.30, 1.70 Q 203.55, 13.32, 204.06, 24.85 Q 204.37,\
                              36.41, 203.68, 48.68 Q 193.23, 48.88, 183.01, 48.79 Q 172.92, 49.08, 162.85, 49.77 Q 152.78, 49.80, 142.70, 48.34 Q 132.65,\
                              47.71, 122.60, 48.92 Q 112.55, 49.12, 102.50, 49.48 Q 92.45, 49.08, 82.40, 49.51 Q 72.35, 49.23, 62.30, 50.07 Q 52.25, 50.05,\
                              42.20, 49.90 Q 32.15, 49.96, 22.10, 49.99 Q 12.05, 50.06, 0.92, 49.08 Q 0.32, 37.06, 1.13, 25.12 Q 2.00, 13.50, 2.00, 2.00"\
                              style=" fill:white;"/>\
                           </svg:g>\
                        </svg:svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group448296371-rect491319622" style="position: absolute; left: 205px; top: 0px; width: 60px; height: 50px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect491319622" data-review-reference-id="rect491319622">\
                  <div class="stencil-wrapper" style="width: 60px; height: 50px">\
                     <div title="">\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 50px;width:60px;" width="60" height="50">\
                           <svg:g width="60" height="50"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 16.00, 1.18, 30.00, 0.81 Q 44.00, 0.59, 58.82, 1.18 Q 59.29, 13.07,\
                              59.14, 24.84 Q 59.37, 36.41, 58.70, 48.70 Q 44.40, 49.25, 30.21, 49.55 Q 16.06, 48.98, 1.55, 48.44 Q 1.19, 36.76, 0.89, 25.15\
                              Q 2.00, 13.50, 2.00, 2.00" style=" fill:white;"/>\
                           </svg:g>\
                        </svg:svg>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-text439398723" style="position: absolute; left: 875px; top: 265px; width: 84px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text439398723" data-review-reference-id="text439398723">\
            <div class="stencil-wrapper" style="width: 84px; height: 20px">\
               <div title="" style="width:89px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">+1 Option</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-text571850579" style="position: absolute; left: 1070px; top: 265px; width: 22px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text571850579" data-review-reference-id="text571850579">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div title="" style="width:27px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">%</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-1080379874" style="position: absolute; left: 835px; top: 340px; width: 265px; height: 50px" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="1080379874" data-review-reference-id="1080379874">\
            <div class="stencil-wrapper" style="width: 265px; height: 50px">\
               <div id="1080379874-1899605446" style="position: absolute; left: 0px; top: 0px; width: 205px; height: 50px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="1899605446" data-review-reference-id="1899605446">\
                  <div class="stencil-wrapper" style="width: 205px; height: 50px">\
                     <div title="">\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 50px;width:205px;" width="205" height="50">\
                           <svg:g width="205" height="50"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.05, -0.68, 22.10, -0.68 Q 32.15, -0.30, 42.20, 0.05 Q 52.25,\
                              0.16, 62.30, 0.12 Q 72.35, 0.57, 82.40, 0.46 Q 92.45, 0.60, 102.50, 0.46 Q 112.55, 0.38, 122.60, 0.72 Q 132.65, 1.18, 142.70,\
                              1.43 Q 152.75, 1.40, 162.80, 1.09 Q 172.85, 1.16, 182.90, 1.27 Q 192.95, 1.23, 203.46, 1.54 Q 203.90, 13.20, 204.16, 24.83\
                              Q 204.13, 36.42, 203.62, 48.62 Q 193.27, 48.99, 183.04, 49.02 Q 172.93, 49.29, 162.84, 49.20 Q 152.77, 49.37, 142.71, 49.40\
                              Q 132.65, 49.33, 122.60, 49.24 Q 112.55, 49.34, 102.50, 49.52 Q 92.45, 49.42, 82.40, 50.13 Q 72.35, 50.39, 62.30, 50.47 Q\
                              52.25, 50.44, 42.20, 49.77 Q 32.15, 49.87, 22.10, 49.05 Q 12.05, 48.89, 1.48, 48.52 Q 1.20, 36.77, 1.14, 25.12 Q 2.00, 13.50,\
                              2.00, 2.00" style=" fill:white;"/>\
                           </svg:g>\
                        </svg:svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="1080379874-1984660606" style="position: absolute; left: 205px; top: 0px; width: 60px; height: 50px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="1984660606" data-review-reference-id="1984660606">\
                  <div class="stencil-wrapper" style="width: 60px; height: 50px">\
                     <div title="">\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 50px;width:60px;" width="60" height="50">\
                           <svg:g width="60" height="50"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 16.00, 3.18, 30.00, 2.04 Q 44.00, 1.39, 58.52, 1.48 Q 58.80, 13.23,\
                              58.84, 24.88 Q 58.68, 36.45, 58.34, 48.34 Q 44.26, 48.80, 30.13, 48.98 Q 16.04, 48.62, 1.56, 48.44 Q 1.43, 36.68, 1.45, 25.07\
                              Q 2.00, 13.50, 2.00, 2.00" style=" fill:white;"/>\
                           </svg:g>\
                        </svg:svg>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-74219004" style="position: absolute; left: 875px; top: 355px; width: 84px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="74219004" data-review-reference-id="74219004">\
            <div class="stencil-wrapper" style="width: 84px; height: 20px">\
               <div title="" style="width:89px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">+1 Option</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-310323964" style="position: absolute; left: 1070px; top: 440px; width: 22px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="310323964" data-review-reference-id="310323964">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div title="" style="width:27px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">%</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-1672504887" style="position: absolute; left: 875px; top: 440px; width: 84px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1672504887" data-review-reference-id="1672504887">\
            <div class="stencil-wrapper" style="width: 84px; height: 20px">\
               <div title="" style="width:89px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">+1 Option</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-773599819" style="position: absolute; left: 835px; top: 425px; width: 265px; height: 50px" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="773599819" data-review-reference-id="773599819">\
            <div class="stencil-wrapper" style="width: 265px; height: 50px">\
               <div id="773599819-1617085105" style="position: absolute; left: 0px; top: 0px; width: 205px; height: 50px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="1617085105" data-review-reference-id="1617085105">\
                  <div class="stencil-wrapper" style="width: 205px; height: 50px">\
                     <div title="">\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 50px;width:205px;" width="205" height="50">\
                           <svg:g width="205" height="50"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.05, 1.25, 22.10, 1.36 Q 32.15, 2.19, 42.20, 1.84 Q 52.25, 3.18,\
                              62.30, 1.90 Q 72.35, 1.67, 82.40, 1.76 Q 92.45, 2.56, 102.50, 3.45 Q 112.55, 2.40, 122.60, 1.05 Q 132.65, 0.90, 142.70, 1.27\
                              Q 152.75, 1.53, 162.80, 2.63 Q 172.85, 3.20, 182.90, 2.76 Q 192.95, 3.00, 202.60, 2.40 Q 203.00, 13.50, 204.02, 24.85 Q 204.84,\
                              36.38, 204.05, 49.05 Q 193.34, 49.23, 183.15, 49.86 Q 172.97, 49.85, 162.86, 50.05 Q 152.78, 50.26, 142.72, 50.32 Q 132.66,\
                              50.14, 122.60, 48.08 Q 112.55, 47.68, 102.50, 47.66 Q 92.45, 48.07, 82.40, 48.49 Q 72.35, 48.59, 62.30, 48.64 Q 52.25, 48.52,\
                              42.20, 49.10 Q 32.15, 48.62, 22.10, 49.30 Q 12.05, 49.65, 1.24, 48.76 Q 0.78, 36.91, 0.58, 25.20 Q 2.00, 13.50, 2.00, 2.00"\
                              style=" fill:white;"/>\
                           </svg:g>\
                        </svg:svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="773599819-173544775" style="position: absolute; left: 205px; top: 0px; width: 60px; height: 50px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="173544775" data-review-reference-id="173544775">\
                  <div class="stencil-wrapper" style="width: 60px; height: 50px">\
                     <div title="">\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 50px;width:60px;" width="60" height="50">\
                           <svg:g width="60" height="50"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 16.00, 1.76, 30.00, 1.62 Q 44.00, 1.61, 58.26, 1.74 Q 58.36, 13.38,\
                              58.24, 24.97 Q 58.70, 36.45, 58.11, 48.11 Q 44.09, 48.28, 30.07, 48.49 Q 16.05, 48.86, 1.83, 48.17 Q 1.31, 36.72, 1.14, 25.12\
                              Q 2.00, 13.50, 2.00, 2.00" style=" fill:white;"/>\
                           </svg:g>\
                        </svg:svg>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-text910221000" style="position: absolute; left: 1065px; top: 355px; width: 22px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text910221000" data-review-reference-id="text910221000">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div title="" style="width:27px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">%</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-text313980359" style="position: absolute; left: 870px; top: 440px; width: 85px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text313980359" data-review-reference-id="text313980359">\
            <div class="stencil-wrapper" style="width: 85px; height: 20px">\
               <div title="" style="width:90px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">-1 Option </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-text595960745" style="position: absolute; left: 1065px; top: 440px; width: 22px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text595960745" data-review-reference-id="text595960745">\
            <div class="stencil-wrapper" style="width: 22px; height: 20px">\
               <div title="" style="width:27px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">%</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page331142030-layer-iphoneButton151831124" style="position: absolute; left: 180px; top: 450px; width: 50px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton151831124" data-review-reference-id="iphoneButton151831124">\
            <div class="stencil-wrapper" style="width: 50px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:54px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="54" height="34" viewBox="-2 -2 54 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 3.48, 27.54, 2.22, 27.78 Q 1.31, 27.13, 0.14, 26.27 Q 0.16, 14.12,\
                        -0.41, 1.76 Q -0.22, 0.43, 0.32, -1.49 Q 1.79, -2.11, 3.42, -2.79 Q 14.74, -2.74, 25.88, -2.69 Q 36.99, -1.22, 48.26, -2.17\
                        Q 49.67, -2.38, 51.27, -1.42 Q 51.91, -0.05, 52.71, 1.45 Q 52.54, 13.77, 52.68, 26.28 Q 51.66, 27.38, 50.59, 28.52 Q 50.04,\
                        29.88, 48.54, 30.68 Q 37.09, 29.61, 26.02, 29.22 Q 15.00, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="25" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Vote</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page331142030"] .border-wrapper, body[data-current-page-id="page331142030"] .simulation-container{\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page331142030"] .border-wrapper, body.has-frame[data-current-page-id="page331142030"]\
         .simulation-container{\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="page331142030"] .svg-border-1366-768{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page331142030"] .border-wrapper .border-div{\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page331142030",\
      			"name": "Poll Setup",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
   <div id="border-wrapper">\
      <div xmlns="http://www.w3.org/1999/xhtml" xmlns:json="http://json.org/" class="svg-border svg-border-1366-768" style="display: none;">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="svg_border" style="position:absolute;left:-43px;top:-13px;width:1423px;height:792px;"><svg:path class=" svg_unselected_element" d="M 32.00, 3.00 Q 42.12, 3.56, 52.24, 2.69 Q 62.35, 2.17, 72.47, 2.08 Q 82.59,\
            2.31, 92.71, 1.81 Q 102.82, 1.25, 112.94, 1.97 Q 123.06, 1.97, 133.18, 1.32 Q 143.29, 1.26, 153.41, 1.14 Q 163.53, 0.93, 173.65,\
            0.88 Q 183.76, 1.06, 193.88, 1.85 Q 204.00, 2.50, 214.12, 2.17 Q 224.24, 1.60, 234.35, 1.34 Q 244.47, 1.47, 254.59, 1.18 Q\
            264.71, 1.42, 274.82, 1.43 Q 284.94, 1.87, 295.06, 0.97 Q 305.18, 0.90, 315.29, 0.83 Q 325.41, 0.70, 335.53, 1.03 Q 345.65,\
            2.34, 355.76, 2.12 Q 365.88, 3.29, 376.00, 3.43 Q 386.12, 2.54, 396.24, 2.77 Q 406.35, 2.79, 416.47, 1.97 Q 426.59, 1.76,\
            436.71, 1.98 Q 446.82, 2.56, 456.94, 2.28 Q 467.06, 1.95, 477.18, 2.12 Q 487.29, 1.28, 497.41, 1.97 Q 507.53, 2.21, 517.65,\
            2.13 Q 527.76, 2.39, 537.88, 2.75 Q 548.00, 2.10, 558.12, 1.56 Q 568.24, 1.50, 578.35, 2.19 Q 588.47, 1.24, 598.59, 1.57 Q\
            608.71, 1.25, 618.82, 1.25 Q 628.94, 1.30, 639.06, 1.29 Q 649.18, 1.04, 659.29, 1.89 Q 669.41, 0.96, 679.53, 0.46 Q 689.65,\
            0.97, 699.77, 2.88 Q 709.88, 3.97, 720.00, 3.83 Q 730.12, 3.35, 740.24, 3.13 Q 750.35, 1.50, 760.47, 2.53 Q 770.59, 1.61,\
            780.71, 2.06 Q 790.82, 2.11, 800.94, 1.94 Q 811.06, 2.37, 821.18, 2.23 Q 831.29, 2.21, 841.41, 1.72 Q 851.53, 1.52, 861.65,\
            1.79 Q 871.77, 1.56, 881.88, 2.20 Q 892.00, 1.79, 902.12, 1.70 Q 912.24, 1.89, 922.35, 2.01 Q 932.47, 1.70, 942.59, 1.63 Q\
            952.71, 1.52, 962.82, 2.58 Q 972.94, 3.38, 983.06, 2.93 Q 993.18, 2.27, 1003.30, 2.44 Q 1013.41, 2.28, 1023.53, 2.18 Q 1033.65,\
            2.15, 1043.77, 2.47 Q 1053.88, 2.42, 1064.00, 2.32 Q 1074.12, 2.11, 1084.24, 2.08 Q 1094.35, 2.59, 1104.47, 2.02 Q 1114.59,\
            2.43, 1124.71, 3.24 Q 1134.83, 2.59, 1144.94, 1.49 Q 1155.06, 1.97, 1165.18, 2.29 Q 1175.30, 2.49, 1185.41, 2.15 Q 1195.53,\
            2.24, 1205.65, 1.83 Q 1215.77, 1.38, 1225.88, 1.71 Q 1236.00, 1.78, 1246.12, 1.79 Q 1256.24, 1.37, 1266.35, 1.12 Q 1276.47,\
            2.13, 1286.59, 1.66 Q 1296.71, 1.73, 1306.83, 0.97 Q 1316.94, 1.25, 1327.06, 1.16 Q 1337.18, 0.97, 1347.30, 0.94 Q 1357.41,\
            1.49, 1367.53, 1.74 Q 1377.65, 2.36, 1387.77, 2.57 Q 1397.88, 1.94, 1408.15, 2.85 Q 1408.65, 12.95, 1408.52, 23.27 Q 1408.03,\
            33.51, 1407.86, 43.69 Q 1408.73, 53.84, 1409.37, 64.02 Q 1408.92, 74.19, 1408.38, 84.37 Q 1408.73, 94.54, 1409.60, 104.71\
            Q 1408.75, 114.88, 1408.48, 125.05 Q 1408.01, 135.22, 1408.39, 145.39 Q 1408.59, 155.57, 1408.23, 165.74 Q 1409.37, 175.91,\
            1408.00, 186.08 Q 1407.85, 196.25, 1408.34, 206.42 Q 1408.01, 216.59, 1408.11, 226.76 Q 1408.37, 236.93, 1408.98, 247.11 Q\
            1409.51, 257.28, 1409.67, 267.45 Q 1408.85, 277.62, 1409.16, 287.79 Q 1409.15, 297.96, 1408.74, 308.13 Q 1408.60, 318.30,\
            1408.59, 328.47 Q 1409.12, 338.64, 1409.02, 348.82 Q 1408.90, 358.99, 1408.66, 369.16 Q 1408.72, 379.33, 1408.72, 389.50 Q\
            1408.57, 399.67, 1407.98, 409.84 Q 1408.19, 420.01, 1408.59, 430.18 Q 1409.31, 440.36, 1409.17, 450.53 Q 1410.05, 460.70,\
            1409.53, 470.87 Q 1408.97, 481.04, 1408.65, 491.21 Q 1407.87, 501.38, 1407.92, 511.55 Q 1407.93, 521.72, 1408.17, 531.89 Q\
            1409.22, 542.07, 1409.25, 552.24 Q 1409.04, 562.41, 1409.19, 572.58 Q 1409.24, 582.75, 1409.39, 592.92 Q 1409.13, 603.09,\
            1408.75, 613.26 Q 1409.24, 623.43, 1409.20, 633.61 Q 1409.15, 643.78, 1408.92, 653.95 Q 1408.96, 664.12, 1408.91, 674.29 Q\
            1408.59, 684.46, 1408.67, 694.63 Q 1408.95, 704.80, 1409.00, 714.97 Q 1408.78, 725.15, 1409.09, 735.32 Q 1408.97, 745.49,\
            1408.29, 755.66 Q 1408.35, 765.83, 1408.28, 776.28 Q 1398.06, 776.53, 1387.83, 776.41 Q 1377.63, 775.73, 1367.51, 775.31 Q\
            1357.41, 775.69, 1347.30, 776.29 Q 1337.18, 776.46, 1327.06, 777.36 Q 1316.95, 777.88, 1306.83, 777.04 Q 1296.71, 775.72,\
            1286.59, 776.03 Q 1276.47, 775.56, 1266.35, 775.92 Q 1256.24, 775.50, 1246.12, 776.21 Q 1236.00, 775.88, 1225.88, 775.41 Q\
            1215.77, 776.85, 1205.65, 776.04 Q 1195.53, 776.62, 1185.41, 777.29 Q 1175.30, 776.86, 1165.18, 776.84 Q 1155.06, 776.26,\
            1144.94, 776.45 Q 1134.83, 776.36, 1124.71, 775.95 Q 1114.59, 775.68, 1104.47, 776.76 Q 1094.35, 777.16, 1084.24, 777.73 Q\
            1074.12, 776.76, 1064.00, 775.86 Q 1053.88, 775.80, 1043.77, 776.09 Q 1033.65, 776.57, 1023.53, 776.80 Q 1013.41, 778.10,\
            1003.30, 777.96 Q 993.18, 777.18, 983.06, 777.15 Q 972.94, 776.55, 962.82, 777.00 Q 952.71, 776.66, 942.59, 776.76 Q 932.47,\
            777.96, 922.35, 777.90 Q 912.24, 777.29, 902.12, 777.00 Q 892.00, 776.25, 881.88, 776.75 Q 871.77, 776.61, 861.65, 776.50\
            Q 851.53, 776.50, 841.41, 776.62 Q 831.29, 776.72, 821.18, 777.16 Q 811.06, 776.78, 800.94, 776.16 Q 790.82, 776.33, 780.71,\
            776.51 Q 770.59, 776.62, 760.47, 776.49 Q 750.35, 775.95, 740.24, 775.57 Q 730.12, 775.38, 720.00, 775.68 Q 709.88, 776.24,\
            699.77, 776.23 Q 689.65, 777.53, 679.53, 777.51 Q 669.41, 777.72, 659.29, 776.87 Q 649.18, 775.33, 639.06, 776.13 Q 628.94,\
            776.02, 618.82, 776.24 Q 608.71, 776.40, 598.59, 777.69 Q 588.47, 776.97, 578.35, 776.46 Q 568.24, 776.60, 558.12, 776.20\
            Q 548.00, 775.53, 537.88, 775.52 Q 527.76, 776.51, 517.65, 775.74 Q 507.53, 776.50, 497.41, 776.19 Q 487.29, 775.63, 477.18,\
            775.76 Q 467.06, 776.71, 456.94, 777.09 Q 446.82, 776.61, 436.71, 775.79 Q 426.59, 775.68, 416.47, 776.35 Q 406.35, 776.64,\
            396.24, 776.67 Q 386.12, 776.09, 376.00, 776.44 Q 365.88, 777.04, 355.76, 777.00 Q 345.65, 777.48, 335.53, 776.98 Q 325.41,\
            777.94, 315.29, 777.69 Q 305.18, 777.45, 295.06, 777.55 Q 284.94, 777.49, 274.82, 778.04 Q 264.71, 777.60, 254.59, 778.22\
            Q 244.47, 777.71, 234.35, 778.50 Q 224.24, 777.31, 214.12, 777.54 Q 204.00, 777.19, 193.88, 776.77 Q 183.76, 776.88, 173.65,\
            776.70 Q 163.53, 776.66, 153.41, 777.29 Q 143.29, 777.34, 133.18, 777.79 Q 123.06, 777.45, 112.94, 777.11 Q 102.82, 776.42,\
            92.71, 776.86 Q 82.59, 777.24, 72.47, 777.01 Q 62.35, 777.30, 52.24, 777.86 Q 42.12, 777.48, 31.02, 776.98 Q 31.64, 765.95,\
            31.59, 755.72 Q 30.83, 745.57, 30.96, 735.35 Q 30.37, 725.17, 30.00, 714.99 Q 29.65, 704.81, 30.43, 694.64 Q 30.57, 684.46,\
            31.34, 674.29 Q 32.54, 664.12, 32.03, 653.95 Q 30.33, 643.78, 29.89, 633.61 Q 30.25, 623.43, 29.77, 613.26 Q 30.08, 603.09,\
            30.82, 592.92 Q 31.17, 582.75, 31.36, 572.58 Q 31.58, 562.41, 31.44, 552.24 Q 31.29, 542.07, 31.26, 531.89 Q 31.53, 521.72,\
            31.69, 511.55 Q 31.70, 501.38, 31.63, 491.21 Q 31.04, 481.04, 30.51, 470.87 Q 30.18, 460.70, 30.27, 450.53 Q 30.23, 440.36,\
            30.57, 430.18 Q 30.48, 420.01, 30.13, 409.84 Q 30.03, 399.67, 29.98, 389.50 Q 30.72, 379.33, 30.54, 369.16 Q 30.71, 358.99,\
            30.38, 348.82 Q 30.26, 338.64, 30.95, 328.47 Q 30.73, 318.30, 30.66, 308.13 Q 30.63, 297.96, 30.85, 287.79 Q 30.28, 277.62,\
            30.39, 267.45 Q 30.83, 257.28, 30.89, 247.11 Q 30.87, 236.93, 30.74, 226.76 Q 31.35, 216.59, 31.40, 206.42 Q 31.99, 196.25,\
            31.87, 186.08 Q 30.90, 175.91, 31.41, 165.74 Q 31.31, 155.57, 30.96, 145.39 Q 31.12, 135.22, 31.30, 125.05 Q 30.52, 114.88,\
            30.73, 104.71 Q 30.62, 94.54, 31.36, 84.37 Q 31.35, 74.20, 30.90, 64.03 Q 32.02, 53.86, 32.00, 43.68 Q 33.12, 33.51, 32.66,\
            23.34 Q 32.00, 13.17, 32.00, 3.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 23.00, 7.00 Q 33.12, 6.07, 43.24, 5.98 Q 53.35, 5.82, 63.47, 5.85 Q 73.59,\
            6.66, 83.71, 6.29 Q 93.82, 5.91, 103.94, 5.88 Q 114.06, 6.92, 124.18, 6.87 Q 134.29, 6.70, 144.41, 6.48 Q 154.53, 6.31, 164.65,\
            6.72 Q 174.76, 6.30, 184.88, 6.11 Q 195.00, 6.41, 205.12, 7.47 Q 215.24, 7.75, 225.35, 7.26 Q 235.47, 7.55, 245.59, 7.37 Q\
            255.71, 8.27, 265.82, 7.65 Q 275.94, 8.39, 286.06, 7.23 Q 296.18, 7.26, 306.29, 7.28 Q 316.41, 6.95, 326.53, 6.27 Q 336.65,\
            6.72, 346.76, 7.03 Q 356.88, 7.00, 367.00, 7.08 Q 377.12, 7.08, 387.24, 6.75 Q 397.35, 6.98, 407.47, 6.33 Q 417.59, 5.92,\
            427.71, 5.85 Q 437.82, 7.14, 447.94, 6.98 Q 458.06, 7.69, 468.18, 6.96 Q 478.29, 6.95, 488.41, 7.33 Q 498.53, 6.39, 508.65,\
            6.42 Q 518.76, 7.45, 528.88, 8.79 Q 539.00, 7.58, 549.12, 7.16 Q 559.24, 6.72, 569.35, 7.18 Q 579.47, 7.69, 589.59, 6.98 Q\
            599.71, 7.31, 609.82, 6.93 Q 619.94, 7.01, 630.06, 6.44 Q 640.18, 5.64, 650.29, 6.23 Q 660.41, 6.78, 670.53, 6.74 Q 680.65,\
            5.98, 690.77, 7.10 Q 700.88, 6.86, 711.00, 7.12 Q 721.12, 6.80, 731.24, 7.00 Q 741.35, 6.11, 751.47, 6.26 Q 761.59, 6.61,\
            771.71, 6.31 Q 781.82, 6.02, 791.94, 5.53 Q 802.06, 6.33, 812.18, 5.63 Q 822.29, 7.10, 832.41, 6.43 Q 842.53, 6.91, 852.65,\
            7.43 Q 862.77, 7.09, 872.88, 6.79 Q 883.00, 7.15, 893.12, 7.97 Q 903.24, 7.51, 913.35, 7.12 Q 923.47, 6.52, 933.59, 6.61 Q\
            943.71, 7.16, 953.82, 6.86 Q 963.94, 6.44, 974.06, 6.32 Q 984.18, 6.95, 994.30, 6.89 Q 1004.41, 6.78, 1014.53, 7.57 Q 1024.65,\
            8.31, 1034.77, 8.14 Q 1044.88, 6.96, 1055.00, 6.47 Q 1065.12, 6.25, 1075.24, 6.83 Q 1085.35, 6.95, 1095.47, 6.38 Q 1105.59,\
            6.62, 1115.71, 6.94 Q 1125.83, 6.55, 1135.94, 6.59 Q 1146.06, 6.53, 1156.18, 5.63 Q 1166.30, 6.17, 1176.41, 7.03 Q 1186.53,\
            6.80, 1196.65, 7.35 Q 1206.77, 7.82, 1216.88, 7.43 Q 1227.00, 6.67, 1237.12, 6.25 Q 1247.24, 5.29, 1257.35, 4.98 Q 1267.47,\
            5.61, 1277.59, 6.52 Q 1287.71, 6.32, 1297.83, 7.49 Q 1307.94, 6.80, 1318.06, 7.05 Q 1328.18, 6.07, 1338.30, 5.72 Q 1348.41,\
            7.30, 1358.53, 7.36 Q 1368.65, 6.25, 1378.77, 6.57 Q 1388.88, 7.04, 1398.99, 7.01 Q 1399.07, 17.15, 1398.97, 27.35 Q 1398.71,\
            37.53, 1398.71, 47.69 Q 1399.11, 57.85, 1399.28, 68.02 Q 1400.37, 78.19, 1398.95, 88.37 Q 1399.34, 98.54, 1398.84, 108.71\
            Q 1399.25, 118.88, 1399.71, 129.05 Q 1400.03, 139.22, 1400.26, 149.39 Q 1400.42, 159.57, 1401.03, 169.74 Q 1400.27, 179.91,\
            1399.47, 190.08 Q 1399.40, 200.25, 1400.42, 210.42 Q 1399.16, 220.59, 1398.48, 230.76 Q 1399.26, 240.93, 1399.36, 251.11 Q\
            1399.73, 261.28, 1398.08, 271.45 Q 1398.65, 281.62, 1399.00, 291.79 Q 1399.45, 301.96, 1399.33, 312.13 Q 1399.31, 322.30,\
            1399.02, 332.47 Q 1398.78, 342.64, 1398.70, 352.82 Q 1398.68, 362.99, 1398.41, 373.16 Q 1398.71, 383.33, 1398.62, 393.50 Q\
            1398.32, 403.67, 1398.20, 413.84 Q 1398.76, 424.01, 1399.64, 434.18 Q 1399.81, 444.36, 1400.50, 454.53 Q 1400.83, 464.70,\
            1400.52, 474.87 Q 1400.32, 485.04, 1400.17, 495.21 Q 1399.97, 505.38, 1400.37, 515.55 Q 1399.97, 525.72, 1400.29, 535.89 Q\
            1399.77, 546.07, 1400.23, 556.24 Q 1399.98, 566.41, 1400.14, 576.58 Q 1400.30, 586.75, 1400.36, 596.92 Q 1399.97, 607.09,\
            1399.98, 617.26 Q 1399.29, 627.43, 1399.04, 637.61 Q 1398.83, 647.78, 1399.28, 657.95 Q 1399.71, 668.12, 1400.05, 678.29 Q\
            1399.69, 688.46, 1399.52, 698.63 Q 1399.03, 708.80, 1400.20, 718.97 Q 1400.05, 729.15, 1400.29, 739.32 Q 1399.94, 749.49,\
            1400.48, 759.66 Q 1399.65, 769.83, 1399.41, 780.41 Q 1389.15, 780.81, 1378.87, 780.69 Q 1368.71, 780.87, 1358.55, 780.71 Q\
            1348.44, 781.34, 1338.31, 781.75 Q 1328.18, 781.39, 1318.06, 780.34 Q 1307.94, 779.42, 1297.83, 779.79 Q 1287.71, 780.15,\
            1277.59, 781.64 Q 1267.47, 782.10, 1257.35, 781.14 Q 1247.24, 779.68, 1237.12, 780.18 Q 1227.00, 779.90, 1216.88, 780.43 Q\
            1206.77, 779.39, 1196.65, 779.77 Q 1186.53, 779.96, 1176.41, 779.41 Q 1166.30, 780.18, 1156.18, 779.56 Q 1146.06, 779.73,\
            1135.94, 779.53 Q 1125.83, 779.33, 1115.71, 779.64 Q 1105.59, 779.90, 1095.47, 780.55 Q 1085.35, 780.59, 1075.24, 780.85 Q\
            1065.12, 782.07, 1055.00, 781.23 Q 1044.88, 780.68, 1034.77, 780.87 Q 1024.65, 780.78, 1014.53, 781.55 Q 1004.41, 780.99,\
            994.30, 780.66 Q 984.18, 781.37, 974.06, 782.16 Q 963.94, 781.55, 953.82, 781.00 Q 943.71, 780.95, 933.59, 781.31 Q 923.47,\
            781.49, 913.35, 781.60 Q 903.24, 781.72, 893.12, 780.96 Q 883.00, 780.70, 872.88, 780.99 Q 862.77, 781.55, 852.65, 781.22\
            Q 842.53, 781.50, 832.41, 781.63 Q 822.29, 781.66, 812.18, 781.68 Q 802.06, 780.98, 791.94, 781.23 Q 781.82, 780.65, 771.71,\
            781.34 Q 761.59, 781.05, 751.47, 780.93 Q 741.35, 780.52, 731.24, 780.63 Q 721.12, 780.77, 711.00, 780.36 Q 700.88, 781.51,\
            690.77, 781.07 Q 680.65, 780.50, 670.53, 780.33 Q 660.41, 781.45, 650.29, 781.28 Q 640.18, 780.29, 630.06, 779.09 Q 619.94,\
            779.78, 609.82, 780.56 Q 599.71, 779.82, 589.59, 779.61 Q 579.47, 779.54, 569.35, 780.06 Q 559.24, 780.41, 549.12, 780.51\
            Q 539.00, 781.11, 528.88, 780.57 Q 518.76, 781.40, 508.65, 780.66 Q 498.53, 781.07, 488.41, 781.33 Q 478.29, 781.80, 468.18,\
            782.20 Q 458.06, 781.46, 447.94, 781.10 Q 437.82, 781.77, 427.71, 780.41 Q 417.59, 781.16, 407.47, 780.15 Q 397.35, 781.32,\
            387.24, 782.21 Q 377.12, 781.88, 367.00, 780.40 Q 356.88, 780.14, 346.76, 779.57 Q 336.65, 780.59, 326.53, 781.32 Q 316.41,\
            781.13, 306.29, 780.74 Q 296.18, 781.06, 286.06, 781.17 Q 275.94, 780.99, 265.82, 779.80 Q 255.71, 781.03, 245.59, 781.18\
            Q 235.47, 781.55, 225.35, 781.65 Q 215.24, 781.85, 205.12, 781.88 Q 195.00, 782.04, 184.88, 781.62 Q 174.76, 781.72, 164.65,\
            781.87 Q 154.53, 781.95, 144.41, 781.59 Q 134.29, 781.36, 124.18, 780.97 Q 114.06, 781.25, 103.94, 781.34 Q 93.82, 781.48,\
            83.71, 781.62 Q 73.59, 781.44, 63.47, 781.20 Q 53.35, 781.06, 43.24, 781.16 Q 33.12, 780.57, 22.98, 780.02 Q 22.90, 769.86,\
            22.92, 759.67 Q 22.25, 749.54, 22.83, 739.32 Q 22.14, 729.16, 22.06, 718.98 Q 22.02, 708.81, 22.04, 698.63 Q 22.26, 688.46,\
            22.61, 678.29 Q 22.64, 668.12, 22.20, 657.95 Q 21.97, 647.78, 21.59, 637.61 Q 21.85, 627.43, 22.32, 617.26 Q 22.76, 607.09,\
            22.53, 596.92 Q 22.48, 586.75, 23.01, 576.58 Q 22.88, 566.41, 22.85, 556.24 Q 22.30, 546.07, 22.27, 535.89 Q 22.93, 525.72,\
            23.16, 515.55 Q 23.36, 505.38, 23.15, 495.21 Q 23.38, 485.04, 23.00, 474.87 Q 23.48, 464.70, 21.97, 454.53 Q 22.93, 444.36,\
            22.47, 434.18 Q 22.94, 424.01, 22.98, 413.84 Q 23.24, 403.67, 23.19, 393.50 Q 23.31, 383.33, 22.60, 373.16 Q 22.47, 362.99,\
            22.65, 352.82 Q 21.96, 342.64, 21.87, 332.47 Q 22.48, 322.30, 21.65, 312.13 Q 21.24, 301.96, 21.12, 291.79 Q 22.52, 281.62,\
            21.15, 271.45 Q 22.07, 261.28, 21.46, 251.11 Q 21.98, 240.93, 21.92, 230.76 Q 21.80, 220.59, 21.85, 210.42 Q 22.11, 200.25,\
            22.56, 190.08 Q 22.96, 179.91, 23.29, 169.74 Q 23.34, 159.57, 23.90, 149.39 Q 22.70, 139.22, 21.87, 129.05 Q 22.17, 118.88,\
            22.06, 108.71 Q 22.23, 98.54, 21.65, 88.37 Q 22.48, 78.20, 22.24, 68.03 Q 21.76, 57.86, 21.68, 47.68 Q 22.79, 37.51, 22.90,\
            27.34 Q 23.00, 17.17, 23.00, 7.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 40.00, 11.00 Q 50.12, 10.39, 60.24, 10.82 Q 70.35, 10.66, 80.47, 11.65 Q 90.59,\
            10.47, 100.71, 10.41 Q 110.82, 11.13, 120.94, 11.54 Q 131.06, 11.60, 141.18, 10.00 Q 151.29, 9.75, 161.41, 10.34 Q 171.53,\
            10.14, 181.65, 11.01 Q 191.76, 10.81, 201.88, 11.29 Q 212.00, 11.27, 222.12, 11.53 Q 232.24, 10.27, 242.35, 9.83 Q 252.47,\
            9.44, 262.59, 9.36 Q 272.71, 9.21, 282.82, 9.87 Q 292.94, 9.31, 303.06, 8.61 Q 313.18, 9.96, 323.29, 10.21 Q 333.41, 10.20,\
            343.53, 9.87 Q 353.65, 9.00, 363.76, 9.55 Q 373.88, 10.02, 384.00, 9.53 Q 394.12, 9.80, 404.24, 10.52 Q 414.35, 9.88, 424.47,\
            9.76 Q 434.59, 9.86, 444.71, 10.20 Q 454.82, 10.26, 464.94, 10.34 Q 475.06, 10.32, 485.18, 10.33 Q 495.29, 10.13, 505.41,\
            9.96 Q 515.53, 10.76, 525.65, 10.86 Q 535.76, 10.58, 545.88, 9.82 Q 556.00, 9.52, 566.12, 8.88 Q 576.24, 9.75, 586.35, 10.77\
            Q 596.47, 10.91, 606.59, 11.05 Q 616.71, 11.48, 626.82, 11.15 Q 636.94, 11.56, 647.06, 11.03 Q 657.18, 9.70, 667.29, 9.66\
            Q 677.41, 10.59, 687.53, 10.64 Q 697.65, 11.29, 707.77, 11.16 Q 717.88, 10.46, 728.00, 9.64 Q 738.12, 10.02, 748.24, 8.55\
            Q 758.35, 9.26, 768.47, 10.38 Q 778.59, 10.54, 788.71, 10.68 Q 798.82, 11.48, 808.94, 10.63 Q 819.06, 10.55, 829.18, 10.31\
            Q 839.29, 10.12, 849.41, 10.22 Q 859.53, 10.19, 869.65, 10.11 Q 879.77, 10.30, 889.88, 10.38 Q 900.00, 10.07, 910.12, 9.78\
            Q 920.24, 9.83, 930.35, 9.61 Q 940.47, 9.49, 950.59, 9.40 Q 960.71, 9.21, 970.82, 9.03 Q 980.94, 9.85, 991.06, 10.25 Q 1001.18,\
            10.31, 1011.30, 9.44 Q 1021.41, 9.77, 1031.53, 9.43 Q 1041.65, 9.63, 1051.77, 8.82 Q 1061.88, 9.55, 1072.00, 10.10 Q 1082.12,\
            9.55, 1092.24, 9.14 Q 1102.35, 9.32, 1112.47, 9.66 Q 1122.59, 9.74, 1132.71, 9.81 Q 1142.83, 10.21, 1152.94, 10.00 Q 1163.06,\
            9.91, 1173.18, 9.75 Q 1183.30, 9.71, 1193.41, 9.75 Q 1203.53, 10.35, 1213.65, 9.30 Q 1223.77, 9.68, 1233.88, 9.74 Q 1244.00,\
            9.84, 1254.12, 9.99 Q 1264.24, 9.89, 1274.35, 9.72 Q 1284.47, 9.65, 1294.59, 9.87 Q 1304.71, 9.36, 1314.83, 10.08 Q 1324.94,\
            9.54, 1335.06, 9.73 Q 1345.18, 10.30, 1355.30, 10.18 Q 1365.41, 10.59, 1375.53, 9.38 Q 1385.65, 10.23, 1395.77, 9.48 Q 1405.88,\
            9.97, 1416.52, 10.48 Q 1416.05, 21.15, 1415.91, 31.36 Q 1417.22, 41.43, 1417.71, 51.63 Q 1417.74, 61.83, 1417.26, 72.02 Q\
            1417.28, 82.19, 1416.24, 92.37 Q 1416.55, 102.54, 1415.92, 112.71 Q 1416.49, 122.88, 1416.42, 133.05 Q 1416.37, 143.22, 1416.38,\
            153.39 Q 1416.05, 163.57, 1417.18, 173.74 Q 1417.30, 183.91, 1416.29, 194.08 Q 1416.74, 204.25, 1417.30, 214.42 Q 1417.78,\
            224.59, 1417.64, 234.76 Q 1417.58, 244.93, 1416.74, 255.11 Q 1417.02, 265.28, 1417.13, 275.45 Q 1417.09, 285.62, 1416.98,\
            295.79 Q 1416.71, 305.96, 1416.49, 316.13 Q 1416.14, 326.30, 1415.33, 336.47 Q 1415.70, 346.64, 1415.53, 356.82 Q 1416.13,\
            366.99, 1416.62, 377.16 Q 1416.37, 387.33, 1416.57, 397.50 Q 1416.57, 407.67, 1416.66, 417.84 Q 1416.52, 428.01, 1416.70,\
            438.18 Q 1417.32, 448.36, 1416.49, 458.53 Q 1417.09, 468.70, 1417.40, 478.87 Q 1417.15, 489.04, 1417.50, 499.21 Q 1417.88,\
            509.38, 1416.86, 519.55 Q 1416.38, 529.72, 1415.89, 539.89 Q 1415.29, 550.07, 1415.80, 560.24 Q 1415.85, 570.41, 1417.10,\
            580.58 Q 1417.05, 590.75, 1416.66, 600.92 Q 1416.88, 611.09, 1416.26, 621.26 Q 1417.65, 631.43, 1416.15, 641.61 Q 1416.31,\
            651.78, 1417.43, 661.95 Q 1418.31, 672.12, 1416.92, 682.29 Q 1416.25, 692.46, 1416.11, 702.63 Q 1416.13, 712.80, 1416.59,\
            722.97 Q 1417.20, 733.15, 1417.26, 743.32 Q 1417.35, 753.49, 1417.42, 763.66 Q 1416.78, 773.83, 1416.53, 784.53 Q 1406.19,\
            784.90, 1395.94, 785.22 Q 1385.74, 785.38, 1375.58, 785.48 Q 1365.43, 785.14, 1355.30, 785.06 Q 1345.18, 785.25, 1335.06,\
            785.44 Q 1324.94, 785.07, 1314.83, 785.03 Q 1304.71, 785.14, 1294.59, 785.33 Q 1284.47, 785.48, 1274.35, 785.49 Q 1264.24,\
            785.21, 1254.12, 785.07 Q 1244.00, 784.41, 1233.88, 784.21 Q 1223.77, 784.56, 1213.65, 785.84 Q 1203.53, 785.96, 1193.41,\
            785.24 Q 1183.30, 784.77, 1173.18, 784.78 Q 1163.06, 784.92, 1152.94, 784.90 Q 1142.83, 784.78, 1132.71, 784.72 Q 1122.59,\
            784.76, 1112.47, 784.88 Q 1102.35, 784.85, 1092.24, 785.16 Q 1082.12, 784.86, 1072.00, 784.79 Q 1061.88, 784.51, 1051.77,\
            784.34 Q 1041.65, 785.12, 1031.53, 785.40 Q 1021.41, 784.81, 1011.30, 784.45 Q 1001.18, 784.04, 991.06, 784.87 Q 980.94, 784.41,\
            970.82, 784.00 Q 960.71, 783.52, 950.59, 783.57 Q 940.47, 784.64, 930.35, 783.89 Q 920.24, 782.72, 910.12, 783.34 Q 900.00,\
            784.31, 889.88, 784.44 Q 879.77, 783.80, 869.65, 783.19 Q 859.53, 784.04, 849.41, 784.91 Q 839.29, 785.01, 829.18, 784.39\
            Q 819.06, 784.08, 808.94, 784.56 Q 798.82, 785.45, 788.71, 785.22 Q 778.59, 784.80, 768.47, 785.06 Q 758.35, 785.33, 748.24,\
            785.50 Q 738.12, 783.87, 728.00, 785.00 Q 717.88, 784.36, 707.77, 784.53 Q 697.65, 784.89, 687.53, 784.53 Q 677.41, 784.89,\
            667.29, 785.11 Q 657.18, 784.90, 647.06, 783.99 Q 636.94, 784.19, 626.82, 784.73 Q 616.71, 785.19, 606.59, 783.74 Q 596.47,\
            783.42, 586.35, 783.36 Q 576.24, 784.48, 566.12, 783.71 Q 556.00, 783.18, 545.88, 783.95 Q 535.76, 784.73, 525.65, 783.99\
            Q 515.53, 783.73, 505.41, 783.62 Q 495.29, 783.76, 485.18, 784.70 Q 475.06, 784.98, 464.94, 784.93 Q 454.82, 784.08, 444.71,\
            783.46 Q 434.59, 784.23, 424.47, 783.57 Q 414.35, 784.59, 404.24, 784.47 Q 394.12, 785.18, 384.00, 785.51 Q 373.88, 785.34,\
            363.76, 785.21 Q 353.65, 784.91, 343.53, 784.71 Q 333.41, 784.83, 323.29, 784.17 Q 313.18, 784.32, 303.06, 784.59 Q 292.94,\
            784.61, 282.82, 784.24 Q 272.71, 783.24, 262.59, 784.22 Q 252.47, 784.59, 242.35, 784.15 Q 232.24, 783.41, 222.12, 783.91\
            Q 212.00, 783.99, 201.88, 783.20 Q 191.76, 783.88, 181.65, 783.20 Q 171.53, 783.40, 161.41, 782.84 Q 151.29, 783.26, 141.18,\
            783.56 Q 131.06, 784.20, 120.94, 783.26 Q 110.82, 782.76, 100.71, 784.01 Q 90.59, 784.51, 80.47, 784.17 Q 70.35, 783.87, 60.24,\
            784.37 Q 50.12, 784.01, 39.68, 784.33 Q 39.70, 773.93, 39.88, 763.68 Q 39.00, 753.55, 39.83, 743.32 Q 38.55, 733.17, 39.35,\
            722.98 Q 38.84, 712.81, 38.97, 702.63 Q 38.81, 692.46, 38.58, 682.29 Q 39.64, 672.12, 40.20, 661.95 Q 39.79, 651.78, 39.31,\
            641.61 Q 38.91, 631.43, 38.35, 621.26 Q 38.28, 611.09, 38.92, 600.92 Q 38.93, 590.75, 38.91, 580.58 Q 38.15, 570.41, 37.60,\
            560.24 Q 37.96, 550.07, 38.95, 539.89 Q 39.77, 529.72, 39.18, 519.55 Q 39.46, 509.38, 39.44, 499.21 Q 40.72, 489.04, 39.77,\
            478.87 Q 38.96, 468.70, 38.77, 458.53 Q 38.68, 448.36, 39.36, 438.18 Q 39.36, 428.01, 38.70, 417.84 Q 38.32, 407.67, 38.17,\
            397.50 Q 38.12, 387.33, 38.15, 377.16 Q 38.14, 366.99, 38.58, 356.82 Q 39.51, 346.64, 40.27, 336.47 Q 39.51, 326.30, 37.94,\
            316.13 Q 39.15, 305.96, 39.07, 295.79 Q 39.66, 285.62, 38.95, 275.45 Q 38.43, 265.28, 38.83, 255.11 Q 38.00, 244.93, 37.92,\
            234.76 Q 38.55, 224.59, 39.40, 214.42 Q 40.03, 204.25, 39.74, 194.08 Q 39.82, 183.91, 39.72, 173.74 Q 40.30, 163.57, 39.73,\
            153.39 Q 39.71, 143.22, 39.52, 133.05 Q 39.42, 122.88, 38.86, 112.71 Q 38.76, 102.54, 38.73, 92.37 Q 38.52, 82.20, 38.72,\
            72.03 Q 38.89, 61.86, 38.80, 51.68 Q 38.92, 41.51, 39.65, 31.34 Q 40.00, 21.17, 40.00, 11.00" style=" fill:white;"/>\
         </svg:svg>\
      </div>\
   </div>\
</div>');