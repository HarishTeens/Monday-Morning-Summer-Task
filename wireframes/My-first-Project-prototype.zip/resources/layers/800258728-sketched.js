rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__800258728-layer" class="layer" name="__containerId__pageLayer" data-layer-id="800258728" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-800258728-layer-431496727" style="position: absolute; left: 0px; top: 0px; width: 1375px; height: 820px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="431496727" data-review-reference-id="431496727">\
            <div class="stencil-wrapper" style="width: 1375px; height: 820px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 820px;width:1375px;" width="1375" height="820">\
                     <svg:g width="1375" height="820"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.08, 1.15, 22.16, 0.99 Q 32.24, 0.91, 42.32, 0.74 Q\
                        52.40, 0.52, 62.49, 0.47 Q 72.57, 0.55, 82.65, 0.33 Q 92.73, 0.41, 102.81, 0.28 Q 112.89, 0.27, 122.97, 0.11 Q 133.05, 0.03,\
                        143.13, 0.15 Q 153.21, 0.72, 163.29, 0.33 Q 173.38, 0.22, 183.46, 0.44 Q 193.54, 0.84, 203.62, 0.20 Q 213.70, 0.59, 223.78,\
                        0.80 Q 233.86, 0.53, 243.94, 0.16 Q 254.02, -0.38, 264.10, -0.36 Q 274.18, -0.46, 284.26, 0.37 Q 294.35, 0.82, 304.43, 0.79\
                        Q 314.51, 0.66, 324.59, 0.28 Q 334.67, 0.08, 344.75, 0.14 Q 354.83, 0.21, 364.91, 1.20 Q 374.99, 2.09, 385.07, 1.79 Q 395.15,\
                        1.09, 405.24, 0.83 Q 415.32, 1.29, 425.40, 1.34 Q 435.48, 1.56, 445.56, 2.20 Q 455.64, 1.97, 465.72, 1.47 Q 475.80, 0.95,\
                        485.88, 0.90 Q 495.96, 0.48, 506.04, 0.04 Q 516.12, -0.11, 526.21, 0.42 Q 536.29, 0.31, 546.37, 0.13 Q 556.45, 0.88, 566.53,\
                        1.39 Q 576.61, 0.24, 586.69, 1.02 Q 596.77, 0.87, 606.85, 0.99 Q 616.93, 1.24, 627.01, 1.81 Q 637.10, 1.70, 647.18, 1.80 Q\
                        657.26, 1.57, 667.34, 1.38 Q 677.42, 0.91, 687.50, 0.82 Q 697.58, 0.58, 707.66, 1.06 Q 717.74, 1.48, 727.82, 2.04 Q 737.90,\
                        1.82, 747.98, 1.91 Q 758.07, 1.49, 768.15, 1.18 Q 778.23, 0.89, 788.31, 1.14 Q 798.39, 0.89, 808.47, 1.31 Q 818.55, 1.78,\
                        828.63, 1.44 Q 838.71, 2.09, 848.79, 1.38 Q 858.87, 1.66, 868.96, 1.70 Q 879.04, 3.00, 889.12, 3.16 Q 899.20, 2.89, 909.28,\
                        3.37 Q 919.36, 2.89, 929.44, 1.72 Q 939.52, 1.41, 949.60, 1.23 Q 959.68, 1.25, 969.76, 1.46 Q 979.84, 1.01, 989.93, 0.68 Q\
                        1000.01, 0.31, 1010.09, 0.04 Q 1020.17, -0.19, 1030.25, 0.15 Q 1040.33, 1.11, 1050.41, 0.85 Q 1060.49, 0.79, 1070.57, 0.58\
                        Q 1080.65, 0.25, 1090.73, 0.25 Q 1100.82, 0.58, 1110.90, 1.27 Q 1120.98, 2.24, 1131.06, 2.23 Q 1141.14, 0.65, 1151.22, 0.63\
                        Q 1161.30, 0.50, 1171.38, 1.29 Q 1181.46, 1.27, 1191.54, 0.31 Q 1201.63, 0.81, 1211.71, 0.71 Q 1221.79, 1.40, 1231.87, 0.92\
                        Q 1241.95, 1.92, 1252.03, 2.03 Q 1262.11, 1.89, 1272.19, 1.43 Q 1282.27, 2.26, 1292.35, 1.97 Q 1302.43, 1.22, 1312.52, 1.60\
                        Q 1322.60, 0.89, 1332.68, 1.23 Q 1342.76, 0.66, 1352.84, 0.85 Q 1362.92, 1.38, 1373.96, 1.04 Q 1374.17, 11.81, 1374.85, 22.14\
                        Q 1374.21, 32.52, 1373.79, 42.77 Q 1373.25, 53.00, 1373.02, 63.20 Q 1372.74, 73.40, 1372.33, 83.60 Q 1373.22, 93.80, 1373.15,\
                        104.00 Q 1373.75, 114.20, 1372.95, 124.40 Q 1373.37, 134.60, 1372.94, 144.80 Q 1373.47, 155.00, 1373.31, 165.20 Q 1373.29,\
                        175.40, 1374.20, 185.60 Q 1373.92, 195.80, 1374.06, 206.00 Q 1373.79, 216.20, 1373.95, 226.40 Q 1373.56, 236.60, 1373.98,\
                        246.80 Q 1373.07, 257.00, 1373.00, 267.20 Q 1374.60, 277.40, 1374.69, 287.60 Q 1374.47, 297.80, 1374.16, 308.00 Q 1374.30,\
                        318.20, 1374.70, 328.40 Q 1373.89, 338.60, 1373.31, 348.80 Q 1373.80, 359.00, 1374.57, 369.20 Q 1374.11, 379.40, 1373.47,\
                        389.60 Q 1372.55, 399.80, 1373.21, 410.00 Q 1372.95, 420.20, 1373.30, 430.40 Q 1372.62, 440.60, 1372.39, 450.80 Q 1372.72,\
                        461.00, 1373.02, 471.20 Q 1374.31, 481.40, 1374.30, 491.60 Q 1374.13, 501.80, 1374.34, 512.00 Q 1374.47, 522.20, 1374.19,\
                        532.40 Q 1373.46, 542.60, 1373.90, 552.80 Q 1373.73, 563.00, 1373.52, 573.20 Q 1373.53, 583.40, 1374.60, 593.60 Q 1374.53,\
                        603.80, 1374.64, 614.00 Q 1374.79, 624.20, 1374.72, 634.40 Q 1374.95, 644.60, 1374.57, 654.80 Q 1374.70, 665.00, 1374.86,\
                        675.20 Q 1374.84, 685.40, 1374.34, 695.60 Q 1373.94, 705.80, 1372.78, 716.00 Q 1372.82, 726.20, 1373.22, 736.40 Q 1373.32,\
                        746.60, 1373.36, 756.80 Q 1373.50, 767.00, 1373.71, 777.20 Q 1373.88, 787.40, 1374.27, 797.60 Q 1373.89, 807.80, 1373.49,\
                        818.49 Q 1363.20, 818.85, 1352.99, 819.06 Q 1342.84, 819.28, 1332.70, 818.68 Q 1322.61, 818.99, 1312.52, 818.34 Q 1302.44,\
                        818.63, 1292.35, 817.59 Q 1282.27, 818.18, 1272.19, 818.62 Q 1262.11, 818.56, 1252.03, 817.61 Q 1241.95, 817.82, 1231.87,\
                        818.79 Q 1221.79, 819.28, 1211.71, 818.65 Q 1201.63, 818.48, 1191.54, 819.01 Q 1181.46, 819.71, 1171.38, 819.31 Q 1161.30,\
                        818.56, 1151.22, 818.06 Q 1141.14, 818.25, 1131.06, 818.25 Q 1120.98, 818.51, 1110.90, 817.91 Q 1100.82, 818.24, 1090.73,\
                        818.64 Q 1080.65, 818.30, 1070.57, 817.86 Q 1060.49, 816.52, 1050.41, 817.15 Q 1040.33, 817.57, 1030.25, 817.17 Q 1020.17,\
                        818.03, 1010.09, 818.01 Q 1000.01, 818.06, 989.93, 816.29 Q 979.84, 816.49, 969.76, 816.47 Q 959.68, 817.14, 949.60, 817.71\
                        Q 939.52, 817.85, 929.44, 817.64 Q 919.36, 818.38, 909.28, 818.97 Q 899.20, 818.99, 889.12, 818.45 Q 879.04, 817.30, 868.96,\
                        818.93 Q 858.87, 819.59, 848.79, 818.76 Q 838.71, 817.73, 828.63, 818.08 Q 818.55, 819.84, 808.47, 819.59 Q 798.39, 819.03,\
                        788.31, 818.24 Q 778.23, 818.74, 768.15, 819.95 Q 758.07, 819.03, 747.98, 818.91 Q 737.90, 818.36, 727.82, 818.68 Q 717.74,\
                        818.45, 707.66, 818.03 Q 697.58, 817.65, 687.50, 818.10 Q 677.42, 818.82, 667.34, 817.80 Q 657.26, 817.49, 647.18, 816.73\
                        Q 637.10, 817.77, 627.01, 818.20 Q 616.93, 818.17, 606.85, 818.16 Q 596.77, 818.34, 586.69, 819.09 Q 576.61, 817.69, 566.53,\
                        817.99 Q 556.45, 817.69, 546.37, 818.32 Q 536.29, 818.19, 526.21, 817.72 Q 516.12, 817.73, 506.04, 818.70 Q 495.96, 818.49,\
                        485.88, 818.19 Q 475.80, 816.98, 465.72, 817.69 Q 455.64, 819.11, 445.56, 819.19 Q 435.48, 818.55, 425.40, 819.29 Q 415.32,\
                        819.47, 405.24, 819.54 Q 395.15, 818.14, 385.07, 818.40 Q 374.99, 818.18, 364.91, 818.75 Q 354.83, 819.09, 344.75, 818.48\
                        Q 334.67, 817.12, 324.59, 819.23 Q 314.51, 818.95, 304.43, 817.58 Q 294.35, 817.66, 284.26, 816.75 Q 274.18, 818.11, 264.10,\
                        818.99 Q 254.02, 819.96, 243.94, 819.84 Q 233.86, 819.97, 223.78, 820.04 Q 213.70, 820.06, 203.62, 819.59 Q 193.54, 819.63,\
                        183.46, 819.47 Q 173.38, 819.78, 163.29, 819.79 Q 153.21, 819.57, 143.13, 819.62 Q 133.05, 819.96, 122.97, 819.09 Q 112.89,\
                        818.99, 102.81, 819.16 Q 92.73, 820.06, 82.65, 820.14 Q 72.57, 819.68, 62.49, 819.75 Q 52.40, 819.98, 42.32, 819.63 Q 32.24,\
                        819.26, 22.16, 818.83 Q 12.08, 819.03, 1.24, 818.76 Q 1.22, 808.06, 1.30, 797.70 Q 2.24, 787.38, 1.24, 777.23 Q 0.87, 767.02,\
                        1.87, 756.80 Q 2.19, 746.60, 1.87, 736.40 Q 1.29, 726.20, 1.53, 716.00 Q 1.81, 705.80, 1.80, 695.60 Q 1.24, 685.40, 0.18,\
                        675.20 Q -0.22, 665.00, 0.44, 654.80 Q 1.03, 644.60, 0.72, 634.40 Q 0.47, 624.20, 0.33, 614.00 Q 0.15, 603.80, 0.09, 593.60\
                        Q -0.06, 583.40, 0.87, 573.20 Q 1.81, 563.00, 1.73, 552.80 Q 1.24, 542.60, 1.06, 532.40 Q 0.97, 522.20, 1.29, 512.00 Q 1.58,\
                        501.80, 2.10, 491.60 Q 1.51, 481.40, 2.04, 471.20 Q 0.96, 461.00, 0.42, 450.80 Q 0.30, 440.60, 0.48, 430.40 Q 0.71, 420.20,\
                        1.01, 410.00 Q 0.73, 399.80, 0.18, 389.60 Q 0.28, 379.40, 0.37, 369.20 Q 0.01, 359.00, -0.04, 348.80 Q 0.32, 338.60, 0.91,\
                        328.40 Q 0.97, 318.20, 0.54, 308.00 Q 0.39, 297.80, 0.79, 287.60 Q 0.34, 277.40, 0.48, 267.20 Q 0.70, 257.00, 1.24, 246.80\
                        Q 1.32, 236.60, 1.68, 226.40 Q 2.12, 216.20, 2.31, 206.00 Q 1.89, 195.80, 1.56, 185.60 Q 1.18, 175.40, 1.32, 165.20 Q 1.09,\
                        155.00, 1.48, 144.80 Q 1.21, 134.60, 1.59, 124.40 Q 1.42, 114.20, 1.45, 104.00 Q 0.76, 93.80, 0.67, 83.60 Q 0.36, 73.40, 0.75,\
                        63.20 Q 0.57, 53.00, 0.83, 42.80 Q 1.17, 32.60, 0.49, 22.40 Q 2.00, 12.20, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 10.78, 6.98, 19.78, 11.61 Q 28.39, 16.90, 37.48, 21.37 Q 45.98,\
                        26.83, 54.41, 32.41 Q 63.32, 37.18, 72.16, 42.07 Q 80.83, 47.25, 89.63, 52.20 Q 98.15, 57.63, 106.60, 63.18 Q 115.35, 68.22,\
                        123.99, 73.45 Q 132.20, 79.40, 141.06, 84.25 Q 149.75, 89.40, 158.64, 94.20 Q 167.11, 99.72, 176.32, 103.99 Q 184.68, 109.69,\
                        193.52, 114.58 Q 201.92, 120.21, 210.35, 125.79 Q 219.01, 130.98, 227.84, 135.89 Q 236.56, 140.99, 245.62, 145.50 Q 254.32,\
                        150.63, 262.57, 156.51 Q 271.37, 161.47, 279.89, 166.91 Q 288.32, 172.47, 297.03, 177.59 Q 306.23, 181.88, 314.77, 187.27\
                        Q 322.93, 193.31, 332.06, 197.71 Q 340.89, 202.62, 350.10, 206.88 Q 358.70, 212.19, 367.02, 217.94 Q 375.73, 223.05, 384.64,\
                        227.83 Q 393.00, 233.53, 401.46, 239.05 Q 410.19, 244.13, 418.60, 249.75 Q 427.44, 254.63, 435.69, 260.51 Q 444.65, 265.21,\
                        453.52, 270.04 Q 462.18, 275.23, 470.53, 280.96 Q 479.42, 285.76, 488.60, 290.08 Q 497.32, 295.18, 506.08, 300.19 Q 514.41,\
                        305.94, 522.86, 311.49 Q 531.35, 316.98, 540.18, 321.88 Q 548.83, 327.08, 557.26, 332.67 Q 566.08, 337.59, 574.38, 343.39\
                        Q 583.27, 348.20, 591.86, 353.52 Q 600.68, 358.44, 610.00, 362.52 Q 618.88, 367.35, 627.17, 373.16 Q 635.48, 378.93, 644.21,\
                        384.01 Q 652.97, 389.03, 662.11, 393.42 Q 670.49, 399.09, 678.82, 404.84 Q 687.76, 409.56, 696.81, 414.10 Q 705.56, 419.14,\
                        714.21, 424.35 Q 722.80, 429.66, 731.47, 434.83 Q 740.11, 440.06, 748.70, 445.38 Q 757.38, 450.55, 766.29, 455.31 Q 775.17,\
                        460.14, 783.21, 466.38 Q 791.47, 472.23, 800.33, 477.09 Q 809.01, 482.26, 818.06, 486.80 Q 826.13, 492.98, 834.94, 497.93\
                        Q 843.85, 502.70, 852.43, 508.03 Q 861.18, 513.06, 869.25, 519.25 Q 878.56, 523.36, 887.43, 528.19 Q 895.94, 533.64, 904.70,\
                        538.66 Q 913.44, 543.72, 921.91, 549.23 Q 931.15, 553.45, 938.69, 560.53 Q 947.71, 565.12, 956.62, 569.90 Q 965.72, 574.35,\
                        974.64, 579.10 Q 983.15, 584.54, 991.47, 590.31 Q 1000.68, 594.57, 1008.92, 600.48 Q 1018.16, 604.70, 1026.98, 609.63 Q 1035.71,\
                        614.71, 1044.31, 619.99 Q 1052.46, 626.05, 1061.12, 631.25 Q 1069.58, 636.76, 1078.39, 641.71 Q 1087.23, 646.60, 1095.86,\
                        651.85 Q 1104.15, 657.67, 1112.66, 663.11 Q 1121.68, 667.70, 1130.19, 673.15 Q 1138.79, 678.43, 1147.15, 684.13 Q 1156.24,\
                        688.60, 1165.14, 693.40 Q 1173.65, 698.84, 1182.28, 704.08 Q 1191.29, 708.69, 1200.12, 713.60 Q 1209.32, 717.88, 1217.91,\
                        723.20 Q 1226.76, 728.07, 1234.98, 734.00 Q 1243.48, 739.46, 1251.80, 745.23 Q 1260.33, 750.64, 1269.14, 755.57 Q 1278.11,\
                        760.26, 1286.50, 765.90 Q 1295.15, 771.11, 1303.41, 776.97 Q 1312.74, 781.04, 1321.50, 786.07 Q 1330.23, 791.14, 1338.82,\
                        796.45 Q 1347.48, 801.65, 1355.91, 807.23 Q 1364.33, 812.83, 1373.00, 818.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 818.00 Q 10.52, 812.55, 18.96, 806.96 Q 27.41, 801.39, 35.81, 795.75\
                        Q 44.46, 790.52, 53.35, 785.69 Q 62.02, 780.49, 70.65, 775.21 Q 79.26, 769.92, 87.89, 764.65 Q 96.72, 759.73, 105.50, 754.71\
                        Q 114.58, 750.21, 122.99, 744.56 Q 131.65, 739.36, 140.36, 734.23 Q 148.95, 728.89, 157.57, 723.61 Q 166.17, 718.29, 174.78,\
                        712.99 Q 183.55, 707.97, 192.47, 703.19 Q 201.03, 697.80, 209.96, 693.05 Q 219.37, 689.09, 227.94, 683.72 Q 236.36, 678.11,\
                        245.14, 673.10 Q 253.79, 667.87, 262.24, 662.30 Q 271.47, 658.04, 279.57, 651.89 Q 288.38, 646.92, 296.90, 641.46 Q 305.69,\
                        636.48, 314.47, 631.46 Q 322.99, 626.01, 331.77, 621.00 Q 340.52, 615.93, 348.95, 610.33 Q 357.59, 605.09, 366.17, 599.73\
                        Q 375.33, 595.36, 384.12, 590.36 Q 392.65, 584.93, 401.23, 579.59 Q 409.86, 574.32, 418.47, 569.01 Q 427.81, 564.95, 436.65,\
                        560.04 Q 445.51, 555.16, 453.88, 549.46 Q 462.06, 543.44, 470.76, 538.29 Q 479.38, 533.01, 488.72, 528.94 Q 497.13, 523.29,\
                        506.23, 518.83 Q 514.55, 513.03, 523.29, 507.96 Q 531.85, 502.58, 541.22, 498.56 Q 549.17, 492.14, 557.65, 486.62 Q 566.32,\
                        481.43, 575.33, 476.80 Q 584.19, 471.92, 592.31, 465.79 Q 601.52, 461.51, 610.10, 456.16 Q 618.73, 450.90, 627.52, 445.90\
                        Q 635.60, 439.71, 644.38, 434.69 Q 652.99, 429.40, 661.88, 424.56 Q 670.74, 419.68, 679.98, 415.46 Q 688.20, 409.49, 696.78,\
                        404.14 Q 705.24, 398.60, 714.03, 393.60 Q 722.38, 387.87, 731.10, 382.75 Q 740.14, 378.17, 749.01, 373.31 Q 758.40, 369.33,\
                        766.35, 362.92 Q 774.76, 357.29, 783.67, 352.48 Q 792.55, 347.64, 801.20, 342.41 Q 809.90, 337.27, 818.83, 332.51 Q 827.12,\
                        326.66, 835.73, 321.37 Q 844.34, 316.07, 853.28, 311.33 Q 861.60, 305.53, 870.28, 300.35 Q 879.00, 295.24, 887.82, 290.30\
                        Q 896.81, 285.64, 905.21, 279.99 Q 913.77, 274.60, 922.49, 269.49 Q 931.17, 264.31, 939.93, 259.25 Q 948.57, 254.01, 957.09,\
                        248.57 Q 966.20, 244.10, 975.55, 240.06 Q 983.91, 234.33, 992.57, 229.11 Q 1001.73, 224.74, 1010.46, 219.64 Q 1018.85, 213.98,\
                        1027.42, 208.61 Q 1035.53, 202.48, 1044.67, 198.06 Q 1053.07, 192.40, 1061.83, 187.36 Q 1070.98, 182.96, 1080.05, 178.44 Q\
                        1088.38, 172.68, 1096.64, 166.79 Q 1105.12, 161.26, 1113.70, 155.92 Q 1122.79, 151.43, 1131.34, 146.02 Q 1140.29, 141.30,\
                        1148.99, 136.16 Q 1157.59, 130.84, 1166.69, 126.36 Q 1175.62, 121.60, 1183.50, 115.09 Q 1192.15, 109.85, 1201.68, 106.10 Q\
                        1210.07, 100.42, 1218.64, 95.06 Q 1226.86, 89.11, 1235.86, 84.46 Q 1244.76, 79.65, 1253.62, 74.78 Q 1261.88, 68.88, 1270.26,\
                        63.20 Q 1278.90, 57.95, 1287.71, 52.99 Q 1295.97, 47.10, 1304.65, 41.92 Q 1313.70, 37.36, 1322.50, 32.38 Q 1331.31, 27.41,\
                        1340.47, 23.05 Q 1349.53, 18.50, 1358.21, 13.32 Q 1366.31, 7.17, 1375.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1145862167" style="position: absolute; left: 170px; top: 0px; width: 970px; height: 120px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1145862167" data-review-reference-id="1145862167">\
            <div class="stencil-wrapper" style="width: 970px; height: 120px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 120px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 120px;width:970px;" width="970" height="120" viewBox="0 0 970 120">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="120" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-626758982" style="position: absolute; left: 455px; top: 15px; width: 410px; height: 48px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="626758982" data-review-reference-id="626758982">\
            <div class="stencil-wrapper" style="width: 410px; height: 48px">\
               <div title="" style="width:415px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 42px;">MONDAY MORNING</span> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-2097632017" style="position: absolute; left: 295px; top: 85px; width: 731px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2097632017" data-review-reference-id="2097632017">\
            <div class="stencil-wrapper" style="width: 731px; height: 37px">\
               <div title="" style="width:736px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">THE OFFICIAL MEDIA BODY OF NIT ROURKELA</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-606679668" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="606679668" data-review-reference-id="606679668">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e191" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e191</title>\
<path class="path1" d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM277.357 531.417q0 6.99 4.926 11.756t11.915 4.846h150.92v152.907q0 6.911 4.846 11.915t11.756 4.926h100.559q6.99 0 11.915-4.926t5.004-11.915v-152.907h150.601q6.911 0 11.915-4.846t4.926-11.756v-100.559q0-6.99-4.926-11.756t-11.915-4.846h-150.601v-150.92q0-6.911-5.004-11.915t-11.915-4.926h-100.559q-6.99 0-11.756 4.926t-4.846 11.915v150.92h-150.92q-6.911 0-11.915 4.846t-4.926 11.756v100.559z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e368" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e368</title>\
<path class="path1" d="M181.008 679.716v-364.035q0-54.969 38.921-93.729t93.491-38.682h364.035q54.969 0 93.729 38.682t38.682 93.729v364.035q0 54.969-38.682 93.65t-93.729 38.762h-364.035q-54.57 0-93.491-38.762t-38.921-93.65zM247.255 712.839q0 13.583 9.77 23.273t23.273 9.77h430.281q13.583 0 23.353-9.77t9.77-23.273v-430.281q0-13.583-9.77-23.353t-23.353-9.77h-430.281q-13.502 0-23.273 9.77t-9.77 23.353v430.281zM345.513 425.852q4.291-10.883 17.554-10.883h264.745q13.264 0 17.554 11.36t-3.972 22.4l-126.375 175.384q-7.944 10.961-19.539 11.756t-19.539-10.089l-126.455-178.086q-8.262-10.883-3.972-21.844z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path class="path1" d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e046" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e046</title>\
<path class="path1" d="M114.842 845.172v-529.492h761.193v529.492q0 13.583-9.77 23.353t-23.273 9.77h-695.028q-13.583 0-23.353-9.77t-9.77-23.353zM114.842 282.557v-99.289q0-13.583 9.77-23.353t23.353-9.77h66.167v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.044q13.583 0 23.353 9.77t9.77 23.353v33.044h364.035v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.124q13.583 0 23.273 9.77t9.77 23.353v33.044h66.246q13.583 0 23.273 9.77t9.77 23.353v99.289h-761.193zM181.008 812.128h99.289v-99.289h-99.289v99.289zM181.008 679.716h99.289v-99.289h-99.289v99.289zM181.008 547.303h99.289v-99.289h-99.289v99.289zM313.421 812.128h99.289v-99.289h-99.289v99.289zM313.421 679.716h99.289v-99.289h-99.289v99.289zM313.421 547.303h99.289v-99.289h-99.289v99.289zM445.833 812.128h99.289v-99.289h-99.289v99.289zM445.833 679.716h99.289v-99.289h-99.289v99.289zM445.833 547.303h99.289v-99.289h-99.289v99.289zM578.167 812.128h99.289v-99.289h-99.289v99.289zM578.167 679.716h99.289v-99.289h-99.289v99.289zM578.167 547.303h99.289v-99.289h-99.289v99.289zM710.579 812.128h99.289v-99.289h-99.289v99.289zM710.579 679.716h99.289v-99.289h-99.289v99.289zM710.579 547.303h99.289v-99.289h-99.289v99.289z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e212" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e212</title>\
<path class="path1" d="M181.008 563.586v-164.821q0-6.674 5.163-11.756t11.756-5.163h280.95v-171.413q0-6.99 3.972-8.817t9.294 2.463l345.208 266.812q5.639 4.291 5.639 10.247t-5.639 10.247l-344.893 267.129q-5.639 3.972-9.612 2.145t-3.972-8.817v-171.413h-280.95q-6.592 0-11.756-5.164t-5.163-11.677z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1475324625" style="position: absolute; left: 170px; top: 120px; width: 970px; height: 60px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1475324625" data-review-reference-id="1475324625">\
            <div class="stencil-wrapper" style="width: 970px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 60px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 60px;width:970px;" width="970" height="60" viewBox="0 0 970 60">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="60" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-526441088" style="position: absolute; left: 240px; top: 135px; width: 52px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="526441088" data-review-reference-id="526441088">\
            <div class="stencil-wrapper" style="width: 52px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:56px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="56" height="34" viewBox="-2 -2 56 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.24, 30.01, 1.11, 28.89 Q 0.74, 27.54, 0.87, 26.04 Q 1.47, 13.93,\
                        1.23, 2.04 Q 2.21, 1.23, 2.42, 0.37 Q 3.06, -0.42, 4.12, -0.61 Q 15.53, -0.82, 27.01, -0.85 Q 38.51, -0.70, 49.83, -0.20 Q\
                        50.95, -0.35, 51.73, 0.30 Q 52.83, 0.75, 53.35, 1.89 Q 52.54, 14.07, 52.68, 25.95 Q 52.55, 27.02, 51.81, 27.83 Q 50.28, 27.55,\
                        49.88, 28.63 Q 38.50, 28.97, 27.01, 29.18 Q 15.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="26" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Home</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 52px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-800258728-layer-526441088\', \'1515095379\', {"button":"left","id":"1616175782","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction592597684","options":"reloadOnly","target":"page353048828","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-800258728-layer-161706072" style="position: absolute; left: 340px; top: 135px; width: 550px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="161706072" data-review-reference-id="161706072">\
            <div class="stencil-wrapper" style="width: 550px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:550px;" width="550" height="30">\
                     <svg:g id="__containerId__-800258728-layer-161706072svg" width="550" height="30"><svg:path id="__containerId__-800258728-layer-161706072_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00\
                        Q 12.11, 0.70, 22.22, 0.61 Q 32.33, 0.73, 42.44, 0.76 Q 52.56, 0.57, 62.67, 1.01 Q 72.78, 0.41, 82.89, 0.81 Q 93.00, 0.74,\
                        103.11, 0.48 Q 113.22, 1.30, 123.33, 1.10 Q 133.44, 0.88, 143.56, 0.71 Q 153.67, 1.00, 163.78, 1.16 Q 173.89, 1.30, 184.00,\
                        1.04 Q 194.11, 0.38, 204.22, 0.85 Q 214.33, 0.93, 224.44, 1.09 Q 234.56, 0.84, 244.67, 0.90 Q 254.78, 0.86, 264.89, 1.33 Q\
                        275.00, 1.79, 285.11, 1.74 Q 295.22, 1.45, 305.33, 1.61 Q 315.44, 1.50, 325.56, 1.08 Q 335.67, 1.00, 345.78, 0.67 Q 355.89,\
                        1.25, 366.00, 0.95 Q 376.11, 1.43, 386.22, 1.05 Q 396.33, 1.24, 406.44, 1.60 Q 416.56, 0.47, 426.67, 0.80 Q 436.78, 0.06,\
                        446.89, 0.36 Q 457.00, 0.53, 467.11, 0.16 Q 477.22, 0.47, 487.33, 0.70 Q 497.44, 0.62, 507.56, 0.50 Q 517.67, 1.26, 527.78,\
                        1.16 Q 537.89, 1.90, 548.04, 1.96 Q 548.03, 14.99, 548.15, 28.15 Q 537.89, 28.02, 527.86, 28.73 Q 517.71, 28.78, 507.56, 28.21\
                        Q 497.45, 28.06, 487.33, 28.20 Q 477.22, 28.71, 467.11, 28.99 Q 457.00, 29.10, 446.89, 29.13 Q 436.78, 29.22, 426.67, 29.28\
                        Q 416.56, 28.46, 406.44, 28.22 Q 396.33, 28.31, 386.22, 28.79 Q 376.11, 28.39, 366.00, 28.12 Q 355.89, 28.08, 345.78, 28.52\
                        Q 335.67, 28.33, 325.56, 27.79 Q 315.44, 28.12, 305.33, 27.96 Q 295.22, 28.81, 285.11, 29.59 Q 275.00, 29.31, 264.89, 29.11\
                        Q 254.78, 29.33, 244.67, 29.74 Q 234.56, 28.96, 224.44, 29.38 Q 214.33, 29.18, 204.22, 29.45 Q 194.11, 29.76, 184.00, 29.95\
                        Q 173.89, 29.16, 163.78, 29.03 Q 153.67, 28.92, 143.56, 28.74 Q 133.44, 29.32, 123.33, 28.99 Q 113.22, 29.57, 103.11, 28.93\
                        Q 93.00, 28.01, 82.89, 28.11 Q 72.78, 28.95, 62.67, 28.95 Q 52.56, 28.25, 42.44, 27.64 Q 32.33, 27.72, 22.22, 27.57 Q 12.11,\
                        27.29, 2.00, 28.00 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-800258728-layer-161706072_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 1.62,\
                        23.15, 1.61 Q 33.22, 1.46, 43.30, 1.93 Q 53.37, 2.13, 63.44, 1.58 Q 73.52, 1.57, 83.59, 2.15 Q 93.67, 2.81, 103.74, 2.89 Q\
                        113.81, 1.94, 123.89, 1.98 Q 133.96, 2.01, 144.04, 1.59 Q 154.11, 2.08, 164.19, 2.61 Q 174.26, 3.38, 184.33, 3.41 Q 194.41,\
                        4.02, 204.48, 4.05 Q 214.56, 2.82, 224.63, 2.64 Q 234.70, 3.27, 244.78, 2.73 Q 254.85, 2.32, 264.93, 2.40 Q 275.00, 2.42,\
                        285.07, 2.23 Q 295.15, 2.42, 305.22, 2.57 Q 315.30, 2.30, 325.37, 2.24 Q 335.44, 1.86, 345.52, 2.03 Q 355.59, 2.54, 365.67,\
                        1.63 Q 375.74, 2.39, 385.81, 3.13 Q 395.89, 3.11, 405.96, 3.75 Q 416.04, 2.94, 426.11, 2.02 Q 436.18, 2.16, 446.26, 2.29 Q\
                        456.33, 2.76, 466.41, 3.11 Q 476.48, 2.80, 486.56, 2.81 Q 496.63, 2.75, 506.70, 1.82 Q 516.78, 2.83, 526.85, 2.03 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-800258728-layer-161706072_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-800258728-layer-161706072_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 0.65,\
                        23.15, 1.35 Q 33.22, 0.83, 43.30, 1.93 Q 53.37, 3.14, 63.44, 1.56 Q 73.52, 1.18, 83.59, 2.67 Q 93.67, 4.04, 103.74, 4.86 Q\
                        113.81, 3.58, 123.89, 2.46 Q 133.96, 2.08, 144.04, 1.44 Q 154.11, 1.46, 164.19, 1.86 Q 174.26, 2.22, 184.33, 2.55 Q 194.41,\
                        3.81, 204.48, 3.60 Q 214.56, 3.75, 224.63, 2.66 Q 234.70, 2.90, 244.78, 2.61 Q 254.85, 3.44, 264.93, 3.17 Q 275.00, 2.29,\
                        285.07, 2.29 Q 295.15, 2.71, 305.22, 2.79 Q 315.30, 1.92, 325.37, 2.76 Q 335.44, 2.76, 345.52, 2.42 Q 355.59, 1.53, 365.67,\
                        1.75 Q 375.74, 2.69, 385.81, 2.75 Q 395.89, 1.98, 405.96, 2.31 Q 416.04, 3.30, 426.11, 3.49 Q 436.18, 3.10, 446.26, 2.25 Q\
                        456.33, 1.92, 466.41, 2.01 Q 476.48, 1.30, 486.56, 1.44 Q 496.63, 2.82, 506.70, 3.88 Q 516.78, 3.38, 526.85, 3.39 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-800258728-layer-161706072_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-800258728-layer-161706072input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-800258728-layer-161706072_input_svg_border\',\'__containerId__-800258728-layer-161706072_line1\',\'__containerId__-800258728-layer-161706072_line2\',\'__containerId__-800258728-layer-161706072_line3\',\'__containerId__-800258728-layer-161706072_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-800258728-layer-161706072_input_svg_border\',\'__containerId__-800258728-layer-161706072_line1\',\'__containerId__-800258728-layer-161706072_line2\',\'__containerId__-800258728-layer-161706072_line3\',\'__containerId__-800258728-layer-161706072_line4\'))" value="Search Box" style="width:543px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1338507132" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1338507132" data-review-reference-id="1338507132">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1294952318" style="position: absolute; left: 0px; top: 778px; width: 1375px; height: 40px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1294952318" data-review-reference-id="1294952318">\
            <div class="stencil-wrapper" style="width: 1375px; height: 40px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 40px; width:1375px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 40px;width:1375px;" width="1375" height="40" viewBox="0 0 1375 40">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="1375" height="40" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-829684012" style="position: absolute; left: 455px; top: 783px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="829684012" data-review-reference-id="829684012">\
            <div class="stencil-wrapper" style="width: 403px; height: 20px">\
               <div title="" style="width:408px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Fixed footer for ASK A QUESTION AND FORUM </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-793386111" style="position: absolute; left: 170px; top: 180px; width: 970px; height: 600px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="793386111" data-review-reference-id="793386111">\
            <div class="stencil-wrapper" style="width: 970px; height: 600px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 600px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 600px;width:970px;" width="970" height="600" viewBox="0 0 970 600">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="600" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1352088888" style="position: absolute; left: 1065px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1352088888" data-review-reference-id="1352088888">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e368-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e368"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1518514962" style="position: absolute; left: 920px; top: 140px; width: 129px; height: 22px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1518514962" data-review-reference-id="1518514962">\
            <div class="stencil-wrapper" style="width: 129px; height: 22px">\
               <div title="" style="width:134px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><strong>Display Name</strong> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-text231941343" style="position: absolute; left: 245px; top: 225px; width: 289px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text231941343" data-review-reference-id="text231941343">\
            <div class="stencil-wrapper" style="width: 289px; height: 37px">\
               <div title="" style="width:294px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Comment Requests</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-rect111811879" style="position: absolute; left: 245px; top: 290px; width: 835px; height: 80px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect111811879" data-review-reference-id="rect111811879">\
            <div class="stencil-wrapper" style="width: 835px; height: 80px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 80px;width:835px;" width="835" height="80">\
                     <svg:g width="835" height="80"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.13, 0.87, 22.27, 0.78 Q 32.40, 0.65, 42.54, 1.20 Q 52.67, 0.87,\
                        62.80, 0.74 Q 72.94, 0.71, 83.07, 1.45 Q 93.21, 1.57, 103.34, 0.56 Q 113.48, 0.79, 123.61, 0.55 Q 133.74, 0.86, 143.88, 1.07\
                        Q 154.01, 1.14, 164.15, 1.67 Q 174.28, 1.87, 184.41, 1.75 Q 194.55, 1.39, 204.68, 0.71 Q 214.82, 1.30, 224.95, 1.06 Q 235.09,\
                        0.94, 245.22, 0.70 Q 255.35, 1.62, 265.49, 1.47 Q 275.62, 1.30, 285.76, 1.72 Q 295.89, 1.09, 306.02, 0.95 Q 316.16, 0.76,\
                        326.29, 0.63 Q 336.43, 0.57, 346.56, 0.42 Q 356.70, 0.90, 366.83, 0.99 Q 376.96, 1.24, 387.10, 1.05 Q 397.23, 0.56, 407.37,\
                        0.17 Q 417.50, 1.08, 427.63, 1.50 Q 437.77, 1.64, 447.90, 0.74 Q 458.04, 1.11, 468.17, 0.51 Q 478.30, 0.31, 488.44, 0.09 Q\
                        498.57, 0.54, 508.71, 2.03 Q 518.84, 2.69, 528.98, 1.48 Q 539.11, 1.04, 549.24, 1.08 Q 559.38, 1.80, 569.51, 1.53 Q 579.65,\
                        1.03, 589.78, 0.58 Q 599.91, 0.90, 610.05, 1.05 Q 620.18, 1.27, 630.32, 0.92 Q 640.45, 0.83, 650.59, 0.35 Q 660.72, 0.32,\
                        670.85, -0.19 Q 680.99, -0.44, 691.12, -0.13 Q 701.26, -0.14, 711.39, 1.31 Q 721.52, 1.31, 731.66, 0.85 Q 741.79, 0.57, 751.93,\
                        0.23 Q 762.06, 0.36, 772.20, 0.32 Q 782.33, 0.82, 792.46, 1.29 Q 802.60, 1.85, 812.73, 1.60 Q 822.87, 1.05, 833.21, 1.79 Q\
                        833.77, 14.41, 833.56, 27.25 Q 833.84, 39.94, 833.07, 52.66 Q 833.26, 65.33, 833.45, 78.45 Q 823.12, 78.75, 812.78, 78.37\
                        Q 802.64, 78.64, 792.50, 79.26 Q 782.34, 78.85, 772.20, 79.08 Q 762.06, 78.33, 751.93, 78.87 Q 741.79, 79.23, 731.66, 78.75\
                        Q 721.52, 77.76, 711.39, 77.30 Q 701.26, 77.76, 691.12, 76.73 Q 680.99, 77.89, 670.85, 78.32 Q 660.72, 78.33, 650.59, 78.50\
                        Q 640.45, 78.74, 630.32, 78.68 Q 620.18, 78.47, 610.05, 78.10 Q 599.91, 77.72, 589.78, 78.82 Q 579.65, 78.33, 569.51, 78.79\
                        Q 559.38, 78.86, 549.24, 79.13 Q 539.11, 78.48, 528.98, 78.34 Q 518.84, 78.70, 508.71, 78.23 Q 498.57, 78.71, 488.44, 77.75\
                        Q 478.30, 77.87, 468.17, 78.38 Q 458.04, 78.81, 447.90, 78.76 Q 437.77, 78.41, 427.63, 78.95 Q 417.50, 78.09, 407.37, 78.88\
                        Q 397.23, 79.20, 387.10, 79.81 Q 376.96, 80.05, 366.83, 80.22 Q 356.70, 79.94, 346.56, 79.46 Q 336.43, 79.59, 326.29, 79.38\
                        Q 316.16, 77.97, 306.02, 77.32 Q 295.89, 77.39, 285.76, 77.83 Q 275.62, 78.07, 265.49, 78.56 Q 255.35, 78.29, 245.22, 78.31\
                        Q 235.09, 77.45, 224.95, 79.21 Q 214.82, 78.82, 204.68, 79.18 Q 194.55, 79.00, 184.41, 79.28 Q 174.28, 78.88, 164.15, 78.84\
                        Q 154.01, 78.69, 143.88, 78.01 Q 133.74, 78.31, 123.61, 78.26 Q 113.48, 78.10, 103.34, 78.45 Q 93.21, 78.62, 83.07, 79.33\
                        Q 72.94, 78.36, 62.80, 78.44 Q 52.67, 79.23, 42.54, 79.23 Q 32.40, 78.90, 22.27, 78.41 Q 12.13, 78.43, 1.63, 78.37 Q 1.65,\
                        65.45, 2.25, 52.63 Q 2.72, 39.95, 1.96, 27.33 Q 2.00, 14.67, 2.00, 2.00" style=" fill:white;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-text456529321" style="position: absolute; left: 290px; top: 315px; width: 445px; height: 41px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text456529321" data-review-reference-id="text456529321">\
            <div class="stencil-wrapper" style="width: 445px; height: 41px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">"Username" had commented on "Article Name" article .<br />Comment: "Content" </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-checkbox570466023" style="position: absolute; left: 830px; top: 325px; width: 67px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox570466023" data-review-reference-id="checkbox570466023">\
            <div class="stencil-wrapper" style="width: 67px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-checkbox570466023_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-checkbox570466023_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-checkbox570466023_input\', \'__containerId__-800258728-layer-checkbox570466023_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-checkbox570466023_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-checkbox570466023_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-checkbox570466023_input\', \'__containerId__-800258728-layer-checkbox570466023_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Accept\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:67px;" width="67" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-checkbox570466023_input\');">\
                        <svg:g id="__containerId__-800258728-layer-checkbox570466023_input_svg" x="0" y="1.0199999999999996" width="67" height="20"><svg:path id="__containerId__-800258728-layer-checkbox570466023_input_svg_border" class=" svg_unselected_element" d="M 5.00,\
                           5.00 Q 10.00, 4.52, 15.02, 4.98 Q 14.62, 10.13, 15.12, 15.12 Q 9.92, 14.70, 5.39, 14.67 Q 5.00, 10.00, 5.00, 5.00" style="\
                           fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-checkbox570466023_input_svgChecked" x="0" y="1.0199999999999996" width="67" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-checkbox972325963" style="position: absolute; left: 945px; top: 325px; width: 63px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="checkbox972325963" data-review-reference-id="checkbox972325963">\
            <div class="stencil-wrapper" style="width: 63px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-checkbox972325963_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-checkbox972325963_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-checkbox972325963_input\', \'__containerId__-800258728-layer-checkbox972325963_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-checkbox972325963_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-checkbox972325963_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-checkbox972325963_input\', \'__containerId__-800258728-layer-checkbox972325963_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Reject\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:63px;" width="63" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-checkbox972325963_input\');">\
                        <svg:g id="__containerId__-800258728-layer-checkbox972325963_input_svg" x="0" y="1.0199999999999996" width="63" height="20"><svg:path id="__containerId__-800258728-layer-checkbox972325963_input_svg_border" class=" svg_unselected_element" d="M 5.00,\
                           5.00 Q 10.00, 6.28, 14.44, 5.56 Q 14.14, 10.29, 14.77, 14.77 Q 9.81, 14.29, 5.31, 14.74 Q 5.00, 10.00, 5.00, 5.00" style="\
                           fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-checkbox972325963_input_svgChecked" x="0" y="1.0199999999999996" width="63" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-218223560" style="position: absolute; left: 245px; top: 385px; width: 835px; height: 80px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="218223560" data-review-reference-id="218223560">\
            <div class="stencil-wrapper" style="width: 835px; height: 80px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 80px;width:835px;" width="835" height="80">\
                     <svg:g width="835" height="80"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.13, 1.62, 22.27, 2.14 Q 32.40, 1.78, 42.54, 2.00 Q 52.67, 0.77,\
                        62.80, 1.50 Q 72.94, 1.00, 83.07, 2.45 Q 93.21, 1.30, 103.34, 1.43 Q 113.48, 2.52, 123.61, 2.37 Q 133.74, 1.85, 143.88, 1.02\
                        Q 154.01, 1.49, 164.15, 2.57 Q 174.28, 2.37, 184.41, 1.22 Q 194.55, 0.26, 204.68, 1.08 Q 214.82, 2.54, 224.95, 2.26 Q 235.09,\
                        2.33, 245.22, 1.98 Q 255.35, 1.87, 265.49, 2.10 Q 275.62, 0.65, 285.76, -0.14 Q 295.89, -0.29, 306.02, -0.35 Q 316.16, 0.22,\
                        326.29, 1.50 Q 336.43, 2.42, 346.56, 2.42 Q 356.70, 2.00, 366.83, 1.47 Q 376.96, 0.76, 387.10, 1.10 Q 397.23, 1.61, 407.37,\
                        1.53 Q 417.50, 1.74, 427.63, 1.80 Q 437.77, 1.92, 447.90, 1.27 Q 458.04, 1.16, 468.17, 0.98 Q 478.30, 0.27, 488.44, 0.52 Q\
                        498.57, 0.37, 508.71, -0.08 Q 518.84, 0.30, 528.98, 1.43 Q 539.11, 0.63, 549.24, 0.83 Q 559.38, 0.96, 569.51, 1.01 Q 579.65,\
                        0.99, 589.78, 0.60 Q 599.91, 0.41, 610.05, 0.05 Q 620.18, 0.29, 630.32, -0.00 Q 640.45, 0.08, 650.59, 0.36 Q 660.72, 1.08,\
                        670.85, 0.96 Q 680.99, 0.93, 691.12, 1.00 Q 701.26, 1.32, 711.39, 1.06 Q 721.52, 1.28, 731.66, 1.23 Q 741.79, 1.53, 751.93,\
                        0.90 Q 762.06, 1.81, 772.20, 2.19 Q 782.33, 2.18, 792.46, 1.71 Q 802.60, 1.25, 812.73, 1.07 Q 822.87, 1.02, 833.64, 1.36 Q\
                        833.72, 14.43, 833.99, 27.19 Q 833.56, 39.96, 833.77, 52.64 Q 834.02, 65.32, 833.84, 78.83 Q 823.34, 79.45, 812.98, 79.79\
                        Q 802.72, 79.81, 792.53, 80.01 Q 782.35, 79.11, 772.21, 79.98 Q 762.07, 79.84, 751.93, 79.30 Q 741.79, 79.58, 731.66, 79.68\
                        Q 721.53, 79.15, 711.39, 79.95 Q 701.26, 79.44, 691.12, 79.47 Q 680.99, 79.01, 670.85, 77.93 Q 660.72, 78.00, 650.59, 79.09\
                        Q 640.45, 78.90, 630.32, 78.98 Q 620.18, 79.11, 610.05, 78.40 Q 599.91, 79.05, 589.78, 78.51 Q 579.65, 78.61, 569.51, 78.29\
                        Q 559.38, 78.42, 549.24, 78.56 Q 539.11, 78.44, 528.98, 78.90 Q 518.84, 78.46, 508.71, 78.77 Q 498.57, 79.39, 488.44, 78.65\
                        Q 478.30, 79.27, 468.17, 79.47 Q 458.04, 79.28, 447.90, 79.27 Q 437.77, 79.47, 427.63, 78.90 Q 417.50, 79.05, 407.37, 77.22\
                        Q 397.23, 77.85, 387.10, 77.88 Q 376.96, 77.83, 366.83, 78.22 Q 356.70, 78.04, 346.56, 78.58 Q 336.43, 78.44, 326.29, 77.97\
                        Q 316.16, 78.88, 306.02, 78.63 Q 295.89, 79.45, 285.76, 78.60 Q 275.62, 78.29, 265.49, 78.62 Q 255.35, 78.94, 245.22, 78.15\
                        Q 235.09, 78.93, 224.95, 79.13 Q 214.82, 78.93, 204.68, 77.51 Q 194.55, 77.20, 184.41, 77.49 Q 174.28, 77.58, 164.15, 77.32\
                        Q 154.01, 76.71, 143.88, 77.31 Q 133.74, 77.26, 123.61, 77.89 Q 113.48, 78.39, 103.34, 78.90 Q 93.21, 78.82, 83.07, 78.87\
                        Q 72.94, 79.22, 62.80, 78.76 Q 52.67, 78.71, 42.54, 78.13 Q 32.40, 78.32, 22.27, 78.47 Q 12.13, 78.38, 1.88, 78.12 Q 1.83,\
                        65.39, 1.56, 52.73 Q 1.89, 40.01, 1.99, 27.33 Q 2.00, 14.67, 2.00, 2.00" style=" fill:white;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1306689989" style="position: absolute; left: 290px; top: 410px; width: 445px; height: 41px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1306689989" data-review-reference-id="1306689989">\
            <div class="stencil-wrapper" style="width: 445px; height: 41px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">"Username" had commented on "Article Name" article .<br />Comment: "Content" </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1638924424" style="position: absolute; left: 830px; top: 420px; width: 67px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1638924424" data-review-reference-id="1638924424">\
            <div class="stencil-wrapper" style="width: 67px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1638924424_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-1638924424_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-1638924424_input\', \'__containerId__-800258728-layer-1638924424_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-1638924424_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-1638924424_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-1638924424_input\', \'__containerId__-800258728-layer-1638924424_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Accept\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:67px;" width="67" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1638924424_input\');">\
                        <svg:g id="__containerId__-800258728-layer-1638924424_input_svg" x="0" y="1.0199999999999996" width="67" height="20"><svg:path id="__containerId__-800258728-layer-1638924424_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00\
                           Q 10.00, 2.65, 16.26, 3.74 Q 16.80, 9.40, 15.97, 15.97 Q 10.31, 16.13, 4.38, 15.52 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-1638924424_input_svgChecked" x="0" y="1.0199999999999996" width="67" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-325455206" style="position: absolute; left: 945px; top: 420px; width: 63px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="325455206" data-review-reference-id="325455206">\
            <div class="stencil-wrapper" style="width: 63px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-325455206_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-325455206_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-325455206_input\', \'__containerId__-800258728-layer-325455206_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-325455206_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-325455206_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-325455206_input\', \'__containerId__-800258728-layer-325455206_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Reject\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:63px;" width="63" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-325455206_input\');">\
                        <svg:g id="__containerId__-800258728-layer-325455206_input_svg" x="0" y="1.0199999999999996" width="63" height="20"><svg:path id="__containerId__-800258728-layer-325455206_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00\
                           Q 10.00, 3.33, 15.88, 4.12 Q 16.43, 9.52, 15.59, 15.59 Q 10.28, 16.03, 4.29, 15.60 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-325455206_input_svgChecked" x="0" y="1.0199999999999996" width="63" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-201063395" style="position: absolute; left: 245px; top: 480px; width: 835px; height: 80px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="201063395" data-review-reference-id="201063395">\
            <div class="stencil-wrapper" style="width: 835px; height: 80px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 80px;width:835px;" width="835" height="80">\
                     <svg:g width="835" height="80"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.13, 2.64, 22.27, 2.35 Q 32.40, 2.02, 42.54, 1.20 Q 52.67, 1.03,\
                        62.80, 1.33 Q 72.94, 1.35, 83.07, 1.39 Q 93.21, 1.14, 103.34, 1.20 Q 113.48, 1.63, 123.61, 1.09 Q 133.74, 1.38, 143.88, 0.78\
                        Q 154.01, 0.55, 164.15, 1.19 Q 174.28, 0.94, 184.41, 1.64 Q 194.55, 0.76, 204.68, 1.34 Q 214.82, 0.43, 224.95, 1.44 Q 235.09,\
                        0.74, 245.22, 0.56 Q 255.35, 0.50, 265.49, 1.47 Q 275.62, 1.68, 285.76, 1.35 Q 295.89, 0.27, 306.02, 0.75 Q 316.16, 1.23,\
                        326.29, 1.56 Q 336.43, 1.96, 346.56, 1.43 Q 356.70, 2.33, 366.83, 2.73 Q 376.96, 1.56, 387.10, 1.56 Q 397.23, 1.64, 407.37,\
                        2.54 Q 417.50, 2.38, 427.63, 0.22 Q 437.77, 1.37, 447.90, 1.32 Q 458.04, 0.87, 468.17, 0.96 Q 478.30, 1.14, 488.44, 1.20 Q\
                        498.57, 1.39, 508.71, 0.37 Q 518.84, 0.66, 528.98, 0.76 Q 539.11, 0.53, 549.24, 0.64 Q 559.38, 1.20, 569.51, 1.12 Q 579.65,\
                        0.31, 589.78, -0.07 Q 599.91, -0.15, 610.05, -0.44 Q 620.18, -0.55, 630.32, -0.47 Q 640.45, -0.41, 650.59, 0.74 Q 660.72,\
                        0.61, 670.85, 1.00 Q 680.99, 0.86, 691.12, 0.32 Q 701.26, 0.44, 711.39, 1.89 Q 721.52, 2.39, 731.66, 2.46 Q 741.79, 1.89,\
                        751.93, 1.14 Q 762.06, 1.57, 772.20, 1.52 Q 782.33, 1.06, 792.46, 0.80 Q 802.60, 0.58, 812.73, 1.74 Q 822.87, 2.80, 833.04,\
                        1.96 Q 834.13, 14.29, 834.76, 27.08 Q 833.86, 39.94, 833.25, 52.66 Q 833.66, 65.32, 833.53, 78.53 Q 823.34, 79.43, 812.98,\
                        79.74 Q 802.65, 78.80, 792.48, 78.61 Q 782.35, 79.09, 772.20, 78.34 Q 762.07, 79.29, 751.93, 78.78 Q 741.79, 78.53, 731.66,\
                        78.81 Q 721.52, 78.84, 711.39, 79.11 Q 701.26, 79.05, 691.12, 78.16 Q 680.99, 78.28, 670.85, 78.60 Q 660.72, 79.07, 650.59,\
                        78.89 Q 640.45, 78.70, 630.32, 78.15 Q 620.18, 77.56, 610.05, 77.12 Q 599.91, 77.25, 589.78, 77.42 Q 579.65, 78.24, 569.51,\
                        78.97 Q 559.38, 79.65, 549.24, 79.55 Q 539.11, 79.82, 528.98, 79.78 Q 518.84, 80.07, 508.71, 80.26 Q 498.57, 79.65, 488.44,\
                        79.88 Q 478.30, 80.18, 468.17, 80.03 Q 458.04, 80.14, 447.90, 79.84 Q 437.77, 79.74, 427.63, 79.47 Q 417.50, 78.36, 407.37,\
                        79.31 Q 397.23, 79.92, 387.10, 80.04 Q 376.96, 80.13, 366.83, 80.18 Q 356.70, 80.04, 346.56, 79.65 Q 336.43, 79.12, 326.29,\
                        79.21 Q 316.16, 79.05, 306.02, 78.69 Q 295.89, 78.77, 285.76, 79.04 Q 275.62, 79.20, 265.49, 79.17 Q 255.35, 79.28, 245.22,\
                        79.45 Q 235.09, 79.13, 224.95, 79.23 Q 214.82, 79.19, 204.68, 78.77 Q 194.55, 79.30, 184.41, 78.95 Q 174.28, 78.97, 164.15,\
                        79.71 Q 154.01, 79.17, 143.88, 79.16 Q 133.74, 78.28, 123.61, 79.37 Q 113.48, 78.97, 103.34, 78.43 Q 93.21, 77.63, 83.07,\
                        77.27 Q 72.94, 77.26, 62.80, 77.30 Q 52.67, 77.74, 42.54, 78.77 Q 32.40, 79.36, 22.27, 79.61 Q 12.13, 79.51, 1.64, 78.36 Q\
                        1.96, 65.35, 2.30, 52.62 Q 3.20, 39.92, 1.58, 27.35 Q 2.00, 14.67, 2.00, 2.00" style=" fill:white;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-167873585" style="position: absolute; left: 290px; top: 505px; width: 445px; height: 41px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="167873585" data-review-reference-id="167873585">\
            <div class="stencil-wrapper" style="width: 445px; height: 41px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">"Username" had commented on "Article Name" article .<br />Comment: "Content" </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1668546472" style="position: absolute; left: 830px; top: 515px; width: 67px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1668546472" data-review-reference-id="1668546472">\
            <div class="stencil-wrapper" style="width: 67px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1668546472_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-1668546472_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-1668546472_input\', \'__containerId__-800258728-layer-1668546472_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-1668546472_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-1668546472_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-1668546472_input\', \'__containerId__-800258728-layer-1668546472_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Accept\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:67px;" width="67" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1668546472_input\');">\
                        <svg:g id="__containerId__-800258728-layer-1668546472_input_svg" x="0" y="1.0199999999999996" width="67" height="20"><svg:path id="__containerId__-800258728-layer-1668546472_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00\
                           Q 10.00, 2.48, 16.31, 3.69 Q 16.71, 9.43, 15.81, 15.81 Q 10.33, 16.23, 4.22, 15.66 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-1668546472_input_svgChecked" x="0" y="1.0199999999999996" width="67" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-378181348" style="position: absolute; left: 945px; top: 515px; width: 63px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="378181348" data-review-reference-id="378181348">\
            <div class="stencil-wrapper" style="width: 63px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-378181348_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-378181348_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-378181348_input\', \'__containerId__-800258728-layer-378181348_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-378181348_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-378181348_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-378181348_input\', \'__containerId__-800258728-layer-378181348_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Reject\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:63px;" width="63" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-378181348_input\');">\
                        <svg:g id="__containerId__-800258728-layer-378181348_input_svg" x="0" y="1.0199999999999996" width="63" height="20"><svg:path id="__containerId__-800258728-layer-378181348_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00\
                           Q 10.00, 4.58, 15.38, 4.62 Q 15.44, 9.85, 15.47, 15.47 Q 10.01, 15.03, 4.90, 15.08 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-378181348_input_svgChecked" x="0" y="1.0199999999999996" width="63" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1640962879" style="position: absolute; left: 250px; top: 585px; width: 835px; height: 80px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="1640962879" data-review-reference-id="1640962879">\
            <div class="stencil-wrapper" style="width: 835px; height: 80px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 80px;width:835px;" width="835" height="80">\
                     <svg:g width="835" height="80"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.13, 0.95, 22.27, 0.77 Q 32.40, 1.00, 42.54, 1.23 Q 52.67, 1.28,\
                        62.80, 1.33 Q 72.94, 1.21, 83.07, 1.69 Q 93.21, 1.13, 103.34, 1.53 Q 113.48, 1.92, 123.61, 2.11 Q 133.74, 1.58, 143.88, 2.25\
                        Q 154.01, 2.75, 164.15, 2.87 Q 174.28, 2.50, 184.41, 1.36 Q 194.55, 1.20, 204.68, 1.57 Q 214.82, 2.14, 224.95, 2.22 Q 235.09,\
                        2.05, 245.22, 2.67 Q 255.35, 1.94, 265.49, 2.25 Q 275.62, 1.74, 285.76, 2.49 Q 295.89, 2.67, 306.02, 2.38 Q 316.16, 2.32,\
                        326.29, 2.88 Q 336.43, 2.53, 346.56, 1.68 Q 356.70, 1.11, 366.83, 0.25 Q 376.96, 0.63, 387.10, 0.24 Q 397.23, 0.53, 407.37,\
                        1.25 Q 417.50, 1.58, 427.63, 2.21 Q 437.77, 1.03, 447.90, 1.51 Q 458.04, 0.67, 468.17, 1.48 Q 478.30, 2.59, 488.44, 2.78 Q\
                        498.57, 1.91, 508.71, 1.78 Q 518.84, 2.21, 528.98, 2.05 Q 539.11, 2.29, 549.24, 1.53 Q 559.38, 1.80, 569.51, 2.06 Q 579.65,\
                        2.07, 589.78, 2.13 Q 599.91, 1.84, 610.05, 2.53 Q 620.18, 2.57, 630.32, 2.96 Q 640.45, 1.71, 650.59, 3.05 Q 660.72, 2.93,\
                        670.85, 1.50 Q 680.99, 0.69, 691.12, 0.47 Q 701.26, 1.35, 711.39, 1.15 Q 721.52, 0.51, 731.66, 0.33 Q 741.79, 0.61, 751.93,\
                        0.98 Q 762.06, 0.80, 772.20, 0.98 Q 782.33, 0.81, 792.46, 0.78 Q 802.60, 0.69, 812.73, 1.35 Q 822.87, 0.74, 833.18, 1.82 Q\
                        832.95, 14.68, 832.57, 27.40 Q 833.38, 39.97, 834.30, 52.62 Q 833.49, 65.33, 833.10, 78.10 Q 822.92, 78.17, 812.83, 78.69\
                        Q 802.65, 78.85, 792.48, 78.48 Q 782.33, 78.30, 772.19, 77.81 Q 762.06, 77.67, 751.93, 77.04 Q 741.79, 77.05, 731.66, 77.58\
                        Q 721.52, 78.70, 711.39, 78.46 Q 701.26, 77.99, 691.12, 78.42 Q 680.99, 78.98, 670.85, 78.93 Q 660.72, 77.68, 650.59, 77.49\
                        Q 640.45, 78.27, 630.32, 78.78 Q 620.18, 79.32, 610.05, 79.24 Q 599.91, 79.54, 589.78, 79.28 Q 579.65, 79.07, 569.51, 78.68\
                        Q 559.38, 79.58, 549.24, 79.68 Q 539.11, 79.64, 528.98, 79.68 Q 518.84, 79.66, 508.71, 78.38 Q 498.57, 78.21, 488.44, 77.73\
                        Q 478.30, 77.25, 468.17, 76.63 Q 458.04, 77.28, 447.90, 78.31 Q 437.77, 78.31, 427.63, 77.55 Q 417.50, 77.74, 407.37, 78.36\
                        Q 397.23, 79.47, 387.10, 79.99 Q 376.96, 80.04, 366.83, 80.12 Q 356.70, 79.92, 346.56, 79.89 Q 336.43, 79.53, 326.29, 79.43\
                        Q 316.16, 79.47, 306.02, 79.64 Q 295.89, 79.85, 285.76, 80.02 Q 275.62, 78.93, 265.49, 79.24 Q 255.35, 79.76, 245.22, 79.90\
                        Q 235.09, 79.96, 224.95, 79.87 Q 214.82, 79.60, 204.68, 79.32 Q 194.55, 78.68, 184.41, 78.15 Q 174.28, 78.84, 164.15, 78.58\
                        Q 154.01, 78.45, 143.88, 78.44 Q 133.74, 79.10, 123.61, 78.90 Q 113.48, 78.27, 103.34, 77.97 Q 93.21, 78.88, 83.07, 79.10\
                        Q 72.94, 78.70, 62.80, 78.36 Q 52.67, 78.52, 42.54, 78.07 Q 32.40, 77.73, 22.27, 77.35 Q 12.13, 77.27, 2.11, 77.89 Q 1.13,\
                        65.62, 1.02, 52.81 Q 0.84, 40.08, 1.04, 27.36 Q 2.00, 14.67, 2.00, 2.00" style=" fill:white;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-591884403" style="position: absolute; left: 295px; top: 610px; width: 445px; height: 41px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="591884403" data-review-reference-id="591884403">\
            <div class="stencil-wrapper" style="width: 445px; height: 41px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">"Username" had commented on "Article Name" article .<br />Comment: "Content" </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-538530977" style="position: absolute; left: 835px; top: 620px; width: 67px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="538530977" data-review-reference-id="538530977">\
            <div class="stencil-wrapper" style="width: 67px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-538530977_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-538530977_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-538530977_input\', \'__containerId__-800258728-layer-538530977_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-538530977_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-538530977_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-538530977_input\', \'__containerId__-800258728-layer-538530977_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Accept\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:67px;" width="67" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-538530977_input\');">\
                        <svg:g id="__containerId__-800258728-layer-538530977_input_svg" x="0" y="1.0199999999999996" width="67" height="20"><svg:path id="__containerId__-800258728-layer-538530977_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00\
                           Q 10.00, 4.62, 15.63, 4.37 Q 16.25, 9.58, 15.46, 15.46 Q 10.15, 15.56, 4.68, 15.27 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-538530977_input_svgChecked" x="0" y="1.0199999999999996" width="67" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1402352241" style="position: absolute; left: 950px; top: 620px; width: 63px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1402352241" data-review-reference-id="1402352241">\
            <div class="stencil-wrapper" style="width: 63px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1402352241_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-1402352241_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-1402352241_input\', \'__containerId__-800258728-layer-1402352241_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-1402352241_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-1402352241_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-1402352241_input\', \'__containerId__-800258728-layer-1402352241_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Reject\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:63px;" width="63" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1402352241_input\');">\
                        <svg:g id="__containerId__-800258728-layer-1402352241_input_svg" x="0" y="1.0199999999999996" width="63" height="20"><svg:path id="__containerId__-800258728-layer-1402352241_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00\
                           Q 10.00, 3.64, 15.76, 4.24 Q 16.09, 9.64, 15.49, 15.49 Q 10.12, 15.43, 4.52, 15.41 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-1402352241_input_svgChecked" x="0" y="1.0199999999999996" width="63" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-566331016" style="position: absolute; left: 250px; top: 685px; width: 835px; height: 80px" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="566331016" data-review-reference-id="566331016">\
            <div class="stencil-wrapper" style="width: 835px; height: 80px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 80px;width:835px;" width="835" height="80">\
                     <svg:g width="835" height="80"><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.13, 1.94, 22.27, 1.74 Q 32.40, 1.87, 42.54, 2.32 Q 52.67, 1.92,\
                        62.80, 1.84 Q 72.94, 2.00, 83.07, 1.75 Q 93.21, 1.97, 103.34, 1.66 Q 113.48, 1.22, 123.61, 1.80 Q 133.74, 2.24, 143.88, 2.12\
                        Q 154.01, 1.57, 164.15, 2.51 Q 174.28, 2.76, 184.41, 2.75 Q 194.55, 1.94, 204.68, 1.95 Q 214.82, 1.07, 224.95, 1.70 Q 235.09,\
                        1.56, 245.22, 1.79 Q 255.35, 2.16, 265.49, 1.93 Q 275.62, 2.56, 285.76, 2.03 Q 295.89, 1.53, 306.02, 1.47 Q 316.16, 1.75,\
                        326.29, 2.63 Q 336.43, 2.17, 346.56, 2.71 Q 356.70, 1.62, 366.83, 1.50 Q 376.96, 0.66, 387.10, 1.31 Q 397.23, 1.63, 407.37,\
                        2.12 Q 417.50, 1.26, 427.63, 0.55 Q 437.77, 0.86, 447.90, 1.35 Q 458.04, 1.74, 468.17, 1.09 Q 478.30, 1.25, 488.44, 2.08 Q\
                        498.57, 2.72, 508.71, 2.80 Q 518.84, 2.11, 528.98, 1.86 Q 539.11, 2.51, 549.24, 2.60 Q 559.38, 1.76, 569.51, 2.12 Q 579.65,\
                        1.44, 589.78, 1.61 Q 599.91, 1.90, 610.05, 1.47 Q 620.18, 1.14, 630.32, 1.98 Q 640.45, 3.52, 650.59, 3.35 Q 660.72, 3.63,\
                        670.85, 2.49 Q 680.99, 1.86, 691.12, 3.50 Q 701.26, 2.51, 711.39, 2.29 Q 721.52, 2.14, 731.66, 1.66 Q 741.79, 0.86, 751.93,\
                        0.29 Q 762.06, 0.55, 772.20, 1.14 Q 782.33, 1.92, 792.46, 1.39 Q 802.60, 1.87, 812.73, 1.49 Q 822.87, 1.50, 833.56, 1.44 Q\
                        833.75, 14.42, 834.18, 27.16 Q 834.19, 39.92, 833.86, 52.64 Q 833.74, 65.32, 833.26, 78.26 Q 822.91, 78.14, 812.77, 78.30\
                        Q 802.66, 78.98, 792.50, 79.11 Q 782.35, 79.15, 772.20, 78.92 Q 762.07, 79.05, 751.93, 78.14 Q 741.79, 77.54, 731.66, 77.25\
                        Q 721.52, 76.66, 711.39, 76.49 Q 701.26, 76.01, 691.12, 77.38 Q 680.99, 77.46, 670.85, 77.99 Q 660.72, 78.57, 650.59, 78.42\
                        Q 640.45, 77.42, 630.32, 78.20 Q 620.18, 78.64, 610.05, 78.75 Q 599.91, 78.12, 589.78, 77.84 Q 579.65, 78.62, 569.51, 78.57\
                        Q 559.38, 78.91, 549.24, 79.14 Q 539.11, 78.37, 528.98, 79.03 Q 518.84, 78.99, 508.71, 78.62 Q 498.57, 78.21, 488.44, 78.70\
                        Q 478.30, 79.46, 468.17, 79.47 Q 458.04, 78.93, 447.90, 78.24 Q 437.77, 77.97, 427.63, 78.29 Q 417.50, 77.02, 407.37, 77.20\
                        Q 397.23, 77.80, 387.10, 78.41 Q 376.96, 80.09, 366.83, 79.41 Q 356.70, 78.31, 346.56, 77.25 Q 336.43, 76.73, 326.29, 77.50\
                        Q 316.16, 76.81, 306.02, 77.59 Q 295.89, 78.18, 285.76, 79.24 Q 275.62, 80.03, 265.49, 79.87 Q 255.35, 79.91, 245.22, 80.10\
                        Q 235.09, 80.21, 224.95, 80.42 Q 214.82, 80.54, 204.68, 80.59 Q 194.55, 80.06, 184.41, 79.91 Q 174.28, 79.38, 164.15, 78.73\
                        Q 154.01, 79.05, 143.88, 79.38 Q 133.74, 78.89, 123.61, 78.70 Q 113.48, 78.32, 103.34, 78.72 Q 93.21, 79.02, 83.07, 78.62\
                        Q 72.94, 78.76, 62.80, 79.05 Q 52.67, 78.98, 42.54, 78.21 Q 32.40, 78.32, 22.27, 78.82 Q 12.13, 79.03, 1.48, 78.52 Q 1.15,\
                        65.62, 0.93, 52.82 Q 0.64, 40.09, 0.57, 27.38 Q 2.00, 14.67, 2.00, 2.00" style=" fill:white;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1647174840" style="position: absolute; left: 295px; top: 710px; width: 445px; height: 41px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1647174840" data-review-reference-id="1647174840">\
            <div class="stencil-wrapper" style="width: 445px; height: 41px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">"Username" had commented on "Article Name" article .<br />Comment: "Content" </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1318991527" style="position: absolute; left: 835px; top: 720px; width: 67px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1318991527" data-review-reference-id="1318991527">\
            <div class="stencil-wrapper" style="width: 67px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1318991527_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-1318991527_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-1318991527_input\', \'__containerId__-800258728-layer-1318991527_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-1318991527_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-1318991527_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-1318991527_input\', \'__containerId__-800258728-layer-1318991527_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Accept\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:67px;" width="67" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1318991527_input\');">\
                        <svg:g id="__containerId__-800258728-layer-1318991527_input_svg" x="0" y="1.0199999999999996" width="67" height="20"><svg:path id="__containerId__-800258728-layer-1318991527_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00\
                           Q 10.00, 4.71, 15.27, 4.73 Q 15.64, 9.79, 15.30, 15.30 Q 10.16, 15.58, 4.73, 15.23 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-1318991527_input_svgChecked" x="0" y="1.0199999999999996" width="67" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-1158314969" style="position: absolute; left: 950px; top: 720px; width: 63px; height: 20px" data-interactive-element-type="default.checkbox" class="checkbox stencil mobile-interaction-potential-trigger " data-stencil-id="1158314969" data-review-reference-id="1158314969">\
            <div class="stencil-wrapper" style="width: 63px; height: 20px">\
               <div class="" style="font-size:1.17em;">\
                  <div xml:space="preserve" title="" style="position:absolute" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1158314969_input\');">\
                     \
                     				\
                     <nobr>\
                        					<input id="__containerId__-800258728-layer-1158314969_input" xml:space="default" class="hidden_class" style="padding-right:9px" type="checkbox" onpropertychange="rabbit.facade.raiseEvent(rabbit.events.propertyChange, \'__containerId__-800258728-layer-1158314969_input\', \'__containerId__-800258728-layer-1158314969_input_svgChecked\');" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'__containerId__-800258728-layer-1158314969_input_svg_border\');" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, \'__containerId__-800258728-layer-1158314969_input_svg_border\');" onclick="rabbit.facade.raiseEvent(rabbit.events.checkBoxClicked, \'__containerId__-800258728-layer-1158314969_input\', \'__containerId__-800258728-layer-1158314969_input_svgChecked\');" checked="true">rabbit.facade.raiseEvent(rabbit.events.svgBlur, \'{$id}_input_svg_border\');</input>\
                        				\
                        					\
                        					\
                        						Reject\
                        						\
                        					\
                        				\
                     </nobr>\
                     			\
                  </div>\
                  <div title="">\
                     <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; height: 20px;width:63px;" width="63" height="20" onclick="rabbit.facade.fireMouseOn(\'__containerId__-800258728-layer-1158314969_input\');">\
                        <svg:g id="__containerId__-800258728-layer-1158314969_input_svg" x="0" y="1.0199999999999996" width="63" height="20"><svg:path id="__containerId__-800258728-layer-1158314969_input_svg_border" class=" svg_unselected_element" d="M 5.00, 5.00\
                           Q 10.00, 6.00, 14.51, 5.49 Q 14.84, 10.05, 14.58, 14.58 Q 10.00, 15.02, 4.84, 15.13 Q 5.00, 10.00, 5.00, 5.00" style=" fill:white;"/>\
                        </svg:g>\
                        <svg:g id="__containerId__-800258728-layer-1158314969_input_svgChecked" x="0" y="1.0199999999999996" width="63" height="20" visibility="inherit"><svg:path class=" svg_unselected_element" d="M 5.00, 9.00 Q 8.00, 12.00, 11.00, 15.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 11.00, 15.00 Q 15.50, 7.00, 20.00, -1.00" style=" fill:none;"/></svg:g>\
                     </svg:svg>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-800258728-layer-2141164884" style="position: absolute; left: 175px; top: 15px; width: 95px; height: 80px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="2141164884" data-review-reference-id="2141164884">\
            <div class="stencil-wrapper" style="width: 95px; height: 80px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 80px;width:95px;" width="95" height="80">\
                     <svg:g width="95" height="80"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.38, 1.16, 24.75, 0.86 Q 36.12, 0.72, 47.50, 0.51 Q\
                        58.88, 0.49, 70.25, 0.22 Q 81.62, 0.39, 93.87, 1.13 Q 94.34, 14.22, 94.60, 27.10 Q 94.90, 39.87, 94.93, 52.60 Q 94.52, 65.31,\
                        93.44, 78.44 Q 81.92, 78.91, 70.42, 79.22 Q 58.94, 79.03, 47.54, 79.11 Q 36.15, 79.48, 24.76, 79.41 Q 13.38, 79.71, 1.25,\
                        78.75 Q 0.67, 65.77, 0.57, 52.87 Q 0.52, 40.10, 0.98, 27.37 Q 2.00, 14.67, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.47, 9.16, 19.93, 17.52 Q 28.72, 25.50, 37.51, 33.46 Q 47.71,\
                        39.75, 56.55, 47.66 Q 65.42, 55.53, 74.25, 63.46 Q 83.90, 70.40, 93.00, 78.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 78.00 Q 9.01, 70.77, 17.18, 64.94 Q 25.41, 59.20, 33.25, 52.97 Q 40.91,\
                        46.53, 49.10, 40.74 Q 56.54, 34.03, 64.53, 27.99 Q 71.92, 21.21, 79.65, 14.85 Q 87.25, 8.33, 95.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="800258728"] .border-wrapper, body[data-current-page-id="800258728"] .simulation-container{\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="800258728"] .border-wrapper, body.has-frame[data-current-page-id="800258728"] .simulation-container{\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="800258728"] .svg-border-1366-768{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="800258728"] .border-wrapper .border-div{\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "800258728",\
      			"name": "Comments approval",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
   <div id="border-wrapper">\
      <div xmlns="http://www.w3.org/1999/xhtml" xmlns:json="http://json.org/" class="svg-border svg-border-1366-768" style="display: none;">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="svg_border" style="position:absolute;left:-43px;top:-13px;width:1423px;height:792px;"><svg:path class=" svg_unselected_element" d="M 32.00, 3.00 Q 42.12, 2.52, 52.24, 3.37 Q 62.35, 3.74, 72.47, 3.42 Q 82.59,\
            3.34, 92.71, 3.60 Q 102.82, 3.16, 112.94, 3.93 Q 123.06, 4.07, 133.18, 4.35 Q 143.29, 3.03, 153.41, 3.86 Q 163.53, 2.35, 173.65,\
            2.35 Q 183.76, 2.76, 193.88, 2.37 Q 204.00, 2.15, 214.12, 2.45 Q 224.24, 2.84, 234.35, 2.83 Q 244.47, 1.32, 254.59, 1.60 Q\
            264.71, 2.44, 274.82, 3.26 Q 284.94, 2.51, 295.06, 2.35 Q 305.18, 2.42, 315.29, 3.05 Q 325.41, 2.55, 335.53, 3.40 Q 345.65,\
            2.24, 355.76, 1.94 Q 365.88, 1.82, 376.00, 1.43 Q 386.12, 1.26, 396.24, 1.97 Q 406.35, 2.37, 416.47, 2.50 Q 426.59, 2.87,\
            436.71, 2.85 Q 446.82, 2.55, 456.94, 1.42 Q 467.06, 0.84, 477.18, 1.67 Q 487.29, 2.65, 497.41, 2.18 Q 507.53, 3.24, 517.65,\
            3.36 Q 527.76, 2.48, 537.88, 1.71 Q 548.00, 1.56, 558.12, 1.37 Q 568.24, 1.17, 578.35, 1.35 Q 588.47, 1.83, 598.59, 2.59 Q\
            608.71, 3.08, 618.82, 1.79 Q 628.94, 2.76, 639.06, 3.58 Q 649.18, 2.71, 659.29, 1.81 Q 669.41, 1.50, 679.53, 1.40 Q 689.65,\
            1.37, 699.77, 1.29 Q 709.88, 1.06, 720.00, 1.09 Q 730.12, 1.66, 740.24, 1.51 Q 750.35, 1.27, 760.47, 1.94 Q 770.59, 2.09,\
            780.71, 1.59 Q 790.82, 1.48, 800.94, 1.32 Q 811.06, 1.37, 821.18, 1.66 Q 831.29, 2.03, 841.41, 1.80 Q 851.53, 2.30, 861.65,\
            1.98 Q 871.77, 1.41, 881.88, 0.75 Q 892.00, 0.80, 902.12, 0.68 Q 912.24, 1.51, 922.35, 3.01 Q 932.47, 3.85, 942.59, 3.97 Q\
            952.71, 2.62, 962.82, 1.12 Q 972.94, 0.96, 983.06, 1.18 Q 993.18, 2.25, 1003.30, 2.51 Q 1013.41, 3.14, 1023.53, 2.78 Q 1033.65,\
            2.60, 1043.77, 2.30 Q 1053.88, 2.26, 1064.00, 1.84 Q 1074.12, 1.77, 1084.24, 1.80 Q 1094.35, 1.93, 1104.47, 2.02 Q 1114.59,\
            2.27, 1124.71, 1.11 Q 1134.83, 1.06, 1144.94, 1.01 Q 1155.06, 0.96, 1165.18, 1.38 Q 1175.30, 2.59, 1185.41, 2.36 Q 1195.53,\
            1.69, 1205.65, 1.19 Q 1215.77, 1.66, 1225.88, 2.59 Q 1236.00, 2.75, 1246.12, 3.17 Q 1256.24, 2.11, 1266.35, 2.35 Q 1276.47,\
            2.51, 1286.59, 1.97 Q 1296.71, 1.98, 1306.83, 1.75 Q 1316.94, 1.95, 1327.06, 1.66 Q 1337.18, 1.39, 1347.30, 1.37 Q 1357.41,\
            1.22, 1367.53, 1.71 Q 1377.65, 1.19, 1387.77, 1.42 Q 1397.88, 1.62, 1408.83, 2.18 Q 1409.13, 12.79, 1408.72, 23.24 Q 1409.31,\
            33.43, 1408.77, 43.66 Q 1409.10, 53.84, 1409.13, 64.02 Q 1408.84, 74.19, 1408.30, 84.37 Q 1408.40, 94.54, 1408.15, 104.71\
            Q 1408.27, 114.88, 1408.94, 125.05 Q 1408.20, 135.22, 1408.78, 145.39 Q 1408.34, 155.57, 1409.00, 165.74 Q 1408.93, 175.91,\
            1408.68, 186.08 Q 1408.51, 196.25, 1407.72, 206.42 Q 1409.09, 216.59, 1407.67, 226.76 Q 1408.79, 236.93, 1408.13, 247.11 Q\
            1407.97, 257.28, 1407.69, 267.45 Q 1408.01, 277.62, 1408.53, 287.79 Q 1408.72, 297.96, 1409.16, 308.13 Q 1408.74, 318.30,\
            1409.75, 328.47 Q 1409.50, 338.64, 1409.38, 348.82 Q 1409.40, 358.99, 1409.76, 369.16 Q 1409.28, 379.33, 1408.77, 389.50 Q\
            1409.81, 399.67, 1409.02, 409.84 Q 1409.64, 420.01, 1408.93, 430.18 Q 1408.32, 440.36, 1408.62, 450.53 Q 1408.66, 460.70,\
            1408.79, 470.87 Q 1408.71, 481.04, 1410.19, 491.21 Q 1410.04, 501.38, 1408.66, 511.55 Q 1408.86, 521.72, 1409.23, 531.89 Q\
            1409.05, 542.07, 1408.67, 552.24 Q 1408.36, 562.41, 1408.77, 572.58 Q 1408.94, 582.75, 1408.69, 592.92 Q 1409.68, 603.09,\
            1409.70, 613.26 Q 1409.71, 623.43, 1409.84, 633.61 Q 1408.95, 643.78, 1409.68, 653.95 Q 1409.75, 664.12, 1409.79, 674.29 Q\
            1409.91, 684.46, 1409.89, 694.63 Q 1409.25, 704.80, 1408.83, 714.97 Q 1408.47, 725.15, 1408.03, 735.32 Q 1407.72, 745.49,\
            1408.38, 755.66 Q 1408.56, 765.83, 1408.12, 776.12 Q 1398.08, 776.58, 1387.76, 775.97 Q 1377.70, 776.72, 1367.56, 777.00 Q\
            1357.43, 777.05, 1347.31, 777.21 Q 1337.18, 777.25, 1327.06, 777.22 Q 1316.94, 777.45, 1306.83, 777.55 Q 1296.71, 776.21,\
            1286.59, 777.02 Q 1276.47, 776.97, 1266.35, 776.54 Q 1256.24, 776.87, 1246.12, 777.17 Q 1236.00, 777.21, 1225.88, 777.43 Q\
            1215.77, 777.26, 1205.65, 777.31 Q 1195.53, 777.43, 1185.41, 777.15 Q 1175.30, 776.57, 1165.18, 775.89 Q 1155.06, 775.52,\
            1144.94, 776.40 Q 1134.83, 775.96, 1124.71, 776.16 Q 1114.59, 776.65, 1104.47, 776.49 Q 1094.35, 775.24, 1084.24, 775.00 Q\
            1074.12, 775.13, 1064.00, 775.36 Q 1053.88, 775.91, 1043.77, 776.94 Q 1033.65, 775.92, 1023.53, 776.62 Q 1013.41, 776.34,\
            1003.30, 776.77 Q 993.18, 776.33, 983.06, 776.28 Q 972.94, 775.97, 962.82, 776.63 Q 952.71, 777.11, 942.59, 777.40 Q 932.47,\
            777.35, 922.35, 777.33 Q 912.24, 777.05, 902.12, 777.96 Q 892.00, 777.96, 881.88, 777.36 Q 871.77, 777.42, 861.65, 777.37\
            Q 851.53, 777.18, 841.41, 777.29 Q 831.29, 777.14, 821.18, 776.54 Q 811.06, 776.10, 800.94, 777.74 Q 790.82, 776.78, 780.71,\
            776.70 Q 770.59, 776.11, 760.47, 776.15 Q 750.35, 776.19, 740.24, 777.03 Q 730.12, 776.55, 720.00, 776.15 Q 709.88, 776.38,\
            699.77, 776.33 Q 689.65, 776.45, 679.53, 776.46 Q 669.41, 776.58, 659.29, 776.44 Q 649.18, 776.35, 639.06, 776.24 Q 628.94,\
            775.86, 618.82, 776.19 Q 608.71, 776.16, 598.59, 776.62 Q 588.47, 776.07, 578.35, 776.86 Q 568.24, 777.41, 558.12, 777.54\
            Q 548.00, 776.20, 537.88, 776.24 Q 527.76, 776.82, 517.65, 777.17 Q 507.53, 776.80, 497.41, 776.51 Q 487.29, 776.78, 477.18,\
            777.21 Q 467.06, 777.31, 456.94, 777.18 Q 446.82, 776.97, 436.71, 776.89 Q 426.59, 777.21, 416.47, 776.75 Q 406.35, 775.00,\
            396.24, 775.68 Q 386.12, 776.74, 376.00, 777.30 Q 365.88, 775.89, 355.76, 775.29 Q 345.65, 775.90, 335.53, 776.33 Q 325.41,\
            776.09, 315.29, 775.52 Q 305.18, 774.71, 295.06, 775.36 Q 284.94, 775.65, 274.82, 774.90 Q 264.71, 774.74, 254.59, 774.71\
            Q 244.47, 775.50, 234.35, 775.71 Q 224.24, 776.00, 214.12, 775.89 Q 204.00, 776.74, 193.88, 776.65 Q 183.76, 775.83, 173.65,\
            775.58 Q 163.53, 776.13, 153.41, 776.97 Q 143.29, 776.83, 133.18, 776.33 Q 123.06, 775.88, 112.94, 776.65 Q 102.82, 776.05,\
            92.71, 776.70 Q 82.59, 777.25, 72.47, 776.49 Q 62.35, 777.47, 52.24, 775.77 Q 42.12, 775.96, 32.27, 775.73 Q 31.43, 766.02,\
            30.99, 755.80 Q 31.99, 745.49, 32.15, 735.31 Q 33.14, 725.13, 31.78, 714.98 Q 32.57, 704.80, 32.63, 694.63 Q 33.39, 684.46,\
            32.58, 674.29 Q 31.21, 664.12, 31.75, 653.95 Q 32.10, 643.78, 32.74, 633.61 Q 30.89, 623.43, 32.31, 613.26 Q 32.52, 603.09,\
            32.32, 592.92 Q 31.26, 582.75, 29.83, 572.58 Q 30.40, 562.41, 30.03, 552.24 Q 30.85, 542.07, 32.15, 531.89 Q 32.33, 521.72,\
            30.83, 511.55 Q 30.14, 501.38, 30.26, 491.21 Q 30.82, 481.04, 31.06, 470.87 Q 30.93, 460.70, 31.55, 450.53 Q 31.52, 440.36,\
            31.89, 430.18 Q 31.74, 420.01, 31.53, 409.84 Q 31.19, 399.67, 31.34, 389.50 Q 32.50, 379.33, 31.64, 369.16 Q 31.55, 358.99,\
            30.17, 348.82 Q 30.17, 338.64, 30.03, 328.47 Q 30.02, 318.30, 30.04, 308.13 Q 30.16, 297.96, 30.09, 287.79 Q 30.40, 277.62,\
            31.35, 267.45 Q 30.37, 257.28, 30.15, 247.11 Q 30.42, 236.93, 30.64, 226.76 Q 30.61, 216.59, 30.51, 206.42 Q 30.69, 196.25,\
            30.54, 186.08 Q 30.53, 175.91, 29.88, 165.74 Q 30.43, 155.57, 31.03, 145.39 Q 30.98, 135.22, 31.17, 125.05 Q 31.30, 114.88,\
            30.95, 104.71 Q 31.41, 94.54, 31.37, 84.37 Q 31.11, 74.20, 31.45, 64.03 Q 31.89, 53.86, 31.03, 43.68 Q 31.30, 33.51, 31.47,\
            23.34 Q 32.00, 13.17, 32.00, 3.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 23.00, 7.00 Q 33.12, 5.94, 43.24, 5.26 Q 53.35, 5.02, 63.47, 5.66 Q 73.59,\
            4.64, 83.71, 5.54 Q 93.82, 6.23, 103.94, 6.33 Q 114.06, 6.29, 124.18, 4.79 Q 134.29, 5.59, 144.41, 6.73 Q 154.53, 6.73, 164.65,\
            6.43 Q 174.76, 6.16, 184.88, 5.81 Q 195.00, 6.22, 205.12, 6.57 Q 215.24, 5.93, 225.35, 5.60 Q 235.47, 5.09, 245.59, 5.97 Q\
            255.71, 6.08, 265.82, 6.23 Q 275.94, 6.29, 286.06, 5.90 Q 296.18, 6.50, 306.29, 5.65 Q 316.41, 6.22, 326.53, 5.52 Q 336.65,\
            5.21, 346.76, 5.01 Q 356.88, 4.90, 367.00, 4.76 Q 377.12, 4.74, 387.24, 4.87 Q 397.35, 5.02, 407.47, 4.89 Q 417.59, 4.85,\
            427.71, 5.49 Q 437.82, 4.76, 447.94, 5.53 Q 458.06, 5.99, 468.18, 6.55 Q 478.29, 6.99, 488.41, 6.70 Q 498.53, 7.05, 508.65,\
            6.74 Q 518.76, 7.59, 528.88, 6.95 Q 539.00, 6.56, 549.12, 6.43 Q 559.24, 6.80, 569.35, 7.37 Q 579.47, 6.68, 589.59, 6.13 Q\
            599.71, 6.66, 609.82, 7.63 Q 619.94, 7.18, 630.06, 6.06 Q 640.18, 5.57, 650.29, 5.51 Q 660.41, 5.61, 670.53, 5.31 Q 680.65,\
            5.77, 690.77, 4.91 Q 700.88, 5.06, 711.00, 4.61 Q 721.12, 5.11, 731.24, 5.24 Q 741.35, 4.88, 751.47, 5.19 Q 761.59, 5.88,\
            771.71, 5.94 Q 781.82, 5.79, 791.94, 6.02 Q 802.06, 5.66, 812.18, 5.54 Q 822.29, 5.73, 832.41, 6.49 Q 842.53, 5.63, 852.65,\
            4.80 Q 862.77, 5.66, 872.88, 5.75 Q 883.00, 5.91, 893.12, 5.83 Q 903.24, 5.88, 913.35, 6.08 Q 923.47, 6.05, 933.59, 6.23 Q\
            943.71, 5.89, 953.82, 5.87 Q 963.94, 5.83, 974.06, 7.02 Q 984.18, 6.56, 994.30, 6.14 Q 1004.41, 6.88, 1014.53, 6.58 Q 1024.65,\
            6.33, 1034.77, 5.61 Q 1044.88, 6.01, 1055.00, 5.62 Q 1065.12, 5.96, 1075.24, 6.52 Q 1085.35, 6.68, 1095.47, 6.52 Q 1105.59,\
            6.57, 1115.71, 7.23 Q 1125.83, 6.63, 1135.94, 6.31 Q 1146.06, 6.54, 1156.18, 6.50 Q 1166.30, 6.12, 1176.41, 6.71 Q 1186.53,\
            7.59, 1196.65, 7.59 Q 1206.77, 8.02, 1216.88, 6.95 Q 1227.00, 6.88, 1237.12, 6.22 Q 1247.24, 6.68, 1257.35, 5.99 Q 1267.47,\
            5.89, 1277.59, 6.22 Q 1287.71, 6.09, 1297.83, 6.20 Q 1307.94, 5.75, 1318.06, 5.71 Q 1328.18, 6.34, 1338.30, 6.70 Q 1348.41,\
            6.54, 1358.53, 5.36 Q 1368.65, 6.48, 1378.77, 5.36 Q 1388.88, 4.78, 1400.13, 5.87 Q 1400.31, 16.74, 1400.33, 27.15 Q 1399.66,\
            37.47, 1399.98, 47.65 Q 1400.35, 57.83, 1400.63, 68.01 Q 1400.44, 78.19, 1400.28, 88.37 Q 1400.20, 98.54, 1398.97, 108.71\
            Q 1399.48, 118.88, 1398.52, 129.05 Q 1398.59, 139.22, 1399.06, 149.39 Q 1399.20, 159.57, 1398.86, 169.74 Q 1398.81, 179.91,\
            1399.70, 190.08 Q 1398.93, 200.25, 1399.19, 210.42 Q 1399.36, 220.59, 1400.06, 230.76 Q 1399.56, 240.93, 1399.67, 251.11 Q\
            1400.07, 261.28, 1400.06, 271.45 Q 1400.39, 281.62, 1400.38, 291.79 Q 1400.01, 301.96, 1399.26, 312.13 Q 1399.20, 322.30,\
            1399.43, 332.47 Q 1400.22, 342.64, 1400.35, 352.82 Q 1400.18, 362.99, 1400.42, 373.16 Q 1400.89, 383.33, 1399.76, 393.50 Q\
            1399.89, 403.67, 1399.49, 413.84 Q 1399.27, 424.01, 1399.56, 434.18 Q 1399.60, 444.36, 1399.51, 454.53 Q 1400.02, 464.70,\
            1399.80, 474.87 Q 1399.78, 485.04, 1399.59, 495.21 Q 1399.68, 505.38, 1400.23, 515.55 Q 1400.17, 525.72, 1398.48, 535.89 Q\
            1399.16, 546.07, 1398.86, 556.24 Q 1398.69, 566.41, 1399.41, 576.58 Q 1398.53, 586.75, 1398.50, 596.92 Q 1398.63, 607.09,\
            1399.07, 617.26 Q 1399.27, 627.43, 1398.98, 637.61 Q 1399.23, 647.78, 1400.08, 657.95 Q 1400.39, 668.12, 1399.53, 678.29 Q\
            1399.43, 688.46, 1400.24, 698.63 Q 1400.36, 708.80, 1399.65, 718.97 Q 1399.53, 729.15, 1399.56, 739.32 Q 1399.66, 749.49,\
            1399.59, 759.66 Q 1399.19, 769.83, 1399.08, 780.08 Q 1388.92, 780.10, 1378.84, 780.53 Q 1368.71, 780.91, 1358.54, 780.24 Q\
            1348.42, 780.18, 1338.30, 780.93 Q 1328.18, 780.47, 1318.06, 781.12 Q 1307.94, 780.30, 1297.83, 780.41 Q 1287.71, 780.53,\
            1277.59, 780.61 Q 1267.47, 780.66, 1257.35, 780.96 Q 1247.24, 781.03, 1237.12, 779.84 Q 1227.00, 779.03, 1216.88, 778.38 Q\
            1206.77, 778.34, 1196.65, 778.76 Q 1186.53, 779.53, 1176.41, 778.03 Q 1166.30, 778.85, 1156.18, 779.92 Q 1146.06, 779.99,\
            1135.94, 779.51 Q 1125.83, 779.91, 1115.71, 780.63 Q 1105.59, 780.12, 1095.47, 779.95 Q 1085.35, 780.02, 1075.24, 780.86 Q\
            1065.12, 781.46, 1055.00, 780.89 Q 1044.88, 780.61, 1034.77, 780.61 Q 1024.65, 779.95, 1014.53, 780.61 Q 1004.41, 780.33,\
            994.30, 780.48 Q 984.18, 780.97, 974.06, 781.29 Q 963.94, 781.56, 953.82, 781.42 Q 943.71, 779.98, 933.59, 780.35 Q 923.47,\
            779.41, 913.35, 779.24 Q 903.24, 778.77, 893.12, 779.96 Q 883.00, 780.96, 872.88, 781.19 Q 862.77, 780.32, 852.65, 779.94\
            Q 842.53, 780.07, 832.41, 781.43 Q 822.29, 782.07, 812.18, 782.21 Q 802.06, 782.22, 791.94, 781.86 Q 781.82, 781.90, 771.71,\
            781.21 Q 761.59, 780.53, 751.47, 781.04 Q 741.35, 780.78, 731.24, 779.52 Q 721.12, 779.44, 711.00, 779.92 Q 700.88, 780.19,\
            690.77, 780.80 Q 680.65, 781.34, 670.53, 781.28 Q 660.41, 781.06, 650.29, 780.27 Q 640.18, 780.37, 630.06, 780.79 Q 619.94,\
            781.22, 609.82, 781.40 Q 599.71, 781.23, 589.59, 779.88 Q 579.47, 780.22, 569.35, 780.38 Q 559.24, 780.21, 549.12, 779.15\
            Q 539.00, 778.61, 528.88, 779.41 Q 518.76, 779.89, 508.65, 780.06 Q 498.53, 779.19, 488.41, 780.25 Q 478.29, 779.32, 468.18,\
            779.43 Q 458.06, 779.34, 447.94, 779.47 Q 437.82, 780.36, 427.71, 780.28 Q 417.59, 780.15, 407.47, 778.92 Q 397.35, 779.18,\
            387.24, 779.58 Q 377.12, 779.90, 367.00, 779.97 Q 356.88, 780.76, 346.76, 780.56 Q 336.65, 780.72, 326.53, 780.14 Q 316.41,\
            779.44, 306.29, 780.16 Q 296.18, 780.15, 286.06, 780.79 Q 275.94, 780.30, 265.82, 780.58 Q 255.71, 780.92, 245.59, 780.98\
            Q 235.47, 781.41, 225.35, 781.03 Q 215.24, 781.71, 205.12, 781.42 Q 195.00, 781.31, 184.88, 781.15 Q 174.76, 781.03, 164.65,\
            781.33 Q 154.53, 780.97, 144.41, 780.67 Q 134.29, 780.57, 124.18, 781.62 Q 114.06, 781.48, 103.94, 782.47 Q 93.82, 781.46,\
            83.71, 782.11 Q 73.59, 782.30, 63.47, 781.89 Q 53.35, 782.24, 43.24, 781.81 Q 33.12, 781.71, 22.70, 780.30 Q 22.17, 770.11,\
            22.00, 759.80 Q 21.87, 749.56, 21.99, 739.35 Q 22.79, 729.15, 22.37, 718.98 Q 22.12, 708.81, 21.86, 698.63 Q 22.26, 688.46,\
            21.41, 678.29 Q 22.26, 668.12, 21.29, 657.95 Q 21.19, 647.78, 21.45, 637.61 Q 21.47, 627.43, 21.76, 617.26 Q 21.25, 607.09,\
            21.63, 596.92 Q 21.11, 586.75, 21.75, 576.58 Q 22.26, 566.41, 22.00, 556.24 Q 21.80, 546.07, 21.01, 535.89 Q 20.68, 525.72,\
            20.89, 515.55 Q 21.34, 505.38, 22.77, 495.21 Q 22.71, 485.04, 21.40, 474.87 Q 20.99, 464.70, 22.00, 454.53 Q 23.02, 444.36,\
            23.36, 434.18 Q 23.09, 424.01, 22.57, 413.84 Q 22.84, 403.67, 22.75, 393.50 Q 22.02, 383.33, 21.78, 373.16 Q 21.92, 362.99,\
            21.95, 352.82 Q 21.60, 342.64, 21.80, 332.47 Q 21.16, 322.30, 21.31, 312.13 Q 22.08, 301.96, 21.55, 291.79 Q 21.66, 281.62,\
            21.92, 271.45 Q 21.66, 261.28, 21.73, 251.11 Q 21.57, 240.93, 21.49, 230.76 Q 21.35, 220.59, 21.30, 210.42 Q 21.07, 200.25,\
            21.23, 190.08 Q 21.32, 179.91, 21.38, 169.74 Q 21.32, 159.57, 22.00, 149.39 Q 22.42, 139.22, 22.52, 129.05 Q 22.38, 118.88,\
            22.29, 108.71 Q 22.48, 98.54, 21.76, 88.37 Q 21.65, 78.20, 22.29, 68.03 Q 22.71, 57.86, 22.54, 47.68 Q 22.22, 37.51, 22.77,\
            27.34 Q 23.00, 17.17, 23.00, 7.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 40.00, 11.00 Q 50.12, 10.46, 60.24, 10.45 Q 70.35, 10.31, 80.47, 10.29 Q 90.59,\
            10.19, 100.71, 10.71 Q 110.82, 10.56, 120.94, 10.49 Q 131.06, 10.13, 141.18, 10.10 Q 151.29, 10.65, 161.41, 10.77 Q 171.53,\
            10.65, 181.65, 10.54 Q 191.76, 10.01, 201.88, 10.95 Q 212.00, 9.90, 222.12, 10.09 Q 232.24, 10.20, 242.35, 10.06 Q 252.47,\
            9.90, 262.59, 10.92 Q 272.71, 11.58, 282.82, 11.84 Q 292.94, 11.64, 303.06, 11.68 Q 313.18, 11.28, 323.29, 10.97 Q 333.41,\
            10.30, 343.53, 10.14 Q 353.65, 10.47, 363.76, 11.67 Q 373.88, 10.91, 384.00, 10.41 Q 394.12, 10.23, 404.24, 10.85 Q 414.35,\
            10.44, 424.47, 10.46 Q 434.59, 10.24, 444.71, 10.38 Q 454.82, 10.00, 464.94, 10.26 Q 475.06, 11.02, 485.18, 10.69 Q 495.29,\
            10.94, 505.41, 10.31 Q 515.53, 10.19, 525.65, 10.49 Q 535.76, 10.22, 545.88, 10.71 Q 556.00, 10.16, 566.12, 11.46 Q 576.24,\
            10.36, 586.35, 11.01 Q 596.47, 10.13, 606.59, 10.11 Q 616.71, 9.44, 626.82, 9.59 Q 636.94, 9.87, 647.06, 10.32 Q 657.18, 10.83,\
            667.29, 9.69 Q 677.41, 10.95, 687.53, 10.77 Q 697.65, 10.58, 707.77, 10.26 Q 717.88, 10.51, 728.00, 10.80 Q 738.12, 10.42,\
            748.24, 10.50 Q 758.35, 10.44, 768.47, 10.99 Q 778.59, 10.32, 788.71, 10.71 Q 798.82, 10.99, 808.94, 10.85 Q 819.06, 9.65,\
            829.18, 9.74 Q 839.29, 10.23, 849.41, 10.27 Q 859.53, 10.54, 869.65, 10.02 Q 879.77, 10.19, 889.88, 10.30 Q 900.00, 10.48,\
            910.12, 11.20 Q 920.24, 11.25, 930.35, 11.13 Q 940.47, 10.52, 950.59, 11.39 Q 960.71, 11.40, 970.82, 10.53 Q 980.94, 9.73,\
            991.06, 10.23 Q 1001.18, 10.55, 1011.30, 11.45 Q 1021.41, 10.53, 1031.53, 10.50 Q 1041.65, 10.45, 1051.77, 11.04 Q 1061.88,\
            11.35, 1072.00, 10.27 Q 1082.12, 12.03, 1092.24, 12.62 Q 1102.35, 12.06, 1112.47, 11.02 Q 1122.59, 10.69, 1132.71, 12.15 Q\
            1142.83, 11.51, 1152.94, 10.38 Q 1163.06, 10.88, 1173.18, 10.31 Q 1183.30, 10.43, 1193.41, 9.79 Q 1203.53, 9.46, 1213.65,\
            9.97 Q 1223.77, 10.53, 1233.88, 10.63 Q 1244.00, 11.70, 1254.12, 10.99 Q 1264.24, 11.35, 1274.35, 11.58 Q 1284.47, 10.41,\
            1294.59, 9.42 Q 1304.71, 9.83, 1314.83, 10.79 Q 1324.94, 10.81, 1335.06, 10.13 Q 1345.18, 9.64, 1355.30, 10.04 Q 1365.41,\
            10.11, 1375.53, 10.40 Q 1385.65, 10.81, 1395.77, 10.86 Q 1405.88, 10.66, 1416.00, 11.01 Q 1415.96, 21.18, 1416.87, 31.22 Q\
            1417.03, 41.44, 1417.02, 51.65 Q 1416.44, 61.85, 1416.60, 72.02 Q 1416.29, 82.20, 1416.29, 92.37 Q 1415.20, 102.54, 1416.49,\
            112.71 Q 1416.91, 122.88, 1416.46, 133.05 Q 1416.19, 143.22, 1416.14, 153.39 Q 1416.19, 163.57, 1416.33, 173.74 Q 1417.28,\
            183.91, 1417.26, 194.08 Q 1417.37, 204.25, 1417.58, 214.42 Q 1416.32, 224.59, 1417.04, 234.76 Q 1416.93, 244.93, 1417.09,\
            255.11 Q 1416.65, 265.28, 1416.69, 275.45 Q 1415.12, 285.62, 1416.82, 295.79 Q 1417.08, 305.96, 1416.31, 316.13 Q 1415.99,\
            326.30, 1416.29, 336.47 Q 1416.48, 346.64, 1416.30, 356.82 Q 1416.08, 366.99, 1416.19, 377.16 Q 1416.04, 387.33, 1415.81,\
            397.50 Q 1415.55, 407.67, 1415.58, 417.84 Q 1416.08, 428.01, 1416.94, 438.18 Q 1417.02, 448.36, 1416.14, 458.53 Q 1416.04,\
            468.70, 1416.64, 478.87 Q 1416.89, 489.04, 1417.28, 499.21 Q 1417.97, 509.38, 1417.76, 519.55 Q 1417.75, 529.72, 1417.84,\
            539.89 Q 1417.93, 550.07, 1417.54, 560.24 Q 1417.69, 570.41, 1416.37, 580.58 Q 1417.51, 590.75, 1417.92, 600.92 Q 1417.71,\
            611.09, 1417.73, 621.26 Q 1417.76, 631.43, 1417.87, 641.61 Q 1417.59, 651.78, 1416.40, 661.95 Q 1416.19, 672.12, 1415.93,\
            682.29 Q 1416.65, 692.46, 1417.27, 702.63 Q 1416.75, 712.80, 1415.13, 722.97 Q 1414.79, 733.15, 1414.70, 743.32 Q 1414.83,\
            753.49, 1415.03, 763.66 Q 1416.01, 773.83, 1415.86, 783.86 Q 1405.93, 784.13, 1395.78, 784.06 Q 1385.59, 783.09, 1375.48,\
            782.55 Q 1365.40, 783.41, 1355.29, 783.63 Q 1345.18, 785.03, 1335.06, 784.99 Q 1324.94, 784.06, 1314.83, 783.89 Q 1304.71,\
            784.97, 1294.59, 784.96 Q 1284.47, 784.52, 1274.35, 785.86 Q 1264.24, 786.09, 1254.12, 785.24 Q 1244.00, 785.82, 1233.88,\
            785.36 Q 1223.77, 785.20, 1213.65, 784.95 Q 1203.53, 784.81, 1193.41, 784.41 Q 1183.30, 784.35, 1173.18, 783.94 Q 1163.06,\
            783.51, 1152.94, 782.97 Q 1142.83, 784.18, 1132.71, 783.98 Q 1122.59, 783.89, 1112.47, 783.59 Q 1102.35, 783.28, 1092.24,\
            783.07 Q 1082.12, 783.56, 1072.00, 784.70 Q 1061.88, 785.34, 1051.77, 785.39 Q 1041.65, 785.55, 1031.53, 785.07 Q 1021.41,\
            785.05, 1011.30, 785.03 Q 1001.18, 785.62, 991.06, 785.32 Q 980.94, 785.91, 970.82, 785.52 Q 960.71, 786.26, 950.59, 785.69\
            Q 940.47, 785.74, 930.35, 785.73 Q 920.24, 785.36, 910.12, 786.33 Q 900.00, 785.52, 889.88, 786.04 Q 879.77, 785.70, 869.65,\
            785.11 Q 859.53, 784.34, 849.41, 784.44 Q 839.29, 784.56, 829.18, 784.68 Q 819.06, 785.04, 808.94, 783.67 Q 798.82, 783.37,\
            788.71, 784.25 Q 778.59, 785.18, 768.47, 785.03 Q 758.35, 784.09, 748.24, 785.36 Q 738.12, 785.59, 728.00, 785.64 Q 717.88,\
            785.15, 707.77, 784.48 Q 697.65, 784.77, 687.53, 784.80 Q 677.41, 784.93, 667.29, 784.82 Q 657.18, 784.79, 647.06, 785.20\
            Q 636.94, 784.42, 626.82, 783.32 Q 616.71, 783.76, 606.59, 784.15 Q 596.47, 785.00, 586.35, 784.18 Q 576.24, 783.66, 566.12,\
            783.96 Q 556.00, 784.47, 545.88, 783.90 Q 535.76, 783.65, 525.65, 784.11 Q 515.53, 783.96, 505.41, 783.68 Q 495.29, 784.10,\
            485.18, 783.86 Q 475.06, 784.45, 464.94, 784.93 Q 454.82, 785.12, 444.71, 785.24 Q 434.59, 784.02, 424.47, 784.96 Q 414.35,\
            785.65, 404.24, 785.08 Q 394.12, 784.59, 384.00, 784.50 Q 373.88, 786.00, 363.76, 786.18 Q 353.65, 784.66, 343.53, 785.05\
            Q 333.41, 784.53, 323.29, 785.22 Q 313.18, 785.06, 303.06, 784.67 Q 292.94, 785.03, 282.82, 785.59 Q 272.71, 784.52, 262.59,\
            783.23 Q 252.47, 783.23, 242.35, 785.22 Q 232.24, 785.63, 222.12, 785.65 Q 212.00, 785.75, 201.88, 785.84 Q 191.76, 785.69,\
            181.65, 785.65 Q 171.53, 785.69, 161.41, 785.82 Q 151.29, 785.89, 141.18, 785.70 Q 131.06, 785.66, 120.94, 785.68 Q 110.82,\
            785.42, 100.71, 785.10 Q 90.59, 785.00, 80.47, 785.69 Q 70.35, 785.69, 60.24, 785.83 Q 50.12, 785.85, 39.19, 784.81 Q 39.14,\
            774.12, 39.14, 763.78 Q 38.96, 753.56, 38.91, 743.35 Q 38.84, 733.16, 38.53, 722.99 Q 38.36, 712.81, 38.59, 702.63 Q 38.86,\
            692.46, 39.20, 682.29 Q 39.05, 672.12, 38.98, 661.95 Q 38.87, 651.78, 38.85, 641.61 Q 38.78, 631.43, 38.49, 621.26 Q 38.94,\
            611.09, 39.10, 600.92 Q 38.81, 590.75, 38.68, 580.58 Q 38.67, 570.41, 38.58, 560.24 Q 38.75, 550.07, 38.57, 539.89 Q 38.63,\
            529.72, 38.60, 519.55 Q 38.82, 509.38, 39.17, 499.21 Q 38.95, 489.04, 39.12, 478.87 Q 39.26, 468.70, 39.10, 458.53 Q 38.23,\
            448.36, 38.77, 438.18 Q 39.29, 428.01, 40.88, 417.84 Q 40.64, 407.67, 39.76, 397.50 Q 39.13, 387.33, 39.02, 377.16 Q 39.02,\
            366.99, 38.93, 356.82 Q 38.95, 346.64, 39.09, 336.47 Q 39.12, 326.30, 39.48, 316.13 Q 38.67, 305.96, 38.58, 295.79 Q 38.49,\
            285.62, 38.48, 275.45 Q 38.65, 265.28, 40.10, 255.11 Q 39.00, 244.93, 39.49, 234.76 Q 38.60, 224.59, 39.05, 214.42 Q 38.30,\
            204.25, 38.20, 194.08 Q 38.93, 183.91, 39.36, 173.74 Q 39.77, 163.57, 39.59, 153.39 Q 40.45, 143.22, 40.29, 133.05 Q 39.89,\
            122.88, 40.17, 112.71 Q 40.10, 102.54, 40.11, 92.37 Q 39.45, 82.20, 39.86, 72.03 Q 39.15, 61.86, 40.41, 51.68 Q 39.11, 41.51,\
            38.82, 31.34 Q 40.00, 21.17, 40.00, 11.00" style=" fill:white;"/>\
         </svg:svg>\
      </div>\
   </div>\
</div>');