rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__1151130604-layer" class="layer" name="__containerId__pageLayer" data-layer-id="1151130604" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-1151130604-layer-90200862" style="position: absolute; left: 0px; top: 0px; width: 1375px; height: 820px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="90200862" data-review-reference-id="90200862">\
            <div class="stencil-wrapper" style="width: 1375px; height: 820px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 820px;width:1375px;" width="1375" height="820">\
                     <svg:g width="1375" height="820"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.08, 1.03, 22.16, 1.33 Q 32.24, 2.30, 42.32, 2.58 Q\
                        52.40, 2.42, 62.49, 2.73 Q 72.57, 3.22, 82.65, 2.45 Q 92.73, 1.55, 102.81, 1.04 Q 112.89, 1.15, 122.97, 1.74 Q 133.05, 2.30,\
                        143.13, 3.25 Q 153.21, 2.46, 163.29, 2.91 Q 173.38, 3.00, 183.46, 2.08 Q 193.54, 2.51, 203.62, 1.52 Q 213.70, 2.39, 223.78,\
                        1.44 Q 233.86, 0.94, 243.94, 1.40 Q 254.02, 2.13, 264.10, 1.69 Q 274.18, 2.11, 284.26, 2.63 Q 294.35, 2.55, 304.43, 1.84 Q\
                        314.51, 2.64, 324.59, 2.99 Q 334.67, 2.84, 344.75, 2.83 Q 354.83, 1.97, 364.91, 1.51 Q 374.99, 2.09, 385.07, 2.52 Q 395.15,\
                        1.95, 405.24, 1.06 Q 415.32, 1.80, 425.40, 2.28 Q 435.48, 2.05, 445.56, 1.76 Q 455.64, 1.58, 465.72, 1.07 Q 475.80, 1.08,\
                        485.88, 0.95 Q 495.96, 1.14, 506.04, 1.32 Q 516.12, 0.75, 526.21, 0.94 Q 536.29, 0.17, 546.37, 0.62 Q 556.45, 0.79, 566.53,\
                        1.35 Q 576.61, 1.46, 586.69, 2.41 Q 596.77, 3.07, 606.85, 1.90 Q 616.93, 1.85, 627.01, 1.83 Q 637.10, 1.91, 647.18, 1.43 Q\
                        657.26, 1.74, 667.34, 2.09 Q 677.42, 2.19, 687.50, 2.89 Q 697.58, 2.04, 707.66, 0.96 Q 717.74, 0.57, 727.82, -0.13 Q 737.90,\
                        0.15, 747.98, 0.43 Q 758.07, 1.96, 768.15, 2.50 Q 778.23, 2.81, 788.31, 2.44 Q 798.39, 1.79, 808.47, 0.58 Q 818.55, -0.25,\
                        828.63, 0.15 Q 838.71, 0.60, 848.79, 1.16 Q 858.87, 1.80, 868.96, 2.50 Q 879.04, 2.66, 889.12, 2.48 Q 899.20, 1.84, 909.28,\
                        1.35 Q 919.36, 0.58, 929.44, 0.47 Q 939.52, 0.52, 949.60, 0.95 Q 959.68, 0.93, 969.76, 0.92 Q 979.84, 0.35, 989.93, 0.24 Q\
                        1000.01, -0.15, 1010.09, -0.38 Q 1020.17, -0.20, 1030.25, -0.27 Q 1040.33, 0.24, 1050.41, 1.32 Q 1060.49, 0.35, 1070.57, -0.57\
                        Q 1080.65, -0.19, 1090.73, -0.04 Q 1100.82, -0.11, 1110.90, 0.13 Q 1120.98, 0.18, 1131.06, 1.18 Q 1141.14, 1.77, 1151.22,\
                        1.51 Q 1161.30, 0.78, 1171.38, 1.67 Q 1181.46, 2.42, 1191.54, 2.30 Q 1201.63, 2.04, 1211.71, 1.35 Q 1221.79, 1.47, 1231.87,\
                        1.84 Q 1241.95, 1.59, 1252.03, 1.21 Q 1262.11, 1.42, 1272.19, 1.55 Q 1282.27, 1.57, 1292.35, 1.48 Q 1302.43, 1.76, 1312.52,\
                        1.72 Q 1322.60, 1.84, 1332.68, 1.86 Q 1342.76, 0.70, 1352.84, 1.22 Q 1362.92, 0.24, 1373.32, 1.68 Q 1373.52, 12.03, 1374.47,\
                        22.19 Q 1374.87, 32.48, 1375.03, 42.73 Q 1374.39, 52.98, 1374.11, 63.19 Q 1374.44, 73.39, 1374.68, 83.60 Q 1374.90, 93.80,\
                        1374.20, 104.00 Q 1373.38, 114.20, 1373.52, 124.40 Q 1372.81, 134.60, 1372.23, 144.80 Q 1373.51, 155.00, 1373.37, 165.20 Q\
                        1374.02, 175.40, 1373.94, 185.60 Q 1374.08, 195.80, 1373.87, 206.00 Q 1373.99, 216.20, 1373.74, 226.40 Q 1373.93, 236.60,\
                        1374.24, 246.80 Q 1373.38, 257.00, 1374.59, 267.20 Q 1374.35, 277.40, 1374.50, 287.60 Q 1374.34, 297.80, 1374.63, 308.00 Q\
                        1374.08, 318.20, 1373.60, 328.40 Q 1373.83, 338.60, 1373.03, 348.80 Q 1374.23, 359.00, 1373.34, 369.20 Q 1372.87, 379.40,\
                        1372.83, 389.60 Q 1373.09, 399.80, 1372.88, 410.00 Q 1372.49, 420.20, 1373.17, 430.40 Q 1372.92, 440.60, 1373.46, 450.80 Q\
                        1373.64, 461.00, 1374.15, 471.20 Q 1374.30, 481.40, 1373.84, 491.60 Q 1373.52, 501.80, 1373.30, 512.00 Q 1374.47, 522.20,\
                        1373.87, 532.40 Q 1373.59, 542.60, 1373.35, 552.80 Q 1373.34, 563.00, 1373.29, 573.20 Q 1373.73, 583.40, 1373.57, 593.60 Q\
                        1373.39, 603.80, 1373.55, 614.00 Q 1373.22, 624.20, 1374.22, 634.40 Q 1374.95, 644.60, 1375.02, 654.80 Q 1375.05, 665.00,\
                        1375.01, 675.20 Q 1375.47, 685.40, 1375.10, 695.60 Q 1374.88, 705.80, 1374.22, 716.00 Q 1374.32, 726.20, 1372.60, 736.40 Q\
                        1373.26, 746.60, 1374.04, 756.80 Q 1374.83, 767.00, 1375.44, 777.20 Q 1375.23, 787.40, 1374.63, 797.60 Q 1373.72, 807.80,\
                        1373.34, 818.34 Q 1363.28, 819.09, 1353.03, 819.37 Q 1342.86, 819.53, 1332.72, 819.35 Q 1322.62, 819.27, 1312.53, 819.28 Q\
                        1302.44, 819.03, 1292.35, 818.53 Q 1282.27, 819.08, 1272.19, 818.58 Q 1262.11, 818.93, 1252.03, 817.95 Q 1241.95, 818.49,\
                        1231.87, 819.62 Q 1221.79, 819.98, 1211.71, 819.63 Q 1201.63, 819.65, 1191.54, 819.18 Q 1181.46, 818.94, 1171.38, 818.98 Q\
                        1161.30, 818.95, 1151.22, 818.36 Q 1141.14, 818.66, 1131.06, 818.70 Q 1120.98, 818.57, 1110.90, 818.63 Q 1100.82, 818.22,\
                        1090.73, 818.91 Q 1080.65, 818.71, 1070.57, 818.55 Q 1060.49, 818.68, 1050.41, 818.79 Q 1040.33, 819.33, 1030.25, 818.95 Q\
                        1020.17, 818.94, 1010.09, 818.68 Q 1000.01, 818.57, 989.93, 818.50 Q 979.84, 818.71, 969.76, 818.85 Q 959.68, 818.62, 949.60,\
                        818.54 Q 939.52, 818.43, 929.44, 819.40 Q 919.36, 819.59, 909.28, 818.85 Q 899.20, 818.23, 889.12, 817.01 Q 879.04, 817.97,\
                        868.96, 817.92 Q 858.87, 818.28, 848.79, 817.81 Q 838.71, 818.42, 828.63, 819.45 Q 818.55, 818.81, 808.47, 818.29 Q 798.39,\
                        817.97, 788.31, 818.06 Q 778.23, 818.69, 768.15, 819.00 Q 758.07, 819.59, 747.98, 819.43 Q 737.90, 819.76, 727.82, 819.62\
                        Q 717.74, 819.25, 707.66, 818.35 Q 697.58, 818.51, 687.50, 819.12 Q 677.42, 819.24, 667.34, 819.40 Q 657.26, 819.45, 647.18,\
                        819.50 Q 637.10, 819.29, 627.01, 819.26 Q 616.93, 818.77, 606.85, 819.19 Q 596.77, 819.13, 586.69, 819.02 Q 576.61, 818.60,\
                        566.53, 818.53 Q 556.45, 818.88, 546.37, 818.33 Q 536.29, 818.07, 526.21, 818.84 Q 516.12, 819.62, 506.04, 819.45 Q 495.96,\
                        818.53, 485.88, 817.77 Q 475.80, 818.46, 465.72, 818.89 Q 455.64, 819.04, 445.56, 818.90 Q 435.48, 818.97, 425.40, 818.71\
                        Q 415.32, 818.80, 405.24, 818.50 Q 395.15, 818.47, 385.07, 818.59 Q 374.99, 818.67, 364.91, 818.42 Q 354.83, 818.46, 344.75,\
                        818.52 Q 334.67, 819.25, 324.59, 818.91 Q 314.51, 818.18, 304.43, 817.71 Q 294.35, 818.54, 284.26, 819.40 Q 274.18, 818.13,\
                        264.10, 818.67 Q 254.02, 818.27, 243.94, 818.93 Q 233.86, 819.03, 223.78, 818.78 Q 213.70, 818.58, 203.62, 818.44 Q 193.54,\
                        818.53, 183.46, 817.52 Q 173.38, 818.18, 163.29, 817.45 Q 153.21, 818.37, 143.13, 817.94 Q 133.05, 817.25, 122.97, 816.79\
                        Q 112.89, 816.91, 102.81, 817.84 Q 92.73, 817.43, 82.65, 817.41 Q 72.57, 817.13, 62.49, 817.34 Q 52.40, 817.69, 42.32, 817.56\
                        Q 32.24, 817.54, 22.16, 817.46 Q 12.08, 817.63, 2.49, 817.51 Q 2.92, 807.50, 3.00, 797.46 Q 1.63, 787.43, 2.02, 777.20 Q 2.41,\
                        766.99, 2.57, 756.80 Q 2.10, 746.60, 2.23, 736.40 Q 2.33, 726.20, 2.03, 716.00 Q 1.40, 705.80, 0.77, 695.60 Q 0.49, 685.40,\
                        0.12, 675.20 Q 0.92, 665.00, 1.90, 654.80 Q 1.81, 644.60, 2.16, 634.40 Q 1.40, 624.20, 1.73, 614.00 Q 0.10, 603.80, 0.04,\
                        593.60 Q 0.86, 583.40, 1.30, 573.20 Q 1.13, 563.00, 2.53, 552.80 Q 3.03, 542.60, 2.91, 532.40 Q 2.20, 522.20, 1.77, 512.00\
                        Q 1.78, 501.80, 2.01, 491.60 Q 2.54, 481.40, 2.27, 471.20 Q 1.50, 461.00, 2.23, 450.80 Q 2.09, 440.60, 2.35, 430.40 Q 1.56,\
                        420.20, 2.52, 410.00 Q 3.00, 399.80, 2.88, 389.60 Q 1.83, 379.40, 1.56, 369.20 Q 1.11, 359.00, 0.30, 348.80 Q 0.62, 338.60,\
                        0.13, 328.40 Q 0.55, 318.20, 0.41, 308.00 Q 0.63, 297.80, 0.38, 287.60 Q 0.21, 277.40, -0.19, 267.20 Q -0.11, 257.00, 0.66,\
                        246.80 Q 0.84, 236.60, 1.00, 226.40 Q 1.89, 216.20, 2.19, 206.00 Q 0.74, 195.80, 0.99, 185.60 Q 1.63, 175.40, 2.23, 165.20\
                        Q 2.12, 155.00, 1.23, 144.80 Q 0.66, 134.60, 0.59, 124.40 Q 0.55, 114.20, 0.77, 104.00 Q 0.16, 93.80, -0.17, 83.60 Q -0.05,\
                        73.40, 0.34, 63.20 Q 0.87, 53.00, 0.95, 42.80 Q 0.64, 32.60, 1.94, 22.40 Q 2.00, 12.20, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.47, 5.84, 19.80, 11.57 Q 28.53, 16.66, 36.82, 22.46 Q 45.66,\
                        27.36, 54.51, 32.24 Q 63.11, 37.52, 71.72, 42.80 Q 80.22, 48.27, 88.98, 53.30 Q 97.71, 58.38, 106.41, 63.50 Q 115.18, 68.51,\
                        123.73, 73.89 Q 132.64, 78.66, 141.50, 83.51 Q 150.13, 88.76, 158.69, 94.13 Q 167.47, 99.11, 175.77, 104.92 Q 184.41, 110.13,\
                        193.11, 115.26 Q 201.72, 120.54, 210.69, 125.21 Q 219.47, 130.21, 228.25, 135.20 Q 236.94, 140.34, 245.40, 145.87 Q 253.97,\
                        151.22, 262.90, 155.96 Q 271.17, 161.80, 280.33, 166.16 Q 288.76, 171.74, 297.64, 176.56 Q 305.98, 182.30, 314.72, 187.35\
                        Q 323.47, 192.40, 332.29, 197.32 Q 340.89, 202.61, 349.10, 208.56 Q 358.11, 213.16, 366.30, 219.16 Q 374.81, 224.60, 383.58,\
                        229.61 Q 392.27, 234.76, 400.86, 240.07 Q 409.67, 245.00, 418.88, 249.28 Q 427.47, 254.58, 436.27, 259.54 Q 445.05, 264.54,\
                        453.54, 270.02 Q 462.16, 275.28, 470.92, 280.29 Q 479.35, 285.87, 488.06, 290.98 Q 496.72, 296.18, 505.32, 301.47 Q 513.82,\
                        306.94, 523.07, 311.14 Q 531.62, 316.52, 539.87, 322.41 Q 548.82, 327.11, 557.73, 331.88 Q 566.54, 336.83, 574.83, 342.64\
                        Q 583.49, 347.83, 592.47, 352.49 Q 601.44, 357.17, 609.41, 363.51 Q 618.22, 368.45, 627.24, 373.05 Q 635.70, 378.57, 644.28,\
                        383.89 Q 652.89, 389.17, 661.93, 393.74 Q 670.46, 399.14, 679.42, 403.84 Q 687.61, 409.81, 696.39, 414.81 Q 705.06, 419.98,\
                        714.09, 424.56 Q 722.62, 429.96, 730.71, 436.12 Q 739.46, 441.16, 748.00, 446.56 Q 757.17, 450.90, 765.53, 456.59 Q 774.20,\
                        461.78, 782.61, 467.38 Q 791.24, 472.63, 799.88, 477.84 Q 808.55, 483.02, 817.45, 487.83 Q 826.13, 492.98, 835.45, 497.06\
                        Q 843.98, 502.48, 852.66, 507.63 Q 861.27, 512.91, 870.24, 517.59 Q 879.19, 522.30, 887.59, 527.92 Q 896.19, 533.22, 904.60,\
                        538.84 Q 913.62, 543.42, 921.80, 549.42 Q 930.71, 554.19, 939.51, 559.16 Q 948.16, 564.37, 956.72, 569.73 Q 965.39, 574.91,\
                        974.26, 579.74 Q 982.71, 585.29, 991.73, 589.87 Q 1000.11, 595.54, 1008.92, 600.48 Q 1017.51, 605.79, 1025.56, 612.00 Q 1034.91,\
                        616.04, 1043.92, 620.65 Q 1052.74, 625.57, 1061.49, 630.62 Q 1069.90, 636.24, 1078.36, 641.77 Q 1087.14, 646.75, 1095.98,\
                        651.64 Q 1104.39, 657.25, 1112.60, 663.21 Q 1121.79, 667.50, 1130.55, 672.53 Q 1138.43, 679.04, 1147.78, 683.07 Q 1156.14,\
                        688.77, 1164.84, 693.90 Q 1173.90, 698.42, 1182.18, 704.26 Q 1191.51, 708.32, 1200.19, 713.49 Q 1208.90, 718.59, 1216.74,\
                        725.16 Q 1225.58, 730.05, 1234.54, 734.74 Q 1243.24, 739.86, 1252.05, 744.81 Q 1260.73, 749.97, 1268.87, 756.03 Q 1277.22,\
                        761.75, 1285.95, 766.83 Q 1294.15, 772.80, 1303.33, 777.11 Q 1312.33, 781.73, 1321.16, 786.64 Q 1330.07, 791.41, 1338.70,\
                        796.66 Q 1347.54, 801.56, 1356.30, 806.58 Q 1364.33, 812.83, 1373.00, 818.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 818.00 Q 10.28, 812.14, 19.11, 807.21 Q 28.13, 802.61, 36.73, 797.29\
                        Q 45.82, 792.80, 54.52, 787.65 Q 62.48, 781.25, 70.82, 775.50 Q 79.14, 769.72, 88.23, 765.24 Q 97.03, 760.25, 106.10, 755.72\
                        Q 115.03, 750.97, 123.31, 745.11 Q 132.16, 740.21, 140.56, 734.56 Q 148.87, 728.75, 157.46, 723.43 Q 166.27, 718.46, 175.25,\
                        713.79 Q 183.93, 708.61, 192.80, 703.74 Q 201.57, 698.71, 210.26, 693.56 Q 219.06, 688.58, 227.74, 683.39 Q 235.90, 677.33,\
                        244.69, 672.35 Q 253.76, 667.81, 262.32, 662.43 Q 270.74, 656.81, 279.15, 651.17 Q 287.76, 645.88, 296.87, 641.41 Q 305.24,\
                        635.71, 313.92, 630.54 Q 322.83, 625.74, 331.10, 619.87 Q 339.78, 614.69, 348.49, 609.56 Q 357.47, 604.88, 365.85, 599.20\
                        Q 375.05, 594.90, 383.59, 589.48 Q 391.97, 583.78, 400.89, 579.01 Q 409.37, 573.50, 418.10, 568.39 Q 426.92, 563.45, 435.81,\
                        558.62 Q 444.75, 553.87, 453.40, 548.64 Q 461.82, 543.03, 470.43, 537.72 Q 479.35, 532.95, 488.15, 527.97 Q 496.66, 522.50,\
                        505.50, 517.59 Q 514.18, 512.41, 522.73, 507.01 Q 531.40, 501.82, 540.04, 496.57 Q 548.63, 491.24, 557.28, 486.00 Q 566.15,\
                        481.13, 574.81, 475.93 Q 583.66, 471.03, 592.76, 466.55 Q 601.20, 460.96, 609.63, 455.38 Q 618.47, 450.45, 627.26, 445.45\
                        Q 636.16, 440.66, 645.09, 435.88 Q 653.44, 430.16, 661.88, 424.57 Q 670.35, 419.03, 679.00, 413.81 Q 687.39, 408.14, 696.31,\
                        403.35 Q 705.54, 399.09, 714.46, 394.32 Q 722.81, 388.58, 731.15, 382.84 Q 740.13, 378.15, 749.37, 373.91 Q 758.08, 368.78,\
                        766.48, 363.13 Q 774.67, 357.13, 783.53, 352.25 Q 792.57, 347.67, 801.49, 342.90 Q 809.95, 337.35, 818.36, 331.70 Q 826.55,\
                        325.71, 835.10, 320.30 Q 843.78, 315.13, 852.67, 310.29 Q 861.56, 305.47, 870.28, 300.36 Q 879.20, 295.58, 887.97, 290.55\
                        Q 896.47, 285.07, 904.99, 279.61 Q 913.50, 274.14, 922.14, 268.89 Q 930.91, 263.87, 939.82, 259.07 Q 948.72, 254.26, 957.75,\
                        249.68 Q 965.77, 243.37, 974.72, 238.65 Q 983.35, 233.39, 991.85, 227.90 Q 1000.72, 223.04, 1009.69, 218.34 Q 1018.35, 213.14,\
                        1027.06, 208.00 Q 1035.58, 202.55, 1044.16, 197.21 Q 1052.73, 191.83, 1061.37, 186.58 Q 1070.08, 181.46, 1078.90, 176.51 Q\
                        1087.55, 171.27, 1096.26, 166.15 Q 1104.82, 160.76, 1113.49, 155.57 Q 1122.35, 150.68, 1131.04, 145.52 Q 1139.87, 140.60,\
                        1148.57, 135.45 Q 1157.26, 130.29, 1166.09, 125.36 Q 1175.18, 120.87, 1184.12, 116.13 Q 1192.94, 111.18, 1201.05, 105.04 Q\
                        1209.52, 99.51, 1218.34, 94.56 Q 1227.28, 89.81, 1235.79, 84.34 Q 1244.36, 78.98, 1253.22, 74.10 Q 1261.73, 68.63, 1270.67,\
                        63.89 Q 1279.80, 59.47, 1288.41, 54.16 Q 1297.03, 48.89, 1305.66, 43.62 Q 1314.15, 38.12, 1323.10, 33.40 Q 1331.67, 28.02,\
                        1340.10, 22.43 Q 1348.88, 17.41, 1357.12, 11.48 Q 1366.31, 7.17, 1375.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-447177703" style="position: absolute; left: 170px; top: 0px; width: 970px; height: 120px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="447177703" data-review-reference-id="447177703">\
            <div class="stencil-wrapper" style="width: 970px; height: 120px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 120px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 120px;width:970px;" width="970" height="120" viewBox="0 0 970 120">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="120" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-906632282" style="position: absolute; left: 455px; top: 15px; width: 410px; height: 48px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="906632282" data-review-reference-id="906632282">\
            <div class="stencil-wrapper" style="width: 410px; height: 48px">\
               <div title="" style="width:415px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 42px;">MONDAY MORNING</span> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-1401756140" style="position: absolute; left: 295px; top: 85px; width: 731px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1401756140" data-review-reference-id="1401756140">\
            <div class="stencil-wrapper" style="width: 731px; height: 37px">\
               <div title="" style="width:736px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">THE OFFICIAL MEDIA BODY OF NIT ROURKELA</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-1886376244" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1886376244" data-review-reference-id="1886376244">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e191" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e191</title>\
<path class="path1" d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM277.357 531.417q0 6.99 4.926 11.756t11.915 4.846h150.92v152.907q0 6.911 4.846 11.915t11.756 4.926h100.559q6.99 0 11.915-4.926t5.004-11.915v-152.907h150.601q6.911 0 11.915-4.846t4.926-11.756v-100.559q0-6.99-4.926-11.756t-11.915-4.846h-150.601v-150.92q0-6.911-5.004-11.915t-11.915-4.926h-100.559q-6.99 0-11.756 4.926t-4.846 11.915v150.92h-150.92q-6.911 0-11.915 4.846t-4.926 11.756v100.559z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e368" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e368</title>\
<path class="path1" d="M181.008 679.716v-364.035q0-54.969 38.921-93.729t93.491-38.682h364.035q54.969 0 93.729 38.682t38.682 93.729v364.035q0 54.969-38.682 93.65t-93.729 38.762h-364.035q-54.57 0-93.491-38.762t-38.921-93.65zM247.255 712.839q0 13.583 9.77 23.273t23.273 9.77h430.281q13.583 0 23.353-9.77t9.77-23.273v-430.281q0-13.583-9.77-23.353t-23.353-9.77h-430.281q-13.502 0-23.273 9.77t-9.77 23.353v430.281zM345.513 425.852q4.291-10.883 17.554-10.883h264.745q13.264 0 17.554 11.36t-3.972 22.4l-126.375 175.384q-7.944 10.961-19.539 11.756t-19.539-10.089l-126.455-178.086q-8.262-10.883-3.972-21.844z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path class="path1" d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e046" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e046</title>\
<path class="path1" d="M114.842 845.172v-529.492h761.193v529.492q0 13.583-9.77 23.353t-23.273 9.77h-695.028q-13.583 0-23.353-9.77t-9.77-23.353zM114.842 282.557v-99.289q0-13.583 9.77-23.353t23.353-9.77h66.167v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.044q13.583 0 23.353 9.77t9.77 23.353v33.044h364.035v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.124q13.583 0 23.273 9.77t9.77 23.353v33.044h66.246q13.583 0 23.273 9.77t9.77 23.353v99.289h-761.193zM181.008 812.128h99.289v-99.289h-99.289v99.289zM181.008 679.716h99.289v-99.289h-99.289v99.289zM181.008 547.303h99.289v-99.289h-99.289v99.289zM313.421 812.128h99.289v-99.289h-99.289v99.289zM313.421 679.716h99.289v-99.289h-99.289v99.289zM313.421 547.303h99.289v-99.289h-99.289v99.289zM445.833 812.128h99.289v-99.289h-99.289v99.289zM445.833 679.716h99.289v-99.289h-99.289v99.289zM445.833 547.303h99.289v-99.289h-99.289v99.289zM578.167 812.128h99.289v-99.289h-99.289v99.289zM578.167 679.716h99.289v-99.289h-99.289v99.289zM578.167 547.303h99.289v-99.289h-99.289v99.289zM710.579 812.128h99.289v-99.289h-99.289v99.289zM710.579 679.716h99.289v-99.289h-99.289v99.289zM710.579 547.303h99.289v-99.289h-99.289v99.289z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e212" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e212</title>\
<path class="path1" d="M181.008 563.586v-164.821q0-6.674 5.163-11.756t11.756-5.163h280.95v-171.413q0-6.99 3.972-8.817t9.294 2.463l345.208 266.812q5.639 4.291 5.639 10.247t-5.639 10.247l-344.893 267.129q-5.639 3.972-9.612 2.145t-3.972-8.817v-171.413h-280.95q-6.592 0-11.756-5.164t-5.163-11.677z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-889441583" style="position: absolute; left: 170px; top: 120px; width: 970px; height: 60px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="889441583" data-review-reference-id="889441583">\
            <div class="stencil-wrapper" style="width: 970px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 60px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 60px;width:970px;" width="970" height="60" viewBox="0 0 970 60">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="60" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-940789379" style="position: absolute; left: 240px; top: 135px; width: 52px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="940789379" data-review-reference-id="940789379">\
            <div class="stencil-wrapper" style="width: 52px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:56px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="56" height="34" viewBox="-2 -2 56 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 3.17, 28.17, 2.66, 27.34 Q 1.92, 26.70, 1.26, 25.92 Q 0.89, 14.02,\
                        0.37, 1.90 Q 0.94, 0.82, 1.50, -0.44 Q 2.35, -1.37, 3.61, -2.20 Q 15.25, -2.66, 26.84, -3.14 Q 38.44, -2.66, 50.32, -2.48\
                        Q 51.34, -1.46, 53.07, -1.20 Q 54.04, -0.16, 54.81, 1.42 Q 55.11, 13.68, 54.58, 26.26 Q 53.64, 27.38, 52.81, 28.72 Q 52.13,\
                        30.00, 50.48, 30.48 Q 38.72, 30.50, 27.08, 30.07 Q 15.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="26" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Home</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 52px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-1151130604-layer-940789379\', \'836759213\', {"button":"left","id":"330583414","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction263610701","options":"reloadOnly","target":"page353048828","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-1151130604-layer-1067942891" style="position: absolute; left: 340px; top: 135px; width: 550px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1067942891" data-review-reference-id="1067942891">\
            <div class="stencil-wrapper" style="width: 550px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:550px;" width="550" height="30">\
                     <svg:g id="__containerId__-1151130604-layer-1067942891svg" width="550" height="30"><svg:path id="__containerId__-1151130604-layer-1067942891_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00\
                        Q 12.11, 1.13, 22.22, 1.05 Q 32.33, 1.43, 42.44, 1.53 Q 52.56, 1.46, 62.67, 1.68 Q 72.78, 1.06, 82.89, 1.84 Q 93.00, 1.66,\
                        103.11, 1.94 Q 113.22, 2.42, 123.33, 2.74 Q 133.44, 2.09, 143.56, 1.35 Q 153.67, 2.15, 163.78, 2.39 Q 173.89, 2.23, 184.00,\
                        1.96 Q 194.11, 2.02, 204.22, 2.55 Q 214.33, 2.55, 224.44, 2.82 Q 234.56, 2.05, 244.67, 2.81 Q 254.78, 1.77, 264.89, 1.74 Q\
                        275.00, 1.19, 285.11, 0.58 Q 295.22, 0.71, 305.33, 1.04 Q 315.44, 2.11, 325.56, 2.10 Q 335.67, 0.96, 345.78, 1.47 Q 355.89,\
                        1.09, 366.00, 0.82 Q 376.11, 0.98, 386.22, 1.47 Q 396.33, 1.42, 406.44, 1.95 Q 416.56, 1.05, 426.67, 2.08 Q 436.78, 2.33,\
                        446.89, 3.29 Q 457.00, 2.43, 467.11, 2.73 Q 477.22, 2.98, 487.33, 3.13 Q 497.44, 2.32, 507.56, 1.16 Q 517.67, 1.93, 527.78,\
                        1.46 Q 537.89, 2.79, 547.95, 2.05 Q 548.18, 14.94, 548.24, 28.24 Q 538.09, 28.73, 527.90, 29.13 Q 517.75, 29.66, 507.59, 29.39\
                        Q 497.45, 28.23, 487.33, 27.10 Q 477.22, 27.97, 467.11, 27.78 Q 457.00, 28.27, 446.89, 29.47 Q 436.78, 29.37, 426.67, 28.62\
                        Q 416.56, 28.48, 406.44, 28.55 Q 396.33, 28.81, 386.22, 29.00 Q 376.11, 28.99, 366.00, 28.99 Q 355.89, 28.90, 345.78, 28.83\
                        Q 335.67, 29.01, 325.56, 29.11 Q 315.44, 27.88, 305.33, 28.26 Q 295.22, 29.11, 285.11, 29.30 Q 275.00, 28.60, 264.89, 28.13\
                        Q 254.78, 28.16, 244.67, 28.15 Q 234.56, 27.92, 224.44, 26.77 Q 214.33, 27.28, 204.22, 27.50 Q 194.11, 26.28, 184.00, 27.28\
                        Q 173.89, 27.19, 163.78, 27.41 Q 153.67, 27.82, 143.56, 28.00 Q 133.44, 28.13, 123.33, 28.60 Q 113.22, 29.48, 103.11, 28.89\
                        Q 93.00, 28.54, 82.89, 28.30 Q 72.78, 29.06, 62.67, 29.27 Q 52.56, 28.02, 42.44, 27.33 Q 32.33, 27.96, 22.22, 28.74 Q 12.11,\
                        27.63, 1.56, 28.44 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1151130604-layer-1067942891_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07,\
                        2.74, 23.15, 2.85 Q 33.22, 2.82, 43.30, 3.15 Q 53.37, 2.39, 63.44, 2.57 Q 73.52, 2.62, 83.59, 2.97 Q 93.67, 3.79, 103.74,\
                        2.55 Q 113.81, 2.24, 123.89, 2.19 Q 133.96, 2.66, 144.04, 1.87 Q 154.11, 1.52, 164.19, 2.20 Q 174.26, 2.87, 184.33, 3.90 Q\
                        194.41, 2.55, 204.48, 3.00 Q 214.56, 2.86, 224.63, 2.73 Q 234.70, 2.23, 244.78, 1.55 Q 254.85, 1.47, 264.93, 1.59 Q 275.00,\
                        1.87, 285.07, 1.89 Q 295.15, 2.34, 305.22, 2.30 Q 315.30, 2.38, 325.37, 2.47 Q 335.44, 2.06, 345.52, 1.99 Q 355.59, 2.77,\
                        365.67, 4.49 Q 375.74, 3.53, 385.81, 3.69 Q 395.89, 3.57, 405.96, 4.21 Q 416.04, 4.00, 426.11, 3.38 Q 436.18, 3.00, 446.26,\
                        2.75 Q 456.33, 3.34, 466.41, 2.38 Q 476.48, 1.98, 486.56, 1.76 Q 496.63, 1.58, 506.70, 1.47 Q 516.78, 1.46, 526.85, 1.95 Q\
                        536.93, 3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-1067942891_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-1067942891_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07,\
                        1.73, 23.15, 1.26 Q 33.22, 1.50, 43.30, 1.01 Q 53.37, 1.80, 63.44, 2.46 Q 73.52, 1.26, 83.59, 1.00 Q 93.67, 0.86, 103.74,\
                        0.86 Q 113.81, 1.80, 123.89, 2.03 Q 133.96, 1.23, 144.04, 1.35 Q 154.11, 1.47, 164.19, 1.36 Q 174.26, 1.30, 184.33, 1.39 Q\
                        194.41, 1.27, 204.48, 1.36 Q 214.56, 1.62, 224.63, 2.23 Q 234.70, 2.63, 244.78, 2.61 Q 254.85, 1.84, 264.93, 1.80 Q 275.00,\
                        1.28, 285.07, 2.00 Q 295.15, 2.06, 305.22, 2.02 Q 315.30, 2.03, 325.37, 1.83 Q 335.44, 2.01, 345.52, 2.23 Q 355.59, 2.62,\
                        365.67, 2.38 Q 375.74, 2.06, 385.81, 1.93 Q 395.89, 1.48, 405.96, 1.94 Q 416.04, 0.99, 426.11, 1.45 Q 436.18, 1.52, 446.26,\
                        1.34 Q 456.33, 1.31, 466.41, 1.28 Q 476.48, 1.33, 486.56, 2.49 Q 496.63, 2.33, 506.70, 2.49 Q 516.78, 2.69, 526.85, 3.07 Q\
                        536.93, 3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-1067942891_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-1151130604-layer-1067942891input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1151130604-layer-1067942891_input_svg_border\',\'__containerId__-1151130604-layer-1067942891_line1\',\'__containerId__-1151130604-layer-1067942891_line2\',\'__containerId__-1151130604-layer-1067942891_line3\',\'__containerId__-1151130604-layer-1067942891_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1151130604-layer-1067942891_input_svg_border\',\'__containerId__-1151130604-layer-1067942891_line1\',\'__containerId__-1151130604-layer-1067942891_line2\',\'__containerId__-1151130604-layer-1067942891_line3\',\'__containerId__-1151130604-layer-1067942891_line4\'))" value="Search Box" style="width:543px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-1576691087" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1576691087" data-review-reference-id="1576691087">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-1748462270" style="position: absolute; left: 0px; top: 778px; width: 1375px; height: 40px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1748462270" data-review-reference-id="1748462270">\
            <div class="stencil-wrapper" style="width: 1375px; height: 40px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 40px; width:1375px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 40px;width:1375px;" width="1375" height="40" viewBox="0 0 1375 40">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="1375" height="40" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-1688690899" style="position: absolute; left: 455px; top: 783px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1688690899" data-review-reference-id="1688690899">\
            <div class="stencil-wrapper" style="width: 403px; height: 20px">\
               <div title="" style="width:408px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Fixed footer for ASK A QUESTION AND FORUM </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-1832556952" style="position: absolute; left: 170px; top: 180px; width: 970px; height: 600px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1832556952" data-review-reference-id="1832556952">\
            <div class="stencil-wrapper" style="width: 970px; height: 600px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 600px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 600px;width:970px;" width="970" height="600" viewBox="0 0 970 600">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="600" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-text140813790" style="position: absolute; left: 570px; top: 215px; width: 161px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text140813790" data-review-reference-id="text140813790">\
            <div class="stencil-wrapper" style="width: 161px; height: 37px">\
               <div title="" style="width:166px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Add Article</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-textinput689272364" style="position: absolute; left: 300px; top: 360px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput689272364" data-review-reference-id="textinput689272364">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                     <svg:g id="__containerId__-1151130604-layer-textinput689272364svg" width="150" height="30"><svg:path id="__containerId__-1151130604-layer-textinput689272364_input_svg_border" class=" svg_unselected_element" d="M 2.00,\
                        2.00 Q 12.43, 1.84, 22.86, 1.35 Q 33.29, 1.04, 43.71, 0.63 Q 54.14, 0.46, 64.57, 0.55 Q 75.00, 0.83, 85.43, 0.82 Q 95.86,\
                        0.79, 106.29, 0.59 Q 116.71, 0.46, 127.14, 0.49 Q 137.57, 1.40, 148.46, 1.54 Q 148.95, 14.68, 148.29, 28.29 Q 137.81, 28.88,\
                        127.23, 28.78 Q 116.76, 28.83, 106.31, 29.18 Q 95.87, 29.21, 85.44, 29.45 Q 75.00, 29.53, 64.57, 28.92 Q 54.14, 28.55, 43.71,\
                        28.04 Q 33.29, 28.44, 22.86, 28.39 Q 12.43, 28.49, 1.57, 28.43 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1151130604-layer-textinput689272364_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 4.20, 23.57, 3.68 Q 33.86, 3.74, 44.14, 2.33 Q 54.43, 4.93, 64.71, 3.71 Q 75.00, 1.76, 85.29, 2.23 Q 95.57, 2.79, 105.86,\
                        4.12 Q 116.14, 3.67, 126.43, 2.56 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput689272364_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput689272364_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 3.22, 23.57, 2.63 Q 33.86, 2.75, 44.14, 1.56 Q 54.43, 1.92, 64.71, 2.24 Q 75.00, 2.52, 85.29, 1.27 Q 95.57, 1.09, 105.86,\
                        1.61 Q 116.14, 0.88, 126.43, 1.05 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput689272364_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-1151130604-layer-textinput689272364input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1151130604-layer-textinput689272364_input_svg_border\',\'__containerId__-1151130604-layer-textinput689272364_line1\',\'__containerId__-1151130604-layer-textinput689272364_line2\',\'__containerId__-1151130604-layer-textinput689272364_line3\',\'__containerId__-1151130604-layer-textinput689272364_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1151130604-layer-textinput689272364_input_svg_border\',\'__containerId__-1151130604-layer-textinput689272364_line1\',\'__containerId__-1151130604-layer-textinput689272364_line2\',\'__containerId__-1151130604-layer-textinput689272364_line3\',\'__containerId__-1151130604-layer-textinput689272364_line4\'))" value="Title" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-textinput372739111" style="position: absolute; left: 770px; top: 360px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput372739111" data-review-reference-id="textinput372739111">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                     <svg:g id="__containerId__-1151130604-layer-textinput372739111svg" width="150" height="30"><svg:path id="__containerId__-1151130604-layer-textinput372739111_input_svg_border" class=" svg_unselected_element" d="M 2.00,\
                        2.00 Q 12.43, 1.90, 22.86, 1.85 Q 33.29, 1.23, 43.71, 1.54 Q 54.14, 0.92, 64.57, 1.24 Q 75.00, 1.24, 85.43, 1.06 Q 95.86,\
                        1.28, 106.29, 0.22 Q 116.71, 0.52, 127.14, 0.62 Q 137.57, 1.13, 148.51, 1.49 Q 149.35, 14.55, 148.51, 28.51 Q 137.68, 28.41,\
                        127.17, 28.26 Q 116.78, 29.21, 106.31, 29.11 Q 95.86, 28.57, 85.43, 28.37 Q 75.00, 28.52, 64.57, 28.45 Q 54.14, 28.20, 43.71,\
                        27.87 Q 33.29, 27.92, 22.86, 28.19 Q 12.43, 28.74, 1.38, 28.62 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1151130604-layer-textinput372739111_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 3.65, 23.57, 3.02 Q 33.86, 2.97, 44.14, 2.06 Q 54.43, 2.49, 64.71, 2.72 Q 75.00, 2.52, 85.29, 2.36 Q 95.57, 1.87, 105.86,\
                        2.71 Q 116.14, 2.35, 126.43, 1.97 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput372739111_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput372739111_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 2.08, 23.57, 2.37 Q 33.86, 2.90, 44.14, 2.86 Q 54.43, 2.32, 64.71, 1.97 Q 75.00, 2.06, 85.29, 1.83 Q 95.57, 2.01, 105.86,\
                        2.06 Q 116.14, 1.81, 126.43, 1.42 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput372739111_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-1151130604-layer-textinput372739111input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1151130604-layer-textinput372739111_input_svg_border\',\'__containerId__-1151130604-layer-textinput372739111_line1\',\'__containerId__-1151130604-layer-textinput372739111_line2\',\'__containerId__-1151130604-layer-textinput372739111_line3\',\'__containerId__-1151130604-layer-textinput372739111_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1151130604-layer-textinput372739111_input_svg_border\',\'__containerId__-1151130604-layer-textinput372739111_line1\',\'__containerId__-1151130604-layer-textinput372739111_line2\',\'__containerId__-1151130604-layer-textinput372739111_line3\',\'__containerId__-1151130604-layer-textinput372739111_line4\'))" value="Category" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-group105049541" style="position: absolute; left: 305px; top: 435px; width: 187px; height: 32px" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group105049541" data-review-reference-id="group105049541">\
            <div class="stencil-wrapper" style="width: 187px; height: 32px">\
               <div id="group105049541-icon280034083" style="position: absolute; left: 155px; top: 0px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon280034083" data-review-reference-id="icon280034083">\
                  <div class="stencil-wrapper" style="width: 32px; height: 32px">\
                     <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                           <!--print symbols here-->\
                           <!--load fonticon glyph-e046-->\
                           <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e046"></use>\
                        </svg>\
                     </div>\
                  </div>\
               </div>\
               <div id="group105049541-textinput775736777" style="position: absolute; left: 0px; top: 0px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput775736777" data-review-reference-id="textinput775736777">\
                  <div class="stencil-wrapper" style="width: 150px; height: 30px">\
                     <div>\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                           <svg:g id="group105049541-textinput775736777svg" width="150" height="30"><svg:path id="group105049541-textinput775736777_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.43,\
                              1.74, 22.86, 2.98 Q 33.29, 2.61, 43.71, 2.78 Q 54.14, 1.02, 64.57, 1.58 Q 75.00, 2.27, 85.43, 2.81 Q 95.86, 1.25, 106.29,\
                              1.37 Q 116.71, 1.92, 127.14, 2.17 Q 137.57, 2.17, 148.23, 1.77 Q 148.12, 14.96, 148.17, 28.17 Q 137.74, 28.60, 127.28, 29.19\
                              Q 116.73, 28.37, 106.29, 28.30 Q 95.86, 28.49, 85.43, 28.17 Q 75.00, 29.25, 64.57, 28.61 Q 54.14, 28.79, 43.71, 28.05 Q 33.29,\
                              27.72, 22.86, 27.99 Q 12.43, 27.85, 1.89, 28.11 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="group105049541-textinput775736777_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.29, 4.27, 23.57,\
                              3.75 Q 33.86, 3.58, 44.14, 3.10 Q 54.43, 2.61, 64.71, 2.77 Q 75.00, 2.83, 85.29, 2.33 Q 95.57, 2.16, 105.86, 1.61 Q 116.14,\
                              2.04, 126.43, 2.70 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="group105049541-textinput775736777_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00,\
                              27.00" style=" fill:none;"/><svg:path id="group105049541-textinput775736777_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.29, 1.76, 23.57,\
                              2.02 Q 33.86, 2.19, 44.14, 1.70 Q 54.43, 1.19, 64.71, 1.90 Q 75.00, 1.01, 85.29, 1.30 Q 95.57, 1.27, 105.86, 1.21 Q 116.14,\
                              1.19, 126.43, 2.19 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="group105049541-textinput775736777_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00, 3.00,\
                              27.00" style=" fill:none;"/>\
                           </svg:g>\
                        </svg:svg>\
                        <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="group105049541-textinput775736777input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'group105049541-textinput775736777_input_svg_border\',\'group105049541-textinput775736777_line1\',\'group105049541-textinput775736777_line2\',\'group105049541-textinput775736777_line3\',\'group105049541-textinput775736777_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'group105049541-textinput775736777_input_svg_border\',\'group105049541-textinput775736777_line1\',\'group105049541-textinput775736777_line2\',\'group105049541-textinput775736777_line3\',\'group105049541-textinput775736777_line4\'))" value="Article Date" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
                     </div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-textinput490017369" style="position: absolute; left: 770px; top: 430px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput490017369" data-review-reference-id="textinput490017369">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                     <svg:g id="__containerId__-1151130604-layer-textinput490017369svg" width="150" height="30"><svg:path id="__containerId__-1151130604-layer-textinput490017369_input_svg_border" class=" svg_unselected_element" d="M 2.00,\
                        2.00 Q 12.43, 3.73, 22.86, 3.09 Q 33.29, 3.30, 43.71, 1.57 Q 54.14, 2.62, 64.57, 2.74 Q 75.00, 1.30, 85.43, 1.10 Q 95.86,\
                        1.64, 106.29, 2.89 Q 116.71, 2.94, 127.14, 2.86 Q 137.57, 1.83, 148.72, 1.28 Q 149.19, 14.60, 148.50, 28.50 Q 137.85, 29.03,\
                        127.15, 28.04 Q 116.73, 28.32, 106.29, 28.09 Q 95.86, 27.84, 85.43, 28.79 Q 75.00, 28.81, 64.57, 28.73 Q 54.14, 28.82, 43.71,\
                        28.57 Q 33.29, 28.66, 22.86, 29.46 Q 12.43, 29.54, 1.46, 28.54 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1151130604-layer-textinput490017369_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 2.61, 23.57, 2.56 Q 33.86, 2.41, 44.14, 2.73 Q 54.43, 2.34, 64.71, 2.23 Q 75.00, 2.33, 85.29, 2.66 Q 95.57, 2.69, 105.86,\
                        2.82 Q 116.14, 2.50, 126.43, 2.61 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput490017369_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput490017369_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 1.91, 23.57, 1.88 Q 33.86, 1.75, 44.14, 1.51 Q 54.43, 1.28, 64.71, 1.56 Q 75.00, 1.66, 85.29, 1.45 Q 95.57, 1.24, 105.86,\
                        1.09 Q 116.14, 1.01, 126.43, 1.41 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput490017369_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-1151130604-layer-textinput490017369input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1151130604-layer-textinput490017369_input_svg_border\',\'__containerId__-1151130604-layer-textinput490017369_line1\',\'__containerId__-1151130604-layer-textinput490017369_line2\',\'__containerId__-1151130604-layer-textinput490017369_line3\',\'__containerId__-1151130604-layer-textinput490017369_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1151130604-layer-textinput490017369_input_svg_border\',\'__containerId__-1151130604-layer-textinput490017369_line1\',\'__containerId__-1151130604-layer-textinput490017369_line2\',\'__containerId__-1151130604-layer-textinput490017369_line3\',\'__containerId__-1151130604-layer-textinput490017369_line4\'))" value="Authors" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-textinput540934007" style="position: absolute; left: 300px; top: 520px; width: 710px; height: 120px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput540934007" data-review-reference-id="textinput540934007">\
            <div class="stencil-wrapper" style="width: 710px; height: 120px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 120px;width:710px;" width="710" height="120">\
                     <svg:g id="__containerId__-1151130604-layer-textinput540934007svg" width="710" height="120"><svg:path id="__containerId__-1151130604-layer-textinput540934007_input_svg_border" class=" svg_unselected_element" d="M 2.00,\
                        2.00 Q 12.09, 3.36, 22.17, 3.13 Q 32.26, 2.69, 42.34, 2.46 Q 52.43, 2.43, 62.51, 1.94 Q 72.60, 2.71, 82.69, 1.45 Q 92.77,\
                        2.18, 102.86, 1.59 Q 112.94, 1.48, 123.03, 1.43 Q 133.11, 2.21, 143.20, 2.26 Q 153.29, 1.47, 163.37, 0.77 Q 173.46, 1.15,\
                        183.54, 1.75 Q 193.63, 2.87, 203.71, 2.01 Q 213.80, 1.64, 223.89, 1.66 Q 233.97, 1.27, 244.06, 1.13 Q 254.14, 1.33, 264.23,\
                        2.41 Q 274.31, 2.69, 284.40, 2.61 Q 294.49, 2.50, 304.57, 0.69 Q 314.66, 0.64, 324.74, -0.36 Q 334.83, -0.22, 344.91, 0.57\
                        Q 355.00, 0.77, 365.09, 0.56 Q 375.17, 1.12, 385.26, 1.97 Q 395.34, 1.50, 405.43, 1.65 Q 415.51, 1.65, 425.60, 1.33 Q 435.69,\
                        1.57, 445.77, 2.08 Q 455.86, 1.72, 465.94, 1.93 Q 476.03, 1.94, 486.11, 1.57 Q 496.20, 2.64, 506.29, 1.09 Q 516.37, 1.58,\
                        526.46, 1.61 Q 536.54, 1.53, 546.63, 1.15 Q 556.71, 1.27, 566.80, 1.16 Q 576.89, 1.20, 586.97, 1.43 Q 597.06, 0.66, 607.14,\
                        -0.15 Q 617.23, 0.16, 627.31, 0.81 Q 637.40, 0.87, 647.49, 0.01 Q 657.57, -0.00, 667.66, 0.36 Q 677.74, 1.21, 687.83, 0.49\
                        Q 697.91, -0.19, 709.04, 0.96 Q 709.34, 13.15, 709.80, 24.94 Q 709.93, 36.67, 710.13, 48.33 Q 709.83, 59.97, 709.69, 71.59\
                        Q 709.76, 83.19, 709.26, 94.80 Q 707.75, 106.40, 707.55, 117.55 Q 697.88, 117.91, 687.73, 117.31 Q 677.68, 117.13, 667.66,\
                        117.98 Q 657.56, 117.47, 647.49, 118.50 Q 637.40, 118.42, 627.31, 117.33 Q 617.23, 117.22, 607.14, 117.95 Q 597.06, 118.33,\
                        586.97, 118.31 Q 576.89, 119.24, 566.80, 118.98 Q 556.71, 118.95, 546.63, 119.15 Q 536.54, 117.40, 526.46, 116.75 Q 516.37,\
                        116.96, 506.29, 118.24 Q 496.20, 118.43, 486.11, 118.32 Q 476.03, 118.78, 465.94, 118.75 Q 455.86, 119.00, 445.77, 118.77\
                        Q 435.69, 118.83, 425.60, 118.56 Q 415.51, 118.55, 405.43, 117.66 Q 395.34, 118.01, 385.26, 118.40 Q 375.17, 118.67, 365.09,\
                        117.95 Q 355.00, 117.62, 344.91, 117.27 Q 334.83, 118.44, 324.74, 119.08 Q 314.66, 119.66, 304.57, 120.28 Q 294.49, 119.99,\
                        284.40, 119.38 Q 274.31, 119.44, 264.23, 118.29 Q 254.14, 117.54, 244.06, 117.75 Q 233.97, 119.48, 223.89, 119.98 Q 213.80,\
                        120.39, 203.71, 119.66 Q 193.63, 119.33, 183.54, 118.96 Q 173.46, 118.20, 163.37, 117.77 Q 153.29, 118.27, 143.20, 118.94\
                        Q 133.11, 119.10, 123.03, 119.56 Q 112.94, 119.54, 102.86, 119.40 Q 92.77, 119.22, 82.69, 119.14 Q 72.60, 119.41, 62.51, 119.51\
                        Q 52.43, 119.56, 42.34, 119.69 Q 32.26, 119.41, 22.17, 119.49 Q 12.09, 119.58, 1.28, 118.72 Q 0.98, 106.74, 0.58, 95.00 Q\
                        1.36, 83.24, -0.45, 71.68 Q 0.27, 60.03, 0.29, 48.41 Q 0.95, 36.80, 1.43, 25.20 Q 2.00, 13.60, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1151130604-layer-textinput540934007_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.06, 1.42, 23.11, 1.91 Q 33.17, 2.19, 43.23, 2.27 Q 53.29, 2.87, 63.34, 2.72 Q 73.40, 2.22, 83.46, 2.54 Q 93.51, 2.99, 103.57,\
                        3.10 Q 113.63, 2.60, 123.69, 2.71 Q 133.74, 2.21, 143.80, 1.61 Q 153.86, 1.47, 163.91, 1.83 Q 173.97, 2.99, 184.03, 1.95 Q\
                        194.09, 2.43, 204.14, 2.36 Q 214.20, 2.07, 224.26, 2.25 Q 234.31, 2.70, 244.37, 2.25 Q 254.43, 2.36, 264.49, 1.87 Q 274.54,\
                        2.63, 284.60, 2.19 Q 294.66, 2.11, 304.71, 2.06 Q 314.77, 1.81, 324.83, 1.97 Q 334.89, 2.20, 344.94, 2.60 Q 355.00, 2.79,\
                        365.06, 1.22 Q 375.11, 1.59, 385.17, 2.45 Q 395.23, 2.52, 405.29, 2.46 Q 415.34, 1.95, 425.40, 1.49 Q 435.46, 1.18, 445.51,\
                        1.64 Q 455.57, 1.11, 465.63, 2.29 Q 475.69, 2.42, 485.74, 2.35 Q 495.80, 2.92, 505.86, 2.49 Q 515.91, 3.49, 525.97, 1.59 Q\
                        536.03, 2.27, 546.09, 2.88 Q 556.14, 2.91, 566.20, 2.96 Q 576.26, 2.69, 586.31, 2.14 Q 596.37, 2.04, 606.43, 2.05 Q 616.49,\
                        1.97, 626.54, 1.70 Q 636.60, 2.12, 646.66, 2.36 Q 656.71, 2.95, 666.77, 2.61 Q 676.83, 3.00, 686.89, 2.93 Q 696.94, 3.00,\
                        707.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput540934007_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        4.15, 14.40, 3.97, 25.80 Q 4.11, 37.20, 4.14, 48.60 Q 3.97, 60.00, 4.07, 71.40 Q 4.06, 82.80, 4.19, 94.20 Q 3.00, 105.60,\
                        3.00, 117.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput540934007_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.06, 2.08, 23.11, 1.89 Q 33.17, 1.57, 43.23, 2.23 Q 53.29, 1.71, 63.34, 1.20 Q 73.40, 2.06, 83.46, 1.16 Q 93.51, 1.25, 103.57,\
                        1.75 Q 113.63, 1.25, 123.69, 1.52 Q 133.74, 2.37, 143.80, 2.54 Q 153.86, 2.59, 163.91, 1.66 Q 173.97, 1.19, 184.03, 1.32 Q\
                        194.09, 1.78, 204.14, 1.59 Q 214.20, 1.33, 224.26, 1.24 Q 234.31, 1.20, 244.37, 1.10 Q 254.43, 1.51, 264.49, 1.26 Q 274.54,\
                        1.16, 284.60, 1.24 Q 294.66, 1.94, 304.71, 2.07 Q 314.77, 1.68, 324.83, 2.17 Q 334.89, 1.96, 344.94, 1.67 Q 355.00, 2.14,\
                        365.06, 2.25 Q 375.11, 2.14, 385.17, 2.36 Q 395.23, 1.98, 405.29, 1.95 Q 415.34, 2.32, 425.40, 2.21 Q 435.46, 1.92, 445.51,\
                        1.76 Q 455.57, 2.14, 465.63, 1.83 Q 475.69, 1.34, 485.74, 1.50 Q 495.80, 1.79, 505.86, 2.37 Q 515.91, 2.68, 525.97, 2.67 Q\
                        536.03, 2.51, 546.09, 2.40 Q 556.14, 1.65, 566.20, 1.54 Q 576.26, 1.81, 586.31, 3.06 Q 596.37, 3.04, 606.43, 3.09 Q 616.49,\
                        4.11, 626.54, 3.32 Q 636.60, 3.57, 646.66, 3.63 Q 656.71, 3.27, 666.77, 3.24 Q 676.83, 2.57, 686.89, 2.93 Q 696.94, 3.00,\
                        707.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1151130604-layer-textinput540934007_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.40, 14.40, 3.23, 25.80 Q 2.83, 37.20, 3.25, 48.60 Q 3.43, 60.00, 2.15, 71.40 Q 3.53, 82.80, 3.28, 94.20 Q 3.00, 105.60,\
                        3.00, 117.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-1151130604-layer-textinput540934007input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1151130604-layer-textinput540934007_input_svg_border\',\'__containerId__-1151130604-layer-textinput540934007_line1\',\'__containerId__-1151130604-layer-textinput540934007_line2\',\'__containerId__-1151130604-layer-textinput540934007_line3\',\'__containerId__-1151130604-layer-textinput540934007_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1151130604-layer-textinput540934007_input_svg_border\',\'__containerId__-1151130604-layer-textinput540934007_line1\',\'__containerId__-1151130604-layer-textinput540934007_line2\',\'__containerId__-1151130604-layer-textinput540934007_line3\',\'__containerId__-1151130604-layer-textinput540934007_line4\'))" rows="" cols="" style="width:703px;height:114px;">The main content</textarea></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-iphoneButton8081482" style="position: absolute; left: 540px; top: 650px; width: 214px; height: 50px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton8081482" data-review-reference-id="iphoneButton8081482">\
            <div class="stencil-wrapper" style="width: 214px; height: 50px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 54px;width:218px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="218" height="54" viewBox="-2 -2 218 54">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 49.00 Q 2.07, 50.37, 0.70, 49.30 Q 0.12, 47.98, -0.02, 46.32 Q -0.39,\
                        35.21, -0.70, 24.12 Q -1.05, 13.07, -0.55, 1.66 Q 0.26, 0.56, 0.63, -1.23 Q 2.30, -1.44, 3.66, -2.05 Q 14.20, -2.30, 24.70,\
                        -2.35 Q 35.15, -2.30, 45.58, -1.93 Q 55.99, -1.65, 66.40, -1.78 Q 76.80, -2.31, 87.20, -2.84 Q 97.60, -2.12, 108.00, -2.02\
                        Q 118.40, -2.11, 128.80, -2.24 Q 139.20, -2.43, 149.60, -2.49 Q 160.00, -2.11, 170.40, -1.86 Q 180.80, -2.13, 191.20, -2.20\
                        Q 201.60, -2.44, 212.22, -1.93 Q 213.50, -1.88, 214.99, -1.10 Q 215.78, 0.04, 216.74, 1.44 Q 216.74, 12.74, 217.19, 23.84\
                        Q 217.36, 34.92, 217.30, 46.50 Q 216.37, 47.66, 215.24, 49.11 Q 214.13, 50.01, 212.54, 50.67 Q 201.85, 50.64, 191.31, 50.55\
                        Q 180.85, 50.31, 170.42, 49.88 Q 160.01, 49.81, 149.60, 49.82 Q 139.20, 49.91, 128.80, 50.14 Q 118.40, 49.87, 108.00, 49.19\
                        Q 97.60, 49.41, 87.20, 49.24 Q 76.80, 49.75, 66.40, 49.72 Q 56.00, 49.83, 45.60, 49.87 Q 35.20, 49.94, 24.80, 50.21 Q 14.40,\
                        49.00, 4.00, 49.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="107" y="25" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Submit</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-1198515586" style="position: absolute; left: 295px; top: 290px; width: 285px; height: 30px" data-interactive-element-type="default.upload" class="upload stencil mobile-interaction-potential-trigger " data-stencil-id="1198515586" data-review-reference-id="1198515586">\
            <div class="stencil-wrapper" style="width: 285px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="position: absolute; top: -2px; height: 30px;width:285px;" width="285" height="30">\
                     <svg:g><svg:path id="1198515586_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.86, 0.33, 23.71, 0.17 Q 34.57,\
                        0.44, 45.43, 0.48 Q 56.29, 0.45, 67.14, 0.78 Q 78.00, 0.78, 88.86, 0.96 Q 99.71, 0.99, 110.57, 0.87 Q 121.43, 1.17, 132.29,\
                        1.55 Q 143.14, 1.26, 154.07, 1.93 Q 154.66, 10.78, 153.93, 19.93 Q 143.18, 20.15, 132.29, 20.05 Q 121.46, 20.53, 110.59, 20.60\
                        Q 99.73, 21.06, 88.86, 20.56 Q 78.00, 20.18, 67.14, 20.23 Q 56.29, 20.99, 45.43, 21.06 Q 34.57, 20.76, 23.71, 20.27 Q 12.86,\
                        21.50, 1.59, 20.41 Q 2.00, 11.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="1198515586_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.86, 1.13, 24.71, 0.89 Q 35.57, 0.67,\
                        46.43, 1.23 Q 57.29, 1.25, 68.14, 0.46 Q 79.00, 1.15, 89.86, 1.64 Q 100.71, 1.68, 111.57, 1.71 Q 122.43, 1.55, 133.29, 0.98\
                        Q 144.14, 3.00, 155.00, 3.00" style=" fill:none;"/><svg:path id="1198515586_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 11.00, 3.00, 19.00" style=" fill:none;"/><svg:path id="1198515586_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.86, 2.84, 24.71, 2.10 Q 35.57, 1.18,\
                        46.43, 2.24 Q 57.29, 2.46, 68.14, 1.29 Q 79.00, 0.53, 89.86, 0.94 Q 100.71, 1.52, 111.57, 1.60 Q 122.43, 1.70, 133.29, 1.98\
                        Q 144.14, 3.00, 155.00, 3.00" style=" fill:none;"/><svg:path id="1198515586_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 11.00, 3.00, 19.00" style=" fill:none;"/>\
                     </svg:g>\
                     <svg:g><svg:path class=" svg_unselected_element" d="M 160.00, 2.00 Q 170.17, 0.77, 180.33, 0.93 Q 190.50, 0.78, 200.67, 0.74 Q 210.83,\
                        0.83, 221.00, 0.67 Q 231.17, 0.87, 241.33, 0.74 Q 251.50, 0.73, 261.67, 0.85 Q 271.83, 1.17, 282.48, 1.52 Q 282.54, 9.32,\
                        282.41, 17.41 Q 272.02, 17.68, 261.77, 17.91 Q 251.55, 18.08, 241.36, 18.14 Q 231.18, 18.25, 221.01, 18.08 Q 210.83, 17.00,\
                        200.67, 17.28 Q 190.50, 18.27, 180.33, 17.46 Q 170.17, 17.76, 159.90, 17.10 Q 160.00, 9.50, 160.00, 2.00" style=" fill:#d9d9d9;"/><svg:path class=" svg_unselected_element" d="M 158.00, 4.00 Q 158.00, 12.00, 158.00, 20.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 159.00, 5.00 Q 159.00, 13.00, 159.00, 21.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 160.00, 6.00 Q 160.00, 14.00, 160.00, 22.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 160.00, 18.00 Q 171.90, 17.05, 183.80, 16.90 Q 195.70, 16.79, 207.60, 16.71\
                        Q 219.50, 16.28, 231.40, 16.94 Q 243.30, 17.19, 255.20, 16.70 Q 267.10, 18.00, 279.00, 18.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 161.00, 19.00 Q 172.90, 18.73, 184.80, 18.72 Q 196.70, 19.09, 208.60, 18.79\
                        Q 220.50, 18.69, 232.40, 18.81 Q 244.30, 18.81, 256.20, 18.51 Q 268.10, 19.00, 280.00, 19.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 162.00, 20.00 Q 173.90, 20.32, 185.80, 20.18 Q 197.70, 20.23, 209.60, 20.30\
                        Q 221.50, 20.33, 233.40, 20.39 Q 245.30, 20.71, 257.20, 20.41 Q 269.10, 20.00, 281.00, 20.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 286.00, 2.00 Q 286.00, 11.00, 286.00, 20.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="width:285;height:30;position:absolute;left: 5px;top: -4px" title="" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'1198515586button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, \'1198515586button\');"><input id="1198515586input" type="text" value="" style="width:152px;height:28px;padding-top: 4px;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'1198515586button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, \'1198515586button\');" /><button id="1198515586button" type="button" title="" class="ClickableSketch" style="cursor:pointer;position:absolute;left:160px;top:1px;width:125px;height:18px;font-size:1em" xml:space="preserve">Browse...</button><form Name="1198515586form" Method="post" Action=""><input type="file" id="1198515586" title="" Name="1198515586" class="upload-input" size="18" onchange="document.getElementById(\'1198515586input\').value = this.value.substr(this.value.lastIndexOf(\'\\\') + 1)" style="cursor:pointer;color:black;position:absolute;top:2px;filter:alpha(opacity=1);opacity: 0.01;width:281px;" onmouseover="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOver, \'1198515586button\');" onmouseout="rabbit.facade.raiseEvent(rabbit.events.buttonMouseOut, \'1198515586button\');" /></form>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-994104809" style="position: absolute; left: 330px; top: 290px; width: 84px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="994104809" data-review-reference-id="994104809">\
            <div class="stencil-wrapper" style="width: 84px; height: 20px">\
               <div title="" style="width:89px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p><span style="font-size: 18px;">Image Url</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-389737695" style="position: absolute; left: 1065px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="389737695" data-review-reference-id="389737695">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e368-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e368"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-454670492" style="position: absolute; left: 920px; top: 140px; width: 129px; height: 22px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="454670492" data-review-reference-id="454670492">\
            <div class="stencil-wrapper" style="width: 129px; height: 22px">\
               <div title="" style="width:134px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><strong>Display Name</strong> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1151130604-layer-1046388767" style="position: absolute; left: 175px; top: 15px; width: 95px; height: 80px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1046388767" data-review-reference-id="1046388767">\
            <div class="stencil-wrapper" style="width: 95px; height: 80px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 80px;width:95px;" width="95" height="80">\
                     <svg:g width="95" height="80"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.38, -0.53, 24.75, -0.49 Q 36.12, -0.12, 47.50, -0.16\
                        Q 58.88, 0.40, 70.25, 0.27 Q 81.62, -0.05, 93.81, 1.19 Q 94.18, 14.27, 94.14, 27.17 Q 94.01, 39.93, 94.11, 52.63 Q 94.41,\
                        65.31, 93.74, 78.74 Q 81.89, 78.81, 70.37, 78.83 Q 58.97, 79.43, 47.53, 78.79 Q 36.14, 78.85, 24.76, 79.04 Q 13.38, 79.13,\
                        1.42, 78.58 Q 0.88, 65.70, 1.17, 52.79 Q 0.97, 40.07, 0.78, 27.37 Q 2.00, 14.67, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.53, 9.08, 20.65, 16.66 Q 29.68, 24.35, 38.68, 32.07 Q 47.76,\
                        39.69, 56.34, 47.91 Q 65.61, 55.31, 74.75, 62.86 Q 83.90, 70.40, 93.00, 78.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 78.00 Q 8.88, 70.60, 16.45, 64.05 Q 24.07, 57.56, 31.63, 50.99 Q 39.67,\
                        45.02, 47.20, 38.40 Q 54.97, 32.10, 62.66, 25.69 Q 70.56, 19.54, 78.59, 13.55 Q 87.25, 8.33, 95.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="1151130604"] .border-wrapper, body[data-current-page-id="1151130604"] .simulation-container{\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="1151130604"] .border-wrapper, body.has-frame[data-current-page-id="1151130604"] .simulation-container{\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="1151130604"] .svg-border-1366-768{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="1151130604"] .border-wrapper .border-div{\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "1151130604",\
      			"name": "add article",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
   <div id="border-wrapper">\
      <div xmlns="http://www.w3.org/1999/xhtml" xmlns:json="http://json.org/" class="svg-border svg-border-1366-768" style="display: none;">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="svg_border" style="position:absolute;left:-43px;top:-13px;width:1423px;height:792px;"><svg:path class=" svg_unselected_element" d="M 32.00, 3.00 Q 42.12, 2.32, 52.24, 2.78 Q 62.35, 2.91, 72.47, 2.85 Q 82.59,\
            2.37, 92.71, 2.73 Q 102.82, 2.76, 112.94, 2.39 Q 123.06, 2.40, 133.18, 2.07 Q 143.29, 1.96, 153.41, 2.13 Q 163.53, 2.21, 173.65,\
            1.86 Q 183.76, 2.53, 193.88, 1.25 Q 204.00, 2.34, 214.12, 2.37 Q 224.24, 2.71, 234.35, 2.89 Q 244.47, 2.57, 254.59, 2.45 Q\
            264.71, 1.90, 274.82, 1.68 Q 284.94, 2.87, 295.06, 1.77 Q 305.18, 1.61, 315.29, 1.93 Q 325.41, 3.03, 335.53, 2.98 Q 345.65,\
            1.62, 355.76, 0.78 Q 365.88, 2.21, 376.00, 2.20 Q 386.12, 2.12, 396.24, 2.53 Q 406.35, 3.01, 416.47, 3.47 Q 426.59, 3.01,\
            436.71, 2.97 Q 446.82, 2.20, 456.94, 2.54 Q 467.06, 1.82, 477.18, 2.55 Q 487.29, 2.21, 497.41, 2.30 Q 507.53, 2.22, 517.65,\
            2.06 Q 527.76, 2.95, 537.88, 3.04 Q 548.00, 2.41, 558.12, 1.49 Q 568.24, 1.81, 578.35, 1.81 Q 588.47, 1.65, 598.59, 2.13 Q\
            608.71, 2.80, 618.82, 3.50 Q 628.94, 3.52, 639.06, 3.87 Q 649.18, 3.10, 659.29, 2.01 Q 669.41, 1.22, 679.53, 1.14 Q 689.65,\
            1.70, 699.77, 2.73 Q 709.88, 1.97, 720.00, 1.85 Q 730.12, 1.31, 740.24, 1.92 Q 750.35, 3.16, 760.47, 2.34 Q 770.59, 2.20,\
            780.71, 2.69 Q 790.82, 3.61, 800.94, 3.44 Q 811.06, 2.50, 821.18, 2.70 Q 831.29, 2.84, 841.41, 2.66 Q 851.53, 2.18, 861.65,\
            2.16 Q 871.77, 2.42, 881.88, 2.97 Q 892.00, 1.92, 902.12, 1.33 Q 912.24, 1.52, 922.35, 2.30 Q 932.47, 2.63, 942.59, 1.73 Q\
            952.71, 2.21, 962.82, 2.60 Q 972.94, 2.50, 983.06, 2.14 Q 993.18, 2.19, 1003.30, 1.99 Q 1013.41, 2.00, 1023.53, 3.08 Q 1033.65,\
            3.04, 1043.77, 3.43 Q 1053.88, 2.43, 1064.00, 2.60 Q 1074.12, 2.02, 1084.24, 1.36 Q 1094.35, 0.95, 1104.47, 1.80 Q 1114.59,\
            2.77, 1124.71, 2.41 Q 1134.83, 2.25, 1144.94, 2.56 Q 1155.06, 2.28, 1165.18, 2.46 Q 1175.30, 2.24, 1185.41, 2.67 Q 1195.53,\
            2.56, 1205.65, 2.81 Q 1215.77, 2.35, 1225.88, 2.30 Q 1236.00, 2.72, 1246.12, 3.13 Q 1256.24, 3.08, 1266.35, 3.78 Q 1276.47,\
            4.01, 1286.59, 3.70 Q 1296.71, 3.05, 1306.83, 2.43 Q 1316.94, 1.76, 1327.06, 1.81 Q 1337.18, 1.59, 1347.30, 1.96 Q 1357.41,\
            2.61, 1367.53, 2.96 Q 1377.65, 2.15, 1387.77, 1.67 Q 1397.88, 1.49, 1409.24, 1.76 Q 1409.98, 12.51, 1410.32, 23.01 Q 1409.74,\
            33.40, 1409.49, 43.64 Q 1409.22, 53.84, 1408.61, 64.02 Q 1408.47, 74.20, 1409.35, 84.37 Q 1409.55, 94.54, 1408.81, 104.71\
            Q 1408.64, 114.88, 1408.42, 125.05 Q 1407.91, 135.22, 1407.30, 145.39 Q 1407.47, 155.57, 1407.91, 165.74 Q 1408.79, 175.91,\
            1409.49, 186.08 Q 1409.62, 196.25, 1409.53, 206.42 Q 1409.19, 216.59, 1409.20, 226.76 Q 1409.32, 236.93, 1409.52, 247.11 Q\
            1408.98, 257.28, 1409.75, 267.45 Q 1408.48, 277.62, 1408.54, 287.79 Q 1408.75, 297.96, 1408.73, 308.13 Q 1408.72, 318.30,\
            1408.67, 328.47 Q 1409.57, 338.64, 1409.73, 348.82 Q 1409.82, 358.99, 1409.48, 369.16 Q 1409.52, 379.33, 1409.47, 389.50 Q\
            1409.49, 399.67, 1409.53, 409.84 Q 1409.27, 420.01, 1409.06, 430.18 Q 1408.33, 440.36, 1409.17, 450.53 Q 1407.45, 460.70,\
            1407.72, 470.87 Q 1407.48, 481.04, 1407.11, 491.21 Q 1407.93, 501.38, 1407.67, 511.55 Q 1407.95, 521.72, 1408.23, 531.89 Q\
            1407.97, 542.07, 1407.51, 552.24 Q 1407.82, 562.41, 1407.93, 572.58 Q 1408.17, 582.75, 1408.51, 592.92 Q 1408.19, 603.09,\
            1408.75, 613.26 Q 1409.27, 623.43, 1409.94, 633.61 Q 1409.18, 643.78, 1409.25, 653.95 Q 1409.31, 664.12, 1409.93, 674.29 Q\
            1409.41, 684.46, 1409.41, 694.63 Q 1409.41, 704.80, 1408.43, 714.97 Q 1409.26, 725.15, 1409.12, 735.32 Q 1408.83, 745.49,\
            1409.57, 755.66 Q 1409.26, 765.83, 1408.51, 776.51 Q 1398.10, 776.66, 1387.78, 776.08 Q 1377.67, 776.37, 1367.56, 777.03 Q\
            1357.44, 777.45, 1347.31, 777.42 Q 1337.18, 777.41, 1327.06, 777.19 Q 1316.94, 777.59, 1306.83, 777.70 Q 1296.71, 777.43,\
            1286.59, 777.32 Q 1276.47, 776.78, 1266.35, 777.55 Q 1256.24, 776.95, 1246.12, 776.99 Q 1236.00, 777.30, 1225.88, 777.07 Q\
            1215.77, 776.25, 1205.65, 776.22 Q 1195.53, 777.49, 1185.41, 776.80 Q 1175.30, 777.46, 1165.18, 776.71 Q 1155.06, 777.06,\
            1144.94, 776.73 Q 1134.83, 776.19, 1124.71, 776.49 Q 1114.59, 776.64, 1104.47, 776.99 Q 1094.35, 777.21, 1084.24, 776.53 Q\
            1074.12, 776.08, 1064.00, 775.84 Q 1053.88, 775.58, 1043.77, 775.55 Q 1033.65, 775.96, 1023.53, 776.03 Q 1013.41, 776.49,\
            1003.30, 776.18 Q 993.18, 777.19, 983.06, 776.36 Q 972.94, 776.56, 962.82, 776.76 Q 952.71, 777.13, 942.59, 777.65 Q 932.47,\
            776.90, 922.35, 776.85 Q 912.24, 777.13, 902.12, 777.59 Q 892.00, 776.88, 881.88, 776.92 Q 871.77, 776.46, 861.65, 775.91\
            Q 851.53, 776.10, 841.41, 775.79 Q 831.29, 777.30, 821.18, 776.81 Q 811.06, 777.37, 800.94, 778.26 Q 790.82, 778.45, 780.71,\
            778.34 Q 770.59, 778.53, 760.47, 778.09 Q 750.35, 777.54, 740.24, 777.13 Q 730.12, 777.15, 720.00, 775.97 Q 709.88, 775.62,\
            699.77, 776.12 Q 689.65, 777.13, 679.53, 777.10 Q 669.41, 777.27, 659.29, 777.05 Q 649.18, 777.19, 639.06, 776.86 Q 628.94,\
            776.83, 618.82, 776.92 Q 608.71, 777.06, 598.59, 777.04 Q 588.47, 777.22, 578.35, 777.27 Q 568.24, 777.32, 558.12, 776.92\
            Q 548.00, 776.18, 537.88, 775.66 Q 527.76, 774.74, 517.65, 774.88 Q 507.53, 775.22, 497.41, 775.80 Q 487.29, 777.01, 477.18,\
            776.75 Q 467.06, 777.21, 456.94, 777.81 Q 446.82, 777.86, 436.71, 777.73 Q 426.59, 776.45, 416.47, 776.73 Q 406.35, 777.15,\
            396.24, 777.17 Q 386.12, 777.02, 376.00, 776.74 Q 365.88, 776.48, 355.76, 777.20 Q 345.65, 776.69, 335.53, 776.10 Q 325.41,\
            776.53, 315.29, 777.00 Q 305.18, 776.94, 295.06, 776.47 Q 284.94, 776.86, 274.82, 777.72 Q 264.71, 776.97, 254.59, 775.49\
            Q 244.47, 775.07, 234.35, 775.64 Q 224.24, 776.14, 214.12, 775.88 Q 204.00, 775.94, 193.88, 776.08 Q 183.76, 776.13, 173.65,\
            775.98 Q 163.53, 775.17, 153.41, 775.73 Q 143.29, 776.26, 133.18, 777.02 Q 123.06, 777.31, 112.94, 777.24 Q 102.82, 776.91,\
            92.71, 777.10 Q 82.59, 776.83, 72.47, 776.54 Q 62.35, 776.62, 52.24, 777.00 Q 42.12, 776.33, 31.85, 776.15 Q 31.51, 765.99,\
            31.57, 755.72 Q 31.00, 745.55, 31.08, 735.35 Q 31.05, 725.16, 31.06, 714.98 Q 30.55, 704.81, 30.42, 694.64 Q 31.73, 684.46,\
            32.07, 674.29 Q 31.17, 664.12, 30.68, 653.95 Q 31.44, 643.78, 31.81, 633.61 Q 32.58, 623.43, 31.27, 613.26 Q 31.64, 603.09,\
            32.38, 592.92 Q 33.11, 582.75, 33.45, 572.58 Q 32.85, 562.41, 32.41, 552.24 Q 31.89, 542.07, 32.36, 531.89 Q 31.71, 521.72,\
            31.75, 511.55 Q 30.99, 501.38, 31.71, 491.21 Q 32.16, 481.04, 31.92, 470.87 Q 31.91, 460.70, 31.81, 450.53 Q 32.17, 440.36,\
            31.24, 430.18 Q 30.93, 420.01, 31.77, 409.84 Q 32.25, 399.67, 32.04, 389.50 Q 31.12, 379.33, 31.06, 369.16 Q 30.66, 358.99,\
            31.14, 348.82 Q 30.63, 338.64, 31.20, 328.47 Q 32.05, 318.30, 31.95, 308.13 Q 31.50, 297.96, 31.00, 287.79 Q 30.85, 277.62,\
            31.29, 267.45 Q 32.33, 257.28, 31.20, 247.11 Q 31.46, 236.93, 31.99, 226.76 Q 31.03, 216.59, 30.65, 206.42 Q 30.33, 196.25,\
            31.24, 186.08 Q 32.01, 175.91, 31.65, 165.74 Q 30.52, 155.57, 31.37, 145.39 Q 31.96, 135.22, 32.49, 125.05 Q 31.88, 114.88,\
            31.05, 104.71 Q 31.00, 94.54, 31.55, 84.37 Q 32.11, 74.20, 32.50, 64.03 Q 31.73, 53.86, 31.26, 43.68 Q 31.33, 33.51, 31.47,\
            23.34 Q 32.00, 13.17, 32.00, 3.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 23.00, 7.00 Q 33.12, 6.30, 43.24, 6.61 Q 53.35, 6.50, 63.47, 6.67 Q 73.59,\
            6.66, 83.71, 6.75 Q 93.82, 7.69, 103.94, 7.33 Q 114.06, 7.43, 124.18, 6.79 Q 134.29, 6.35, 144.41, 7.10 Q 154.53, 8.03, 164.65,\
            8.30 Q 174.76, 7.25, 184.88, 7.35 Q 195.00, 6.23, 205.12, 6.83 Q 215.24, 6.82, 225.35, 6.38 Q 235.47, 6.11, 245.59, 6.94 Q\
            255.71, 6.97, 265.82, 8.02 Q 275.94, 8.54, 286.06, 7.71 Q 296.18, 7.30, 306.29, 7.29 Q 316.41, 7.37, 326.53, 7.25 Q 336.65,\
            7.00, 346.76, 7.13 Q 356.88, 6.13, 367.00, 5.54 Q 377.12, 5.71, 387.24, 5.92 Q 397.35, 6.18, 407.47, 6.08 Q 417.59, 5.94,\
            427.71, 5.74 Q 437.82, 6.12, 447.94, 5.63 Q 458.06, 5.47, 468.18, 6.60 Q 478.29, 7.51, 488.41, 6.73 Q 498.53, 6.55, 508.65,\
            7.95 Q 518.76, 8.20, 528.88, 7.80 Q 539.00, 6.06, 549.12, 6.33 Q 559.24, 6.36, 569.35, 6.07 Q 579.47, 5.72, 589.59, 6.25 Q\
            599.71, 7.54, 609.82, 7.73 Q 619.94, 8.15, 630.06, 7.84 Q 640.18, 6.60, 650.29, 6.04 Q 660.41, 5.80, 670.53, 5.47 Q 680.65,\
            5.27, 690.77, 5.04 Q 700.88, 5.74, 711.00, 5.11 Q 721.12, 5.03, 731.24, 4.96 Q 741.35, 4.81, 751.47, 4.59 Q 761.59, 4.95,\
            771.71, 5.44 Q 781.82, 5.66, 791.94, 5.54 Q 802.06, 5.26, 812.18, 5.30 Q 822.29, 5.61, 832.41, 5.50 Q 842.53, 5.73, 852.65,\
            6.29 Q 862.77, 5.77, 872.88, 5.37 Q 883.00, 4.76, 893.12, 5.00 Q 903.24, 5.49, 913.35, 6.22 Q 923.47, 6.84, 933.59, 7.03 Q\
            943.71, 6.65, 953.82, 6.02 Q 963.94, 5.69, 974.06, 5.97 Q 984.18, 6.90, 994.30, 7.73 Q 1004.41, 7.81, 1014.53, 7.64 Q 1024.65,\
            7.52, 1034.77, 7.29 Q 1044.88, 6.34, 1055.00, 5.19 Q 1065.12, 5.50, 1075.24, 6.26 Q 1085.35, 6.60, 1095.47, 6.61 Q 1105.59,\
            5.84, 1115.71, 5.63 Q 1125.83, 5.68, 1135.94, 5.52 Q 1146.06, 5.16, 1156.18, 5.62 Q 1166.30, 5.88, 1176.41, 5.98 Q 1186.53,\
            6.46, 1196.65, 6.72 Q 1206.77, 6.54, 1216.88, 7.32 Q 1227.00, 6.19, 1237.12, 7.00 Q 1247.24, 6.79, 1257.35, 6.71 Q 1267.47,\
            6.02, 1277.59, 6.08 Q 1287.71, 6.40, 1297.83, 5.32 Q 1307.94, 5.27, 1318.06, 5.24 Q 1328.18, 4.92, 1338.30, 4.92 Q 1348.41,\
            4.77, 1358.53, 4.80 Q 1368.65, 6.34, 1378.77, 6.92 Q 1388.88, 5.79, 1399.81, 6.20 Q 1400.25, 16.76, 1400.61, 27.11 Q 1400.83,\
            37.39, 1400.48, 47.64 Q 1400.65, 57.83, 1400.70, 68.01 Q 1400.90, 78.19, 1401.01, 88.36 Q 1401.16, 98.54, 1400.81, 108.71\
            Q 1400.53, 118.88, 1400.19, 129.05 Q 1400.00, 139.22, 1399.57, 149.39 Q 1399.69, 159.57, 1399.73, 169.74 Q 1399.89, 179.91,\
            1400.09, 190.08 Q 1399.43, 200.25, 1399.66, 210.42 Q 1399.41, 220.59, 1399.30, 230.76 Q 1399.24, 240.93, 1399.34, 251.11 Q\
            1399.00, 261.28, 1399.38, 271.45 Q 1399.40, 281.62, 1400.01, 291.79 Q 1400.44, 301.96, 1400.33, 312.13 Q 1399.95, 322.30,\
            1400.11, 332.47 Q 1400.49, 342.64, 1400.40, 352.82 Q 1400.05, 362.99, 1400.65, 373.16 Q 1400.06, 383.33, 1400.64, 393.50 Q\
            1400.77, 403.67, 1400.33, 413.84 Q 1400.31, 424.01, 1400.18, 434.18 Q 1399.60, 444.36, 1400.75, 454.53 Q 1401.22, 464.70,\
            1400.74, 474.87 Q 1399.94, 485.04, 1399.95, 495.21 Q 1399.69, 505.38, 1399.31, 515.55 Q 1399.76, 525.72, 1399.28, 535.89 Q\
            1399.28, 546.07, 1399.55, 556.24 Q 1398.67, 566.41, 1400.00, 576.58 Q 1399.41, 586.75, 1399.27, 596.92 Q 1399.49, 607.09,\
            1400.11, 617.26 Q 1400.16, 627.43, 1400.19, 637.61 Q 1399.65, 647.78, 1399.97, 657.95 Q 1400.70, 668.12, 1400.09, 678.29 Q\
            1400.50, 688.46, 1400.62, 698.63 Q 1401.02, 708.80, 1400.16, 718.97 Q 1400.51, 729.15, 1400.50, 739.32 Q 1399.14, 749.49,\
            1399.47, 759.66 Q 1398.89, 769.83, 1399.10, 780.09 Q 1388.97, 780.26, 1378.86, 780.64 Q 1368.70, 780.80, 1358.55, 780.58 Q\
            1348.43, 780.91, 1338.30, 780.31 Q 1328.18, 781.03, 1318.06, 780.70 Q 1307.94, 781.22, 1297.83, 780.81 Q 1287.71, 780.75,\
            1277.59, 780.71 Q 1267.47, 780.92, 1257.35, 781.02 Q 1247.24, 780.92, 1237.12, 780.79 Q 1227.00, 780.90, 1216.88, 780.26 Q\
            1206.77, 778.86, 1196.65, 779.89 Q 1186.53, 780.98, 1176.41, 780.83 Q 1166.30, 780.61, 1156.18, 780.24 Q 1146.06, 781.27,\
            1135.94, 781.48 Q 1125.83, 781.06, 1115.71, 780.89 Q 1105.59, 781.62, 1095.47, 781.49 Q 1085.35, 781.40, 1075.24, 781.95 Q\
            1065.12, 781.38, 1055.00, 781.64 Q 1044.88, 781.74, 1034.77, 781.00 Q 1024.65, 779.96, 1014.53, 780.05 Q 1004.41, 780.76,\
            994.30, 780.96 Q 984.18, 781.50, 974.06, 780.97 Q 963.94, 781.59, 953.82, 781.40 Q 943.71, 781.91, 933.59, 781.65 Q 923.47,\
            782.08, 913.35, 781.64 Q 903.24, 782.02, 893.12, 782.65 Q 883.00, 782.03, 872.88, 782.38 Q 862.77, 781.82, 852.65, 779.56\
            Q 842.53, 778.36, 832.41, 778.65 Q 822.29, 780.31, 812.18, 780.67 Q 802.06, 780.93, 791.94, 781.15 Q 781.82, 780.54, 771.71,\
            781.52 Q 761.59, 781.12, 751.47, 780.93 Q 741.35, 781.43, 731.24, 781.30 Q 721.12, 781.10, 711.00, 781.22 Q 700.88, 780.93,\
            690.77, 781.30 Q 680.65, 781.46, 670.53, 781.54 Q 660.41, 781.60, 650.29, 781.75 Q 640.18, 781.25, 630.06, 781.12 Q 619.94,\
            781.10, 609.82, 781.87 Q 599.71, 781.11, 589.59, 781.35 Q 579.47, 781.15, 569.35, 781.35 Q 559.24, 781.22, 549.12, 780.99\
            Q 539.00, 781.24, 528.88, 781.44 Q 518.76, 781.23, 508.65, 780.86 Q 498.53, 780.95, 488.41, 781.17 Q 478.29, 781.10, 468.18,\
            780.78 Q 458.06, 780.93, 447.94, 781.02 Q 437.82, 781.17, 427.71, 781.25 Q 417.59, 781.11, 407.47, 780.62 Q 397.35, 780.95,\
            387.24, 780.64 Q 377.12, 780.10, 367.00, 780.30 Q 356.88, 780.27, 346.76, 780.11 Q 336.65, 779.92, 326.53, 780.00 Q 316.41,\
            779.64, 306.29, 779.83 Q 296.18, 779.63, 286.06, 779.44 Q 275.94, 780.43, 265.82, 779.58 Q 255.71, 779.87, 245.59, 780.01\
            Q 235.47, 780.02, 225.35, 780.46 Q 215.24, 780.96, 205.12, 781.30 Q 195.00, 781.33, 184.88, 781.30 Q 174.76, 781.13, 164.65,\
            780.47 Q 154.53, 780.86, 144.41, 780.48 Q 134.29, 780.63, 124.18, 780.91 Q 114.06, 780.75, 103.94, 780.20 Q 93.82, 779.48,\
            83.71, 779.73 Q 73.59, 779.89, 63.47, 781.10 Q 53.35, 780.71, 43.24, 779.99 Q 33.12, 780.73, 22.76, 780.24 Q 22.77, 769.91,\
            22.46, 759.74 Q 22.58, 749.52, 22.78, 739.32 Q 22.73, 729.15, 22.74, 718.98 Q 22.31, 708.81, 22.98, 698.63 Q 23.59, 688.46,\
            24.43, 678.29 Q 23.30, 668.12, 22.69, 657.95 Q 22.76, 647.78, 21.51, 637.61 Q 21.70, 627.43, 22.40, 617.26 Q 22.39, 607.09,\
            22.94, 596.92 Q 22.63, 586.75, 22.37, 576.58 Q 22.13, 566.41, 22.80, 556.24 Q 22.34, 546.07, 22.84, 535.89 Q 22.87, 525.72,\
            22.20, 515.55 Q 22.75, 505.38, 22.39, 495.21 Q 23.11, 485.04, 23.30, 474.87 Q 22.93, 464.70, 22.77, 454.53 Q 22.93, 444.36,\
            23.91, 434.18 Q 22.91, 424.01, 21.85, 413.84 Q 22.58, 403.67, 23.14, 393.50 Q 23.23, 383.33, 23.35, 373.16 Q 23.41, 362.99,\
            23.23, 352.82 Q 23.04, 342.64, 22.67, 332.47 Q 21.98, 322.30, 22.07, 312.13 Q 22.47, 301.96, 21.73, 291.79 Q 22.39, 281.62,\
            23.13, 271.45 Q 22.65, 261.28, 23.17, 251.11 Q 22.20, 240.93, 21.33, 230.76 Q 21.71, 220.59, 22.13, 210.42 Q 21.78, 200.25,\
            21.85, 190.08 Q 21.71, 179.91, 21.70, 169.74 Q 21.47, 159.57, 21.15, 149.39 Q 20.96, 139.22, 22.19, 129.05 Q 23.30, 118.88,\
            21.57, 108.71 Q 21.10, 98.54, 21.79, 88.37 Q 23.32, 78.20, 23.52, 68.03 Q 22.35, 57.86, 22.34, 47.68 Q 23.22, 37.51, 23.32,\
            27.34 Q 23.00, 17.17, 23.00, 7.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 40.00, 11.00 Q 50.12, 9.89, 60.24, 9.79 Q 70.35, 9.71, 80.47, 9.80 Q 90.59,\
            9.69, 100.71, 9.70 Q 110.82, 10.34, 120.94, 10.06 Q 131.06, 10.56, 141.18, 9.66 Q 151.29, 9.49, 161.41, 9.60 Q 171.53, 9.93,\
            181.65, 10.81 Q 191.76, 10.56, 201.88, 10.42 Q 212.00, 10.98, 222.12, 11.16 Q 232.24, 10.78, 242.35, 10.22 Q 252.47, 9.83,\
            262.59, 9.45 Q 272.71, 9.74, 282.82, 9.56 Q 292.94, 9.96, 303.06, 10.09 Q 313.18, 10.39, 323.29, 10.70 Q 333.41, 10.77, 343.53,\
            10.83 Q 353.65, 10.51, 363.76, 10.44 Q 373.88, 10.22, 384.00, 10.20 Q 394.12, 9.94, 404.24, 9.85 Q 414.35, 9.88, 424.47, 10.37\
            Q 434.59, 10.24, 444.71, 9.87 Q 454.82, 9.83, 464.94, 9.61 Q 475.06, 10.00, 485.18, 9.51 Q 495.29, 9.71, 505.41, 9.42 Q 515.53,\
            9.91, 525.65, 9.38 Q 535.76, 9.05, 545.88, 10.26 Q 556.00, 9.07, 566.12, 9.66 Q 576.24, 9.31, 586.35, 10.24 Q 596.47, 10.73,\
            606.59, 10.92 Q 616.71, 10.79, 626.82, 10.66 Q 636.94, 10.67, 647.06, 10.70 Q 657.18, 10.13, 667.29, 10.17 Q 677.41, 10.04,\
            687.53, 9.98 Q 697.65, 10.18, 707.77, 10.15 Q 717.88, 10.12, 728.00, 10.36 Q 738.12, 9.73, 748.24, 9.94 Q 758.35, 9.43, 768.47,\
            9.74 Q 778.59, 10.25, 788.71, 10.29 Q 798.82, 10.35, 808.94, 10.73 Q 819.06, 10.86, 829.18, 10.54 Q 839.29, 11.11, 849.41,\
            10.14 Q 859.53, 10.74, 869.65, 10.29 Q 879.77, 10.20, 889.88, 9.82 Q 900.00, 10.20, 910.12, 10.61 Q 920.24, 10.23, 930.35,\
            10.01 Q 940.47, 9.92, 950.59, 10.47 Q 960.71, 10.21, 970.82, 9.75 Q 980.94, 9.54, 991.06, 10.34 Q 1001.18, 10.57, 1011.30,\
            9.81 Q 1021.41, 9.95, 1031.53, 9.44 Q 1041.65, 10.16, 1051.77, 11.21 Q 1061.88, 10.60, 1072.00, 10.14 Q 1082.12, 9.89, 1092.24,\
            10.43 Q 1102.35, 11.21, 1112.47, 9.95 Q 1122.59, 9.58, 1132.71, 11.40 Q 1142.83, 11.39, 1152.94, 11.53 Q 1163.06, 11.63, 1173.18,\
            11.12 Q 1183.30, 11.18, 1193.41, 10.90 Q 1203.53, 11.52, 1213.65, 10.51 Q 1223.77, 11.35, 1233.88, 11.08 Q 1244.00, 11.10,\
            1254.12, 11.38 Q 1264.24, 10.75, 1274.35, 9.84 Q 1284.47, 10.30, 1294.59, 10.25 Q 1304.71, 10.05, 1314.83, 10.14 Q 1324.94,\
            9.51, 1335.06, 9.44 Q 1345.18, 9.37, 1355.30, 10.09 Q 1365.41, 9.88, 1375.53, 10.56 Q 1385.65, 10.54, 1395.77, 10.53 Q 1405.88,\
            10.20, 1416.20, 10.80 Q 1416.24, 21.09, 1417.16, 31.18 Q 1417.42, 41.42, 1416.50, 51.67 Q 1416.50, 61.85, 1417.12, 72.02 Q\
            1416.92, 82.19, 1416.89, 92.37 Q 1416.78, 102.54, 1416.68, 112.71 Q 1416.84, 122.88, 1416.56, 133.05 Q 1415.93, 143.22, 1416.59,\
            153.39 Q 1416.79, 163.57, 1416.20, 173.74 Q 1416.39, 183.91, 1416.68, 194.08 Q 1416.83, 204.25, 1417.09, 214.42 Q 1417.00,\
            224.59, 1416.69, 234.76 Q 1417.26, 244.93, 1417.07, 255.11 Q 1416.42, 265.28, 1416.65, 275.45 Q 1416.72, 285.62, 1417.33,\
            295.79 Q 1417.58, 305.96, 1417.31, 316.13 Q 1416.95, 326.30, 1417.29, 336.47 Q 1417.80, 346.64, 1417.45, 356.82 Q 1416.56,\
            366.99, 1417.22, 377.16 Q 1417.56, 387.33, 1417.45, 397.50 Q 1417.28, 407.67, 1416.65, 417.84 Q 1416.49, 428.01, 1416.93,\
            438.18 Q 1417.55, 448.36, 1417.53, 458.53 Q 1417.75, 468.70, 1417.90, 478.87 Q 1417.63, 489.04, 1417.76, 499.21 Q 1417.75,\
            509.38, 1417.86, 519.55 Q 1417.47, 529.72, 1416.38, 539.89 Q 1416.35, 550.07, 1416.07, 560.24 Q 1415.92, 570.41, 1416.48,\
            580.58 Q 1416.56, 590.75, 1416.00, 600.92 Q 1416.21, 611.09, 1416.82, 621.26 Q 1416.92, 631.43, 1415.90, 641.61 Q 1415.52,\
            651.78, 1415.33, 661.95 Q 1415.65, 672.12, 1415.87, 682.29 Q 1415.57, 692.46, 1416.41, 702.63 Q 1416.79, 712.80, 1417.14,\
            722.97 Q 1416.69, 733.15, 1416.84, 743.32 Q 1414.96, 753.49, 1415.39, 763.66 Q 1415.92, 773.83, 1416.06, 784.06 Q 1406.11,\
            784.68, 1395.96, 785.33 Q 1385.73, 785.15, 1375.52, 783.63 Q 1365.41, 783.89, 1355.30, 784.23 Q 1345.18, 784.28, 1335.06,\
            783.43 Q 1324.94, 782.57, 1314.83, 782.97 Q 1304.71, 783.21, 1294.59, 784.40 Q 1284.47, 783.75, 1274.35, 784.07 Q 1264.24,\
            784.04, 1254.12, 784.25 Q 1244.00, 784.48, 1233.88, 783.96 Q 1223.77, 784.37, 1213.65, 785.52 Q 1203.53, 785.82, 1193.41,\
            784.18 Q 1183.30, 784.55, 1173.18, 784.06 Q 1163.06, 784.43, 1152.94, 784.39 Q 1142.83, 784.48, 1132.71, 784.87 Q 1122.59,\
            784.91, 1112.47, 785.32 Q 1102.35, 784.65, 1092.24, 785.79 Q 1082.12, 784.90, 1072.00, 785.20 Q 1061.88, 785.27, 1051.77,\
            785.45 Q 1041.65, 785.79, 1031.53, 785.27 Q 1021.41, 785.33, 1011.30, 785.14 Q 1001.18, 786.09, 991.06, 786.05 Q 980.94, 786.20,\
            970.82, 786.41 Q 960.71, 786.52, 950.59, 786.62 Q 940.47, 786.46, 930.35, 785.26 Q 920.24, 784.32, 910.12, 785.59 Q 900.00,\
            785.17, 889.88, 784.54 Q 879.77, 784.17, 869.65, 784.11 Q 859.53, 783.88, 849.41, 784.28 Q 839.29, 784.46, 829.18, 784.77\
            Q 819.06, 784.90, 808.94, 784.61 Q 798.82, 783.94, 788.71, 784.50 Q 778.59, 784.78, 768.47, 785.09 Q 758.35, 785.31, 748.24,\
            785.15 Q 738.12, 785.35, 728.00, 785.01 Q 717.88, 785.32, 707.77, 784.46 Q 697.65, 784.30, 687.53, 784.38 Q 677.41, 784.16,\
            667.29, 784.12 Q 657.18, 785.10, 647.06, 785.02 Q 636.94, 784.68, 626.82, 784.91 Q 616.71, 785.19, 606.59, 784.02 Q 596.47,\
            784.30, 586.35, 784.13 Q 576.24, 784.67, 566.12, 784.83 Q 556.00, 784.67, 545.88, 784.65 Q 535.76, 785.01, 525.65, 785.49\
            Q 515.53, 785.41, 505.41, 785.55 Q 495.29, 785.78, 485.18, 784.39 Q 475.06, 783.91, 464.94, 784.38 Q 454.82, 783.65, 444.71,\
            784.46 Q 434.59, 784.21, 424.47, 784.78 Q 414.35, 785.26, 404.24, 785.30 Q 394.12, 785.10, 384.00, 785.30 Q 373.88, 785.98,\
            363.76, 785.49 Q 353.65, 784.92, 343.53, 785.75 Q 333.41, 785.32, 323.29, 784.51 Q 313.18, 783.93, 303.06, 783.35 Q 292.94,\
            784.00, 282.82, 784.40 Q 272.71, 784.65, 262.59, 785.05 Q 252.47, 785.48, 242.35, 785.51 Q 232.24, 784.99, 222.12, 785.31\
            Q 212.00, 785.35, 201.88, 785.49 Q 191.76, 785.58, 181.65, 785.47 Q 171.53, 785.11, 161.41, 784.95 Q 151.29, 784.98, 141.18,\
            785.22 Q 131.06, 784.71, 120.94, 784.62 Q 110.82, 783.48, 100.71, 783.84 Q 90.59, 784.35, 80.47, 785.08 Q 70.35, 785.76, 60.24,\
            785.60 Q 50.12, 784.82, 39.46, 784.54 Q 39.04, 774.15, 38.78, 763.83 Q 38.64, 753.58, 38.66, 743.36 Q 39.51, 733.15, 39.42,\
            722.98 Q 39.21, 712.81, 39.79, 702.63 Q 39.47, 692.46, 39.08, 682.29 Q 39.11, 672.12, 38.99, 661.95 Q 38.79, 651.78, 38.98,\
            641.61 Q 38.75, 631.43, 38.83, 621.26 Q 38.91, 611.09, 39.22, 600.92 Q 39.67, 590.75, 39.05, 580.58 Q 38.93, 570.41, 39.53,\
            560.24 Q 39.17, 550.07, 38.64, 539.89 Q 38.95, 529.72, 39.03, 519.55 Q 39.25, 509.38, 39.34, 499.21 Q 38.58, 489.04, 38.96,\
            478.87 Q 38.46, 468.70, 38.78, 458.53 Q 39.29, 448.36, 39.56, 438.18 Q 39.61, 428.01, 39.61, 417.84 Q 39.75, 407.67, 38.88,\
            397.50 Q 38.91, 387.33, 39.16, 377.16 Q 39.37, 366.99, 39.20, 356.82 Q 39.50, 346.64, 39.53, 336.47 Q 38.83, 326.30, 38.66,\
            316.13 Q 39.50, 305.96, 39.56, 295.79 Q 40.05, 285.62, 39.42, 275.45 Q 38.45, 265.28, 39.21, 255.11 Q 39.61, 244.93, 39.50,\
            234.76 Q 40.13, 224.59, 40.78, 214.42 Q 41.00, 204.25, 41.00, 194.08 Q 41.01, 183.91, 39.91, 173.74 Q 40.15, 163.57, 39.83,\
            153.39 Q 39.48, 143.22, 39.18, 133.05 Q 39.63, 122.88, 40.25, 112.71 Q 39.81, 102.54, 39.18, 92.37 Q 38.72, 82.20, 40.12,\
            72.03 Q 39.65, 61.86, 39.30, 51.68 Q 39.91, 41.51, 40.61, 31.34 Q 40.00, 21.17, 40.00, 11.00" style=" fill:white;"/>\
         </svg:svg>\
      </div>\
   </div>\
</div>');