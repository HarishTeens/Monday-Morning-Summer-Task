rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__2120475796-layer" class="layer" name="__containerId__pageLayer" data-layer-id="2120475796" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-2120475796-layer-207635179" style="position: absolute; left: 5px; top: 0px; width: 1375px; height: 820px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="207635179" data-review-reference-id="207635179">\
            <div class="stencil-wrapper" style="width: 1375px; height: 820px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 820px;width:1375px;" width="1375" height="820" viewBox="0 0 1375 820">\
                     <svg:g width="1375" height="820">\
                        <svg:rect x="0" y="0" width="1375" height="820" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="1375" y2="820" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="820" x2="1375" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-707383384" style="position: absolute; left: 170px; top: 0px; width: 970px; height: 120px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="707383384" data-review-reference-id="707383384">\
            <div class="stencil-wrapper" style="width: 970px; height: 120px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 120px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 120px;width:970px;" width="970" height="120" viewBox="0 0 970 120">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="120" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1461639699" style="position: absolute; left: 455px; top: 15px; width: 410px; height: 48px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1461639699" data-review-reference-id="1461639699">\
            <div class="stencil-wrapper" style="width: 410px; height: 48px">\
               <div title="" style="width:415px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 42px;">MONDAY MORNING</span> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1228519717" style="position: absolute; left: 295px; top: 85px; width: 731px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1228519717" data-review-reference-id="1228519717">\
            <div class="stencil-wrapper" style="width: 731px; height: 37px">\
               <div title="" style="width:736px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">THE OFFICIAL MEDIA BODY OF NIT ROURKELA</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-79367415" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="79367415" data-review-reference-id="79367415">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e191" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e191</title>\
<path class="path1" d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM277.357 531.417q0 6.99 4.926 11.756t11.915 4.846h150.92v152.907q0 6.911 4.846 11.915t11.756 4.926h100.559q6.99 0 11.915-4.926t5.004-11.915v-152.907h150.601q6.911 0 11.915-4.846t4.926-11.756v-100.559q0-6.99-4.926-11.756t-11.915-4.846h-150.601v-150.92q0-6.911-5.004-11.915t-11.915-4.926h-100.559q-6.99 0-11.756 4.926t-4.846 11.915v150.92h-150.92q-6.911 0-11.915 4.846t-4.926 11.756v100.559z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e368" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e368</title>\
<path class="path1" d="M181.008 679.716v-364.035q0-54.969 38.921-93.729t93.491-38.682h364.035q54.969 0 93.729 38.682t38.682 93.729v364.035q0 54.969-38.682 93.65t-93.729 38.762h-364.035q-54.57 0-93.491-38.762t-38.921-93.65zM247.255 712.839q0 13.583 9.77 23.273t23.273 9.77h430.281q13.583 0 23.353-9.77t9.77-23.273v-430.281q0-13.583-9.77-23.353t-23.353-9.77h-430.281q-13.502 0-23.273 9.77t-9.77 23.353v430.281zM345.513 425.852q4.291-10.883 17.554-10.883h264.745q13.264 0 17.554 11.36t-3.972 22.4l-126.375 175.384q-7.944 10.961-19.539 11.756t-19.539-10.089l-126.455-178.086q-8.262-10.883-3.972-21.844z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path class="path1" d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e046" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e046</title>\
<path class="path1" d="M114.842 845.172v-529.492h761.193v529.492q0 13.583-9.77 23.353t-23.273 9.77h-695.028q-13.583 0-23.353-9.77t-9.77-23.353zM114.842 282.557v-99.289q0-13.583 9.77-23.353t23.353-9.77h66.167v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.044q13.583 0 23.353 9.77t9.77 23.353v33.044h364.035v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.124q13.583 0 23.273 9.77t9.77 23.353v33.044h66.246q13.583 0 23.273 9.77t9.77 23.353v99.289h-761.193zM181.008 812.128h99.289v-99.289h-99.289v99.289zM181.008 679.716h99.289v-99.289h-99.289v99.289zM181.008 547.303h99.289v-99.289h-99.289v99.289zM313.421 812.128h99.289v-99.289h-99.289v99.289zM313.421 679.716h99.289v-99.289h-99.289v99.289zM313.421 547.303h99.289v-99.289h-99.289v99.289zM445.833 812.128h99.289v-99.289h-99.289v99.289zM445.833 679.716h99.289v-99.289h-99.289v99.289zM445.833 547.303h99.289v-99.289h-99.289v99.289zM578.167 812.128h99.289v-99.289h-99.289v99.289zM578.167 679.716h99.289v-99.289h-99.289v99.289zM578.167 547.303h99.289v-99.289h-99.289v99.289zM710.579 812.128h99.289v-99.289h-99.289v99.289zM710.579 679.716h99.289v-99.289h-99.289v99.289zM710.579 547.303h99.289v-99.289h-99.289v99.289z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e212" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e212</title>\
<path class="path1" d="M181.008 563.586v-164.821q0-6.674 5.163-11.756t11.756-5.163h280.95v-171.413q0-6.99 3.972-8.817t9.294 2.463l345.208 266.812q5.639 4.291 5.639 10.247t-5.639 10.247l-344.893 267.129q-5.639 3.972-9.612 2.145t-3.972-8.817v-171.413h-280.95q-6.592 0-11.756-5.164t-5.163-11.677z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-176780162" style="position: absolute; left: 170px; top: 120px; width: 970px; height: 60px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="176780162" data-review-reference-id="176780162">\
            <div class="stencil-wrapper" style="width: 970px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 60px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 60px;width:970px;" width="970" height="60" viewBox="0 0 970 60">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="60" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-255672602" style="position: absolute; left: 240px; top: 135px; width: 52px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="255672602" data-review-reference-id="255672602">\
            <div class="stencil-wrapper" style="width: 52px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:52px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="52" height="30" viewBox="0 0 52 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 42,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="26" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Home</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 52px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-2120475796-layer-255672602\', \'873198243\', {"button":"left","id":"469899381","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction425964047","options":"reloadOnly","target":"page353048828","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-2120475796-layer-580256433" style="position: absolute; left: 340px; top: 135px; width: 550px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="580256433" data-review-reference-id="580256433">\
            <div class="stencil-wrapper" style="width: 550px; height: 30px">\
               <div title=""><input id="__containerId__-2120475796-layer-580256433input" value="Search Box" style="width:548px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-446376350" style="position: absolute; left: 955px; top: 135px; width: 50px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="446376350" data-review-reference-id="446376350">\
            <div class="stencil-wrapper" style="width: 50px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:50px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="50" height="30" viewBox="0 0 50 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 40,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="25" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Login</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-78246833" style="position: absolute; left: 1045px; top: 135px; width: 59px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="78246833" data-review-reference-id="78246833">\
            <div class="stencil-wrapper" style="width: 59px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:59px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="59" height="30" viewBox="0 0 59 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 49,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="29.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">SignUp</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-2001994705" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="2001994705" data-review-reference-id="2001994705">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1202713320" style="position: absolute; left: 0px; top: 778px; width: 1375px; height: 40px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1202713320" data-review-reference-id="1202713320">\
            <div class="stencil-wrapper" style="width: 1375px; height: 40px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 40px; width:1375px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 40px;width:1375px;" width="1375" height="40" viewBox="0 0 1375 40">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="1375" height="40" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-762553459" style="position: absolute; left: 455px; top: 783px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="762553459" data-review-reference-id="762553459">\
            <div class="stencil-wrapper" style="width: 403px; height: 20px">\
               <div title="" style="width:408px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Fixed footer for ASK A QUESTION AND FORUM </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-textinput195912019" style="position: absolute; left: 210px; top: 210px; width: 865px; height: 55px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput195912019" data-review-reference-id="textinput195912019">\
            <div class="stencil-wrapper" style="width: 865px; height: 55px">\
               <div title=""><textarea id="__containerId__-2120475796-layer-textinput195912019input" rows="" cols="" style="width:863px;height:51px;padding: 0px;border-width:1px;">*Entered query *</textarea></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1306687622" style="position: absolute; left: 1025px; top: 220px; width: 39px; height: 39px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1306687622" data-review-reference-id="1306687622">\
            <div class="stencil-wrapper" style="width: 39px; height: 39px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:39px;height:39px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="39" height="39" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1587265112" style="position: absolute; left: 175px; top: 287px; width: 700px; height: 444px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1587265112" data-review-reference-id="1587265112">\
            <div class="stencil-wrapper" style="width: 700px; height: 444px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 444px; width:700px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 444px;width:700px;" width="700" height="444" viewBox="0 0 700 444">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="700" height="444" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1944081321" style="position: absolute; left: 875px; top: 287px; width: 270px; height: 442px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1944081321" data-review-reference-id="1944081321">\
            <div class="stencil-wrapper" style="width: 270px; height: 442px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 442px; width:270px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 442px;width:270px;" width="270" height="442" viewBox="0 0 270 442">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="270" height="442" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1878280266" style="position: absolute; left: 910px; top: 327px; width: 188px; height: 184px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1878280266" data-review-reference-id="1878280266">\
            <div class="stencil-wrapper" style="width: 188px; height: 184px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textblock2"><p style="font-size: 14px;"><span style="font-size: 18px;"><strong>POLL</strong><br /><br />Lorem ipsum dolor sit amet, consetetur\
                        sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-578471091" style="position: absolute; left: 695px; top: 362px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="578471091" data-review-reference-id="578471091">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105" viewBox="0 0 160 105">\
                     <svg:g width="160" height="105">\
                        <svg:rect x="0" y="0" width="160" height="105" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="160" y2="105" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="105" x2="160" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-2053049038" style="position: absolute; left: 475px; top: 362px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="2053049038" data-review-reference-id="2053049038">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105" viewBox="0 0 160 105">\
                     <svg:g width="160" height="105">\
                        <svg:rect x="0" y="0" width="160" height="105" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="160" y2="105" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="105" x2="160" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1084387657" style="position: absolute; left: 255px; top: 362px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1084387657" data-review-reference-id="1084387657">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105" viewBox="0 0 160 105">\
                     <svg:g width="160" height="105">\
                        <svg:rect x="0" y="0" width="160" height="105" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="160" y2="105" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="105" x2="160" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-863147732" style="position: absolute; left: 250px; top: 532px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="863147732" data-review-reference-id="863147732">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105" viewBox="0 0 160 105">\
                     <svg:g width="160" height="105">\
                        <svg:rect x="0" y="0" width="160" height="105" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="160" y2="105" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="105" x2="160" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1216323317" style="position: absolute; left: 470px; top: 532px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1216323317" data-review-reference-id="1216323317">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105" viewBox="0 0 160 105">\
                     <svg:g width="160" height="105">\
                        <svg:rect x="0" y="0" width="160" height="105" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="160" y2="105" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="105" x2="160" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1017474405" style="position: absolute; left: 690px; top: 532px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1017474405" data-review-reference-id="1017474405">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105" viewBox="0 0 160 105">\
                     <svg:g width="160" height="105">\
                        <svg:rect x="0" y="0" width="160" height="105" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="160" y2="105" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="105" x2="160" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1789137582" style="position: absolute; left: 175px; top: 15px; width: 95px; height: 80px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1789137582" data-review-reference-id="1789137582">\
            <div class="stencil-wrapper" style="width: 95px; height: 80px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 80px;width:95px;" width="95" height="80" viewBox="0 0 95 80">\
                     <svg:g width="95" height="80">\
                        <svg:rect x="0" y="0" width="95" height="80" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="95" y2="80" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="80" x2="95" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="2120475796"] .border-wrapper, body[data-current-page-id="2120475796"] .simulation-container{\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="2120475796"] .border-wrapper, body.has-frame[data-current-page-id="2120475796"] .simulation-container{\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="2120475796"] .svg-border-1366-768{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="2120475796"] .border-wrapper .border-div{\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "2120475796",\
      			"name": "search results",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');