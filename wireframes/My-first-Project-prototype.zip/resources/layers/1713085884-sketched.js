rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__1713085884-layer" class="layer" name="__containerId__pageLayer" data-layer-id="1713085884" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-1713085884-layer-1405824351" style="position: absolute; left: 0px; top: 0px; width: 1375px; height: 820px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1405824351" data-review-reference-id="1405824351">\
            <div class="stencil-wrapper" style="width: 1375px; height: 820px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 820px;width:1375px;" width="1375" height="820">\
                     <svg:g width="1375" height="820"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.08, 0.27, 22.16, 0.40 Q 32.24, 0.51, 42.32, 1.03 Q\
                        52.40, 0.24, 62.49, -0.07 Q 72.57, -0.10, 82.65, 0.75 Q 92.73, 0.43, 102.81, 0.34 Q 112.89, 0.46, 122.97, 0.66 Q 133.05, 0.33,\
                        143.13, 0.47 Q 153.21, 1.33, 163.29, 1.61 Q 173.38, 1.36, 183.46, 0.77 Q 193.54, 0.39, 203.62, 0.57 Q 213.70, 1.01, 223.78,\
                        0.82 Q 233.86, 0.76, 243.94, 0.73 Q 254.02, 0.72, 264.10, 0.58 Q 274.18, 1.03, 284.26, 1.05 Q 294.35, 0.97, 304.43, 0.85 Q\
                        314.51, 0.56, 324.59, 1.05 Q 334.67, 0.36, 344.75, 0.32 Q 354.83, 0.12, 364.91, 0.11 Q 374.99, 0.26, 385.07, 0.17 Q 395.15,\
                        0.06, 405.24, -0.04 Q 415.32, 0.14, 425.40, 0.37 Q 435.48, -0.04, 445.56, 0.37 Q 455.64, 0.81, 465.72, 1.19 Q 475.80, 1.23,\
                        485.88, 1.82 Q 495.96, 1.57, 506.04, 1.73 Q 516.12, 0.93, 526.21, 0.91 Q 536.29, 0.98, 546.37, 1.58 Q 556.45, 1.42, 566.53,\
                        2.01 Q 576.61, 1.82, 586.69, 1.86 Q 596.77, 1.62, 606.85, 1.65 Q 616.93, 0.89, 627.01, 0.91 Q 637.10, 0.84, 647.18, 1.83 Q\
                        657.26, 1.88, 667.34, 1.29 Q 677.42, 1.63, 687.50, 0.11 Q 697.58, 1.39, 707.66, 0.32 Q 717.74, 0.29, 727.82, 0.55 Q 737.90,\
                        0.58, 747.98, 0.51 Q 758.07, 0.33, 768.15, 0.22 Q 778.23, -0.06, 788.31, 0.78 Q 798.39, 0.40, 808.47, 0.29 Q 818.55, 0.23,\
                        828.63, 0.70 Q 838.71, 1.25, 848.79, 0.74 Q 858.87, 1.10, 868.96, -0.03 Q 879.04, 1.42, 889.12, 1.04 Q 899.20, 0.95, 909.28,\
                        1.18 Q 919.36, 1.23, 929.44, 1.03 Q 939.52, 0.85, 949.60, 1.09 Q 959.68, 1.06, 969.76, 1.89 Q 979.84, 1.32, 989.93, 1.48 Q\
                        1000.01, 1.45, 1010.09, 1.48 Q 1020.17, 1.19, 1030.25, 0.40 Q 1040.33, 0.87, 1050.41, 0.78 Q 1060.49, 1.16, 1070.57, 0.82\
                        Q 1080.65, 1.16, 1090.73, 1.53 Q 1100.82, 1.74, 1110.90, 1.64 Q 1120.98, 2.50, 1131.06, 2.62 Q 1141.14, 1.82, 1151.22, 1.93\
                        Q 1161.30, 2.14, 1171.38, 2.70 Q 1181.46, 2.48, 1191.54, 2.31 Q 1201.63, 1.49, 1211.71, 1.77 Q 1221.79, 1.63, 1231.87, 0.71\
                        Q 1241.95, 0.98, 1252.03, 1.08 Q 1262.11, 1.14, 1272.19, 1.02 Q 1282.27, 1.48, 1292.35, 2.26 Q 1302.43, 2.86, 1312.52, 2.84\
                        Q 1322.60, 1.46, 1332.68, 2.24 Q 1342.76, 2.61, 1352.84, 2.93 Q 1362.92, 1.78, 1373.90, 1.10 Q 1373.60, 12.00, 1372.58, 22.46\
                        Q 1372.90, 32.61, 1374.01, 42.77 Q 1373.35, 52.99, 1374.04, 63.19 Q 1373.86, 73.40, 1373.66, 83.60 Q 1372.74, 93.80, 1374.01,\
                        104.00 Q 1373.24, 114.20, 1373.45, 124.40 Q 1373.96, 134.60, 1373.69, 144.80 Q 1374.07, 155.00, 1374.29, 165.20 Q 1374.41,\
                        175.40, 1374.71, 185.60 Q 1374.82, 195.80, 1373.42, 206.00 Q 1373.24, 216.20, 1373.29, 226.40 Q 1373.12, 236.60, 1373.80,\
                        246.80 Q 1372.85, 257.00, 1374.49, 267.20 Q 1373.56, 277.40, 1374.36, 287.60 Q 1373.77, 297.80, 1373.37, 308.00 Q 1374.26,\
                        318.20, 1373.77, 328.40 Q 1373.19, 338.60, 1373.86, 348.80 Q 1374.72, 359.00, 1375.36, 369.20 Q 1375.09, 379.40, 1373.22,\
                        389.60 Q 1372.78, 399.80, 1373.93, 410.00 Q 1374.29, 420.20, 1374.23, 430.40 Q 1374.01, 440.60, 1373.94, 450.80 Q 1374.13,\
                        461.00, 1373.81, 471.20 Q 1373.60, 481.40, 1373.52, 491.60 Q 1373.77, 501.80, 1374.16, 512.00 Q 1373.81, 522.20, 1373.94,\
                        532.40 Q 1374.26, 542.60, 1374.06, 552.80 Q 1372.83, 563.00, 1372.48, 573.20 Q 1372.75, 583.40, 1373.24, 593.60 Q 1373.29,\
                        603.80, 1372.21, 614.00 Q 1372.90, 624.20, 1372.89, 634.40 Q 1372.64, 644.60, 1372.84, 654.80 Q 1372.96, 665.00, 1373.41,\
                        675.20 Q 1374.29, 685.40, 1374.52, 695.60 Q 1374.05, 705.80, 1373.54, 716.00 Q 1373.73, 726.20, 1373.62, 736.40 Q 1373.38,\
                        746.60, 1373.26, 756.80 Q 1373.62, 767.00, 1373.32, 777.20 Q 1373.65, 787.40, 1373.40, 797.60 Q 1373.77, 807.80, 1373.32,\
                        818.32 Q 1363.12, 818.60, 1352.86, 818.15 Q 1342.78, 818.38, 1332.68, 818.11 Q 1322.59, 817.77, 1312.51, 817.12 Q 1302.43,\
                        817.38, 1292.35, 817.39 Q 1282.27, 818.01, 1272.19, 818.15 Q 1262.11, 818.05, 1252.03, 818.07 Q 1241.95, 818.17, 1231.87,\
                        817.33 Q 1221.79, 817.32, 1211.71, 816.37 Q 1201.63, 817.30, 1191.54, 817.08 Q 1181.46, 817.58, 1171.38, 817.29 Q 1161.30,\
                        818.12, 1151.22, 818.96 Q 1141.14, 818.86, 1131.06, 818.35 Q 1120.98, 817.39, 1110.90, 817.78 Q 1100.82, 819.23, 1090.73,\
                        819.62 Q 1080.65, 819.55, 1070.57, 819.10 Q 1060.49, 819.12, 1050.41, 819.00 Q 1040.33, 818.25, 1030.25, 818.18 Q 1020.17,\
                        818.56, 1010.09, 819.26 Q 1000.01, 819.34, 989.93, 819.18 Q 979.84, 818.76, 969.76, 819.10 Q 959.68, 819.25, 949.60, 818.34\
                        Q 939.52, 817.16, 929.44, 817.92 Q 919.36, 819.04, 909.28, 818.69 Q 899.20, 817.98, 889.12, 817.69 Q 879.04, 817.50, 868.96,\
                        817.50 Q 858.87, 817.23, 848.79, 817.65 Q 838.71, 817.38, 828.63, 818.66 Q 818.55, 819.20, 808.47, 820.49 Q 798.39, 819.83,\
                        788.31, 819.18 Q 778.23, 819.37, 768.15, 817.84 Q 758.07, 817.96, 747.98, 817.96 Q 737.90, 818.75, 727.82, 818.43 Q 717.74,\
                        817.50, 707.66, 817.47 Q 697.58, 818.76, 687.50, 819.20 Q 677.42, 819.21, 667.34, 819.30 Q 657.26, 818.42, 647.18, 818.77\
                        Q 637.10, 818.16, 627.01, 817.36 Q 616.93, 817.72, 606.85, 819.69 Q 596.77, 819.50, 586.69, 818.64 Q 576.61, 818.11, 566.53,\
                        818.74 Q 556.45, 819.06, 546.37, 818.93 Q 536.29, 819.12, 526.21, 818.59 Q 516.12, 819.14, 506.04, 819.01 Q 495.96, 818.89,\
                        485.88, 819.61 Q 475.80, 818.75, 465.72, 819.78 Q 455.64, 819.69, 445.56, 820.15 Q 435.48, 820.09, 425.40, 820.08 Q 415.32,\
                        819.37, 405.24, 818.13 Q 395.15, 817.47, 385.07, 817.57 Q 374.99, 818.13, 364.91, 818.01 Q 354.83, 817.47, 344.75, 817.44\
                        Q 334.67, 818.31, 324.59, 818.52 Q 314.51, 817.20, 304.43, 817.69 Q 294.35, 817.90, 284.26, 818.89 Q 274.18, 818.67, 264.10,\
                        817.96 Q 254.02, 818.05, 243.94, 819.08 Q 233.86, 819.00, 223.78, 818.05 Q 213.70, 816.26, 203.62, 817.98 Q 193.54, 818.65,\
                        183.46, 819.41 Q 173.38, 819.25, 163.29, 818.67 Q 153.21, 818.65, 143.13, 818.82 Q 133.05, 818.88, 122.97, 820.19 Q 112.89,\
                        820.32, 102.81, 820.41 Q 92.73, 820.63, 82.65, 820.68 Q 72.57, 820.27, 62.49, 820.18 Q 52.40, 819.77, 42.32, 818.31 Q 32.24,\
                        816.94, 22.16, 817.91 Q 12.08, 818.97, 1.39, 818.61 Q 1.06, 808.11, 1.16, 797.72 Q 0.77, 787.48, 0.57, 777.25 Q 0.53, 767.02,\
                        0.40, 756.81 Q 0.22, 746.61, 0.66, 736.40 Q 0.98, 726.20, 0.30, 716.00 Q 0.23, 705.80, 0.34, 695.60 Q 0.28, 685.40, 0.16,\
                        675.20 Q 1.04, 665.00, 0.62, 654.80 Q 0.02, 644.60, 0.93, 634.40 Q 0.52, 624.20, 0.34, 614.00 Q 0.45, 603.80, 0.66, 593.60\
                        Q 1.29, 583.40, 0.65, 573.20 Q 0.30, 563.00, 0.90, 552.80 Q 0.88, 542.60, 0.75, 532.40 Q 1.38, 522.20, 1.98, 512.00 Q 1.79,\
                        501.80, 1.58, 491.60 Q 1.00, 481.40, 1.32, 471.20 Q 1.18, 461.00, 1.10, 450.80 Q 0.88, 440.60, 0.82, 430.40 Q 1.55, 420.20,\
                        2.52, 410.00 Q 1.74, 399.80, 0.86, 389.60 Q 1.14, 379.40, 0.68, 369.20 Q 0.67, 359.00, 1.03, 348.80 Q 1.08, 338.60, 1.24,\
                        328.40 Q 0.95, 318.20, 1.13, 308.00 Q 0.43, 297.80, 0.35, 287.60 Q 0.05, 277.40, 0.09, 267.20 Q 0.04, 257.00, 0.46, 246.80\
                        Q 0.35, 236.60, 0.37, 226.40 Q 0.31, 216.20, 0.83, 206.00 Q 0.36, 195.80, 0.72, 185.60 Q 0.83, 175.40, 1.16, 165.20 Q 0.90,\
                        155.00, 0.86, 144.80 Q 1.69, 134.60, 1.69, 124.40 Q 0.90, 114.20, 0.90, 104.00 Q 1.03, 93.80, 1.80, 83.60 Q 1.06, 73.40, 1.46,\
                        63.20 Q 2.09, 53.00, 2.56, 42.80 Q 2.01, 32.60, 1.58, 22.40 Q 2.00, 12.20, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 10.78, 6.99, 19.24, 12.53 Q 28.08, 17.40, 35.91, 23.99 Q 44.75,\
                        28.89, 53.87, 33.31 Q 62.39, 38.74, 70.67, 44.58 Q 79.29, 49.84, 88.33, 54.39 Q 97.31, 59.05, 106.32, 63.65 Q 115.03, 68.76,\
                        123.50, 74.27 Q 131.92, 79.87, 140.51, 85.17 Q 149.16, 90.38, 157.53, 96.07 Q 166.80, 100.24, 175.11, 106.02 Q 184.62, 109.79,\
                        192.60, 116.13 Q 201.63, 120.70, 210.51, 125.52 Q 219.42, 130.29, 227.96, 135.69 Q 236.49, 141.09, 245.10, 146.37 Q 253.61,\
                        151.82, 261.91, 157.62 Q 270.81, 162.42, 279.82, 167.02 Q 288.54, 172.10, 297.36, 177.04 Q 305.70, 182.76, 313.93, 188.67\
                        Q 323.33, 192.64, 331.56, 198.54 Q 340.20, 203.78, 348.52, 209.54 Q 357.61, 214.02, 367.10, 217.80 Q 375.38, 223.65, 383.55,\
                        229.65 Q 392.42, 234.50, 401.43, 239.10 Q 410.42, 243.74, 418.91, 249.22 Q 427.87, 253.90, 436.64, 258.92 Q 445.27, 264.15,\
                        453.73, 269.68 Q 462.50, 274.70, 470.74, 280.60 Q 479.77, 285.17, 488.34, 290.52 Q 496.52, 296.52, 505.59, 301.02 Q 514.41,\
                        305.95, 522.60, 311.92 Q 531.33, 317.00, 540.16, 321.91 Q 549.30, 326.31, 557.72, 331.89 Q 566.06, 337.62, 575.09, 342.19\
                        Q 583.37, 348.04, 592.23, 352.89 Q 600.78, 358.27, 609.26, 363.76 Q 617.72, 369.29, 626.56, 374.18 Q 635.84, 378.33, 644.91,\
                        382.84 Q 653.44, 388.26, 661.39, 394.64 Q 669.83, 400.20, 679.01, 404.53 Q 687.44, 410.11, 696.00, 415.47 Q 704.50, 420.92,\
                        713.83, 424.99 Q 723.10, 429.16, 732.11, 433.76 Q 740.41, 439.56, 748.64, 445.48 Q 756.87, 451.40, 765.05, 457.39 Q 773.85,\
                        462.35, 782.68, 467.27 Q 791.59, 472.04, 800.88, 476.17 Q 809.84, 480.87, 818.37, 486.28 Q 826.89, 491.70, 835.49, 496.99\
                        Q 844.02, 502.42, 853.09, 506.91 Q 861.77, 512.07, 870.65, 516.90 Q 879.50, 521.77, 888.13, 527.01 Q 896.39, 532.89, 905.05,\
                        538.08 Q 913.76, 543.18, 922.24, 548.67 Q 931.02, 553.67, 939.40, 559.34 Q 948.19, 564.31, 957.17, 568.97 Q 966.00, 573.88,\
                        974.55, 579.25 Q 982.72, 585.27, 991.38, 590.46 Q 1000.77, 594.44, 1009.17, 600.06 Q 1018.38, 604.33, 1026.39, 610.61 Q 1034.84,\
                        616.16, 1043.19, 621.87 Q 1051.58, 627.52, 1060.65, 632.02 Q 1069.46, 636.97, 1077.93, 642.48 Q 1086.77, 647.38, 1095.88,\
                        651.82 Q 1104.61, 656.88, 1113.05, 662.45 Q 1121.41, 668.14, 1130.04, 673.39 Q 1138.82, 678.38, 1147.89, 682.90 Q 1156.49,\
                        688.19, 1164.37, 694.69 Q 1173.84, 698.52, 1182.07, 704.43 Q 1191.01, 709.15, 1199.65, 714.38 Q 1208.40, 719.42, 1217.05,\
                        724.64 Q 1225.83, 729.63, 1234.44, 734.91 Q 1242.80, 740.60, 1251.79, 745.25 Q 1260.71, 749.99, 1269.53, 754.92 Q 1278.50,\
                        759.61, 1286.82, 765.36 Q 1295.17, 771.08, 1303.82, 776.29 Q 1312.10, 782.12, 1320.40, 787.92 Q 1329.13, 792.99, 1338.24,\
                        797.43 Q 1347.61, 801.44, 1356.54, 806.18 Q 1364.33, 812.83, 1373.00, 818.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 818.00 Q 9.71, 811.19, 18.36, 805.95 Q 27.21, 801.07, 35.89, 795.87 Q\
                        44.65, 790.83, 53.47, 785.89 Q 62.12, 780.66, 71.02, 775.84 Q 79.53, 770.37, 88.47, 765.63 Q 97.25, 760.63, 106.04, 755.62\
                        Q 114.74, 750.47, 123.27, 745.04 Q 132.34, 740.51, 140.83, 735.02 Q 149.61, 730.01, 158.17, 724.62 Q 166.98, 719.66, 175.73,\
                        714.60 Q 184.28, 709.19, 192.91, 703.92 Q 201.40, 698.43, 210.58, 694.09 Q 219.34, 689.05, 227.79, 683.48 Q 235.88, 677.31,\
                        244.95, 672.78 Q 254.10, 668.38, 262.76, 663.17 Q 271.09, 657.41, 279.83, 652.33 Q 289.05, 648.04, 297.23, 642.03 Q 305.74,\
                        636.55, 314.51, 631.52 Q 323.21, 626.38, 332.22, 621.76 Q 340.89, 616.56, 349.86, 611.86 Q 358.58, 606.76, 367.03, 601.18\
                        Q 375.67, 595.94, 384.08, 590.29 Q 392.89, 585.34, 401.42, 579.91 Q 409.95, 574.47, 419.54, 570.81 Q 427.95, 565.19, 436.66,\
                        560.05 Q 445.12, 554.51, 453.68, 549.11 Q 461.74, 542.89, 470.40, 537.68 Q 479.24, 532.76, 488.37, 528.34 Q 497.53, 523.97,\
                        506.29, 518.93 Q 514.78, 513.42, 523.54, 508.38 Q 532.05, 502.90, 540.19, 496.81 Q 548.66, 491.28, 557.48, 486.33 Q 566.49,\
                        481.71, 575.63, 477.30 Q 583.78, 471.22, 592.53, 466.17 Q 601.22, 461.00, 609.92, 455.86 Q 618.59, 450.66, 627.31, 445.54\
                        Q 636.09, 440.52, 644.53, 434.94 Q 653.68, 430.56, 662.49, 425.59 Q 671.41, 420.82, 679.63, 414.86 Q 688.26, 409.60, 697.27,\
                        404.96 Q 706.13, 400.08, 714.54, 394.46 Q 722.58, 388.20, 731.76, 383.86 Q 740.86, 379.38, 749.46, 374.07 Q 757.81, 368.33,\
                        766.22, 362.70 Q 775.10, 357.86, 783.64, 352.43 Q 792.83, 348.11, 801.39, 342.73 Q 809.70, 336.92, 818.55, 332.03 Q 827.87,\
                        327.92, 836.74, 323.06 Q 845.09, 317.33, 853.81, 312.21 Q 862.40, 306.89, 871.04, 301.63 Q 879.58, 296.22, 887.96, 290.53\
                        Q 896.48, 285.09, 905.39, 280.29 Q 914.02, 275.03, 922.48, 269.47 Q 931.13, 264.24, 940.10, 259.54 Q 948.99, 254.72, 957.96,\
                        250.02 Q 966.54, 244.67, 975.40, 239.79 Q 983.98, 234.45, 992.36, 228.76 Q 1000.97, 223.47, 1009.36, 217.78 Q 1017.77, 212.15,\
                        1026.38, 206.86 Q 1035.44, 202.32, 1044.12, 197.13 Q 1053.36, 192.90, 1062.07, 187.77 Q 1070.65, 182.42, 1079.22, 177.05 Q\
                        1087.73, 171.59, 1096.33, 166.27 Q 1105.07, 161.18, 1113.95, 156.35 Q 1122.85, 151.54, 1131.56, 146.40 Q 1140.17, 141.10,\
                        1149.03, 136.23 Q 1157.31, 130.37, 1165.44, 124.26 Q 1173.94, 118.78, 1182.75, 113.81 Q 1191.50, 108.75, 1200.24, 103.68 Q\
                        1209.05, 98.71, 1217.70, 93.48 Q 1226.32, 88.20, 1234.96, 82.94 Q 1243.70, 77.87, 1252.49, 72.88 Q 1261.66, 68.52, 1270.57,\
                        63.72 Q 1278.94, 58.02, 1287.50, 52.63 Q 1296.69, 48.31, 1305.49, 43.33 Q 1314.09, 38.02, 1323.08, 33.35 Q 1331.12, 27.10,\
                        1340.30, 22.76 Q 1348.70, 17.11, 1357.12, 11.49 Q 1366.31, 7.17, 1375.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-336460015" style="position: absolute; left: 170px; top: 0px; width: 970px; height: 120px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="336460015" data-review-reference-id="336460015">\
            <div class="stencil-wrapper" style="width: 970px; height: 120px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 120px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 120px;width:970px;" width="970" height="120" viewBox="0 0 970 120">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="120" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-1653673494" style="position: absolute; left: 455px; top: 15px; width: 410px; height: 48px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1653673494" data-review-reference-id="1653673494">\
            <div class="stencil-wrapper" style="width: 410px; height: 48px">\
               <div title="" style="width:415px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 42px;">MONDAY MORNING</span> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-2066919949" style="position: absolute; left: 295px; top: 85px; width: 731px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2066919949" data-review-reference-id="2066919949">\
            <div class="stencil-wrapper" style="width: 731px; height: 37px">\
               <div title="" style="width:736px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">THE OFFICIAL MEDIA BODY OF NIT ROURKELA</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-1782110545" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1782110545" data-review-reference-id="1782110545">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e191" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e191</title>\
<path class="path1" d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM277.357 531.417q0 6.99 4.926 11.756t11.915 4.846h150.92v152.907q0 6.911 4.846 11.915t11.756 4.926h100.559q6.99 0 11.915-4.926t5.004-11.915v-152.907h150.601q6.911 0 11.915-4.846t4.926-11.756v-100.559q0-6.99-4.926-11.756t-11.915-4.846h-150.601v-150.92q0-6.911-5.004-11.915t-11.915-4.926h-100.559q-6.99 0-11.756 4.926t-4.846 11.915v150.92h-150.92q-6.911 0-11.915 4.846t-4.926 11.756v100.559z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e368" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e368</title>\
<path class="path1" d="M181.008 679.716v-364.035q0-54.969 38.921-93.729t93.491-38.682h364.035q54.969 0 93.729 38.682t38.682 93.729v364.035q0 54.969-38.682 93.65t-93.729 38.762h-364.035q-54.57 0-93.491-38.762t-38.921-93.65zM247.255 712.839q0 13.583 9.77 23.273t23.273 9.77h430.281q13.583 0 23.353-9.77t9.77-23.273v-430.281q0-13.583-9.77-23.353t-23.353-9.77h-430.281q-13.502 0-23.273 9.77t-9.77 23.353v430.281zM345.513 425.852q4.291-10.883 17.554-10.883h264.745q13.264 0 17.554 11.36t-3.972 22.4l-126.375 175.384q-7.944 10.961-19.539 11.756t-19.539-10.089l-126.455-178.086q-8.262-10.883-3.972-21.844z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path class="path1" d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e046" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e046</title>\
<path class="path1" d="M114.842 845.172v-529.492h761.193v529.492q0 13.583-9.77 23.353t-23.273 9.77h-695.028q-13.583 0-23.353-9.77t-9.77-23.353zM114.842 282.557v-99.289q0-13.583 9.77-23.353t23.353-9.77h66.167v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.044q13.583 0 23.353 9.77t9.77 23.353v33.044h364.035v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.124q13.583 0 23.273 9.77t9.77 23.353v33.044h66.246q13.583 0 23.273 9.77t9.77 23.353v99.289h-761.193zM181.008 812.128h99.289v-99.289h-99.289v99.289zM181.008 679.716h99.289v-99.289h-99.289v99.289zM181.008 547.303h99.289v-99.289h-99.289v99.289zM313.421 812.128h99.289v-99.289h-99.289v99.289zM313.421 679.716h99.289v-99.289h-99.289v99.289zM313.421 547.303h99.289v-99.289h-99.289v99.289zM445.833 812.128h99.289v-99.289h-99.289v99.289zM445.833 679.716h99.289v-99.289h-99.289v99.289zM445.833 547.303h99.289v-99.289h-99.289v99.289zM578.167 812.128h99.289v-99.289h-99.289v99.289zM578.167 679.716h99.289v-99.289h-99.289v99.289zM578.167 547.303h99.289v-99.289h-99.289v99.289zM710.579 812.128h99.289v-99.289h-99.289v99.289zM710.579 679.716h99.289v-99.289h-99.289v99.289zM710.579 547.303h99.289v-99.289h-99.289v99.289z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e212" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e212</title>\
<path class="path1" d="M181.008 563.586v-164.821q0-6.674 5.163-11.756t11.756-5.163h280.95v-171.413q0-6.99 3.972-8.817t9.294 2.463l345.208 266.812q5.639 4.291 5.639 10.247t-5.639 10.247l-344.893 267.129q-5.639 3.972-9.612 2.145t-3.972-8.817v-171.413h-280.95q-6.592 0-11.756-5.164t-5.163-11.677z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-402811089" style="position: absolute; left: 170px; top: 120px; width: 970px; height: 60px" data-interactive-element-type="default.clickArea" class="clickArea pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="402811089" data-review-reference-id="402811089">\
            <div class="stencil-wrapper" style="width: 970px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 60px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 60px;width:970px;" width="970" height="60" viewBox="0 0 970 60">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="60" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 970px; height: 60px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-1713085884-layer-402811089\', \'1877576236\', {"button":"left","id":"510728702","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction963953633","options":"reloadOnly","target":"page353048828","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-1713085884-layer-285578594" style="position: absolute; left: 240px; top: 135px; width: 52px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="285578594" data-review-reference-id="285578594">\
            <div class="stencil-wrapper" style="width: 52px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:56px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="56" height="34" viewBox="-2 -2 56 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.53, 29.44, 1.17, 28.83 Q 0.30, 27.86, -0.45, 26.46 Q -0.86,\
                        14.27, -0.98, 1.67 Q -0.01, 0.50, 0.77, -1.08 Q 1.94, -1.90, 3.43, -2.76 Q 15.19, -3.06, 26.86, -2.86 Q 38.46, -2.25, 50.19,\
                        -1.85 Q 51.41, -1.66, 52.92, -1.03 Q 53.24, 0.44, 54.13, 1.64 Q 54.46, 13.78, 54.41, 26.23 Q 53.97, 27.49, 53.22, 29.07 Q\
                        51.96, 29.78, 50.41, 30.28 Q 38.58, 29.53, 27.05, 29.70 Q 15.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="26" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Home</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-869629787" style="position: absolute; left: 340px; top: 135px; width: 550px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="869629787" data-review-reference-id="869629787">\
            <div class="stencil-wrapper" style="width: 550px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:550px;" width="550" height="30">\
                     <svg:g id="__containerId__-1713085884-layer-869629787svg" width="550" height="30"><svg:path id="__containerId__-1713085884-layer-869629787_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00\
                        Q 12.11, 1.38, 22.22, 1.57 Q 32.33, 2.07, 42.44, 1.11 Q 52.56, 1.62, 62.67, 1.56 Q 72.78, 0.47, 82.89, 0.04 Q 93.00, -0.09,\
                        103.11, -0.09 Q 113.22, 0.26, 123.33, -0.07 Q 133.44, -0.26, 143.56, 0.10 Q 153.67, 0.49, 163.78, 0.85 Q 173.89, 0.37, 184.00,\
                        0.05 Q 194.11, -0.08, 204.22, -0.13 Q 214.33, -0.16, 224.44, 0.45 Q 234.56, 1.33, 244.67, 0.37 Q 254.78, -0.39, 264.89, 0.10\
                        Q 275.00, 1.41, 285.11, 0.89 Q 295.22, 1.28, 305.33, 1.11 Q 315.44, 1.17, 325.56, 1.83 Q 335.67, 1.33, 345.78, 1.02 Q 355.89,\
                        0.57, 366.00, 0.59 Q 376.11, 0.42, 386.22, 0.64 Q 396.33, 0.51, 406.44, 0.54 Q 416.56, 0.54, 426.67, 0.35 Q 436.78, 0.23,\
                        446.89, 0.48 Q 457.00, 1.30, 467.11, 1.09 Q 477.22, 0.97, 487.33, 0.52 Q 497.44, 0.20, 507.56, 0.18 Q 517.67, 0.38, 527.78,\
                        0.94 Q 537.89, 2.08, 547.59, 2.41 Q 547.62, 15.13, 548.24, 28.24 Q 538.19, 29.12, 527.83, 28.43 Q 517.71, 28.80, 507.58, 28.84\
                        Q 497.46, 29.02, 487.34, 28.67 Q 477.22, 27.69, 467.11, 27.49 Q 457.00, 27.73, 446.89, 28.07 Q 436.78, 28.09, 426.67, 28.96\
                        Q 416.56, 29.46, 406.44, 29.79 Q 396.33, 29.83, 386.22, 29.54 Q 376.11, 29.48, 366.00, 29.40 Q 355.89, 29.14, 345.78, 29.04\
                        Q 335.67, 29.71, 325.56, 29.36 Q 315.44, 29.65, 305.33, 29.33 Q 295.22, 29.05, 285.11, 28.99 Q 275.00, 28.98, 264.89, 29.71\
                        Q 254.78, 29.83, 244.67, 29.83 Q 234.56, 29.37, 224.44, 29.54 Q 214.33, 28.18, 204.22, 27.97 Q 194.11, 28.22, 184.00, 28.39\
                        Q 173.89, 28.30, 163.78, 28.66 Q 153.67, 29.56, 143.56, 29.09 Q 133.44, 29.31, 123.33, 29.02 Q 113.22, 29.13, 103.11, 29.13\
                        Q 93.00, 28.96, 82.89, 29.00 Q 72.78, 28.78, 62.67, 29.05 Q 52.56, 28.04, 42.44, 28.81 Q 32.33, 28.65, 22.22, 28.56 Q 12.11,\
                        27.98, 2.24, 27.76 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1713085884-layer-869629787_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 2.45,\
                        23.15, 1.84 Q 33.22, 1.60, 43.30, 1.82 Q 53.37, 2.95, 63.44, 2.19 Q 73.52, 2.79, 83.59, 2.22 Q 93.67, 2.66, 103.74, 3.26 Q\
                        113.81, 2.97, 123.89, 2.70 Q 133.96, 2.71, 144.04, 4.28 Q 154.11, 3.79, 164.19, 3.47 Q 174.26, 2.83, 184.33, 2.66 Q 194.41,\
                        2.93, 204.48, 2.81 Q 214.56, 3.10, 224.63, 2.93 Q 234.70, 3.73, 244.78, 2.91 Q 254.85, 2.98, 264.93, 2.42 Q 275.00, 3.15,\
                        285.07, 3.75 Q 295.15, 4.25, 305.22, 3.35 Q 315.30, 2.50, 325.37, 3.03 Q 335.44, 2.57, 345.52, 2.38 Q 355.59, 1.62, 365.67,\
                        1.85 Q 375.74, 2.38, 385.81, 1.75 Q 395.89, 0.73, 405.96, 1.43 Q 416.04, 1.89, 426.11, 1.62 Q 436.18, 2.33, 446.26, 1.61 Q\
                        456.33, 2.38, 466.41, 2.73 Q 476.48, 1.58, 486.56, 1.41 Q 496.63, 2.11, 506.70, 2.25 Q 516.78, 2.48, 526.85, 1.58 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-869629787_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-869629787_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 2.96,\
                        23.15, 3.11 Q 33.22, 3.59, 43.30, 3.13 Q 53.37, 3.98, 63.44, 3.85 Q 73.52, 3.26, 83.59, 2.95 Q 93.67, 2.77, 103.74, 4.42 Q\
                        113.81, 4.07, 123.89, 4.14 Q 133.96, 4.19, 144.04, 3.89 Q 154.11, 4.02, 164.19, 3.27 Q 174.26, 3.13, 184.33, 2.63 Q 194.41,\
                        3.42, 204.48, 4.01 Q 214.56, 4.16, 224.63, 3.27 Q 234.70, 2.05, 244.78, 3.51 Q 254.85, 3.92, 264.93, 3.89 Q 275.00, 3.68,\
                        285.07, 3.15 Q 295.15, 3.09, 305.22, 3.43 Q 315.30, 2.77, 325.37, 2.41 Q 335.44, 2.34, 345.52, 2.90 Q 355.59, 2.43, 365.67,\
                        2.48 Q 375.74, 3.16, 385.81, 2.59 Q 395.89, 2.77, 405.96, 2.21 Q 416.04, 1.89, 426.11, 3.35 Q 436.18, 2.93, 446.26, 3.07 Q\
                        456.33, 1.88, 466.41, 1.44 Q 476.48, 1.84, 486.56, 2.51 Q 496.63, 1.50, 506.70, 3.24 Q 516.78, 3.83, 526.85, 4.26 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-869629787_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-1713085884-layer-869629787input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1713085884-layer-869629787_input_svg_border\',\'__containerId__-1713085884-layer-869629787_line1\',\'__containerId__-1713085884-layer-869629787_line2\',\'__containerId__-1713085884-layer-869629787_line3\',\'__containerId__-1713085884-layer-869629787_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1713085884-layer-869629787_input_svg_border\',\'__containerId__-1713085884-layer-869629787_line1\',\'__containerId__-1713085884-layer-869629787_line2\',\'__containerId__-1713085884-layer-869629787_line3\',\'__containerId__-1713085884-layer-869629787_line4\'))" value="Search Box" style="width:543px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-1711278925" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1711278925" data-review-reference-id="1711278925">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-2088739707" style="position: absolute; left: 0px; top: 778px; width: 1375px; height: 40px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="2088739707" data-review-reference-id="2088739707">\
            <div class="stencil-wrapper" style="width: 1375px; height: 40px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 40px; width:1375px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 40px;width:1375px;" width="1375" height="40" viewBox="0 0 1375 40">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="1375" height="40" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-446297466" style="position: absolute; left: 455px; top: 783px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="446297466" data-review-reference-id="446297466">\
            <div class="stencil-wrapper" style="width: 403px; height: 20px">\
               <div title="" style="width:408px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Fixed footer for ASK A QUESTION AND FORUM </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-340138517" style="position: absolute; left: 170px; top: 180px; width: 970px; height: 600px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="340138517" data-review-reference-id="340138517">\
            <div class="stencil-wrapper" style="width: 970px; height: 600px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 600px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 600px;width:970px;" width="970" height="600" viewBox="0 0 970 600">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="600" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-text784996323" style="position: absolute; left: 585px; top: 230px; width: 132px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text784996323" data-review-reference-id="text784996323">\
            <div class="stencil-wrapper" style="width: 132px; height: 37px">\
               <div title="" style="width:137px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">New Poll</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-textinput575568579" style="position: absolute; left: 330px; top: 305px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput575568579" data-review-reference-id="textinput575568579">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                     <svg:g id="__containerId__-1713085884-layer-textinput575568579svg" width="150" height="30"><svg:path id="__containerId__-1713085884-layer-textinput575568579_input_svg_border" class=" svg_unselected_element" d="M 2.00,\
                        2.00 Q 12.43, 1.12, 22.86, 1.06 Q 33.29, 1.07, 43.71, 1.40 Q 54.14, 1.57, 64.57, 1.84 Q 75.00, 1.39, 85.43, 1.71 Q 95.86,\
                        1.61, 106.29, 2.07 Q 116.71, 1.50, 127.14, 2.58 Q 137.57, 1.86, 148.26, 1.74 Q 147.04, 15.32, 148.08, 28.08 Q 137.65, 28.29,\
                        127.14, 27.96 Q 116.66, 26.99, 106.27, 27.26 Q 95.86, 28.66, 85.43, 28.04 Q 75.00, 27.06, 64.57, 26.60 Q 54.14, 26.28, 43.71,\
                        28.11 Q 33.29, 27.94, 22.86, 28.75 Q 12.43, 27.92, 2.25, 27.75 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1713085884-layer-textinput575568579_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 2.23, 23.57, 2.12 Q 33.86, 2.02, 44.14, 2.55 Q 54.43, 2.66, 64.71, 2.06 Q 75.00, 2.82, 85.29, 2.98 Q 95.57, 2.63, 105.86,\
                        3.17 Q 116.14, 2.44, 126.43, 2.79 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput575568579_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput575568579_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 5.39, 23.57, 5.02 Q 33.86, 4.91, 44.14, 3.78 Q 54.43, 2.93, 64.71, 3.58 Q 75.00, 3.69, 85.29, 2.98 Q 95.57, 2.16, 105.86,\
                        2.63 Q 116.14, 3.82, 126.43, 3.20 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput575568579_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-1713085884-layer-textinput575568579input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1713085884-layer-textinput575568579_input_svg_border\',\'__containerId__-1713085884-layer-textinput575568579_line1\',\'__containerId__-1713085884-layer-textinput575568579_line2\',\'__containerId__-1713085884-layer-textinput575568579_line3\',\'__containerId__-1713085884-layer-textinput575568579_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1713085884-layer-textinput575568579_input_svg_border\',\'__containerId__-1713085884-layer-textinput575568579_line1\',\'__containerId__-1713085884-layer-textinput575568579_line2\',\'__containerId__-1713085884-layer-textinput575568579_line3\',\'__containerId__-1713085884-layer-textinput575568579_line4\'))" value="Poll Question " style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-textinput663585158" style="position: absolute; left: 330px; top: 380px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput663585158" data-review-reference-id="textinput663585158">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                     <svg:g id="__containerId__-1713085884-layer-textinput663585158svg" width="150" height="30"><svg:path id="__containerId__-1713085884-layer-textinput663585158_input_svg_border" class=" svg_unselected_element" d="M 2.00,\
                        2.00 Q 12.43, 2.39, 22.86, 1.68 Q 33.29, 1.30, 43.71, 1.91 Q 54.14, 2.07, 64.57, 1.83 Q 75.00, 1.15, 85.43, 1.20 Q 95.86,\
                        2.24, 106.29, 1.31 Q 116.71, 1.59, 127.14, 2.26 Q 137.57, 1.62, 148.03, 1.97 Q 148.65, 14.78, 148.23, 28.23 Q 137.68, 28.39,\
                        127.14, 27.97 Q 116.72, 28.10, 106.30, 28.40 Q 95.86, 28.28, 85.42, 27.21 Q 75.00, 26.34, 64.57, 26.47 Q 54.14, 27.87, 43.71,\
                        28.08 Q 33.29, 28.60, 22.86, 27.86 Q 12.43, 28.53, 1.77, 28.23 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1713085884-layer-textinput663585158_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 2.61, 23.57, 2.61 Q 33.86, 2.46, 44.14, 2.45 Q 54.43, 2.30, 64.71, 2.43 Q 75.00, 2.37, 85.29, 2.45 Q 95.57, 2.43, 105.86,\
                        2.15 Q 116.14, 1.53, 126.43, 2.36 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput663585158_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput663585158_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 2.68, 23.57, 2.66 Q 33.86, 2.53, 44.14, 2.31 Q 54.43, 2.06, 64.71, 2.02 Q 75.00, 1.94, 85.29, 1.66 Q 95.57, 2.03, 105.86,\
                        1.82 Q 116.14, 1.79, 126.43, 1.74 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput663585158_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-1713085884-layer-textinput663585158input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1713085884-layer-textinput663585158_input_svg_border\',\'__containerId__-1713085884-layer-textinput663585158_line1\',\'__containerId__-1713085884-layer-textinput663585158_line2\',\'__containerId__-1713085884-layer-textinput663585158_line3\',\'__containerId__-1713085884-layer-textinput663585158_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1713085884-layer-textinput663585158_input_svg_border\',\'__containerId__-1713085884-layer-textinput663585158_line1\',\'__containerId__-1713085884-layer-textinput663585158_line2\',\'__containerId__-1713085884-layer-textinput663585158_line3\',\'__containerId__-1713085884-layer-textinput663585158_line4\'))" value="+1 Option" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-textinput868019233" style="position: absolute; left: 335px; top: 460px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput868019233" data-review-reference-id="textinput868019233">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                     <svg:g id="__containerId__-1713085884-layer-textinput868019233svg" width="150" height="30"><svg:path id="__containerId__-1713085884-layer-textinput868019233_input_svg_border" class=" svg_unselected_element" d="M 2.00,\
                        2.00 Q 12.43, 1.38, 22.86, 0.87 Q 33.29, 1.28, 43.71, 0.35 Q 54.14, 0.81, 64.57, 1.03 Q 75.00, 0.42, 85.43, 0.56 Q 95.86,\
                        0.48, 106.29, 0.69 Q 116.71, 0.25, 127.14, 0.53 Q 137.57, -0.22, 148.92, 1.08 Q 148.75, 14.75, 148.27, 28.27 Q 137.70, 28.47,\
                        127.17, 28.25 Q 116.72, 28.21, 106.29, 28.01 Q 95.87, 29.00, 85.44, 29.40 Q 75.01, 29.72, 64.57, 29.28 Q 54.14, 30.04, 43.72,\
                        30.27 Q 33.29, 30.13, 22.86, 28.62 Q 12.43, 27.97, 2.19, 27.81 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1713085884-layer-textinput868019233_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 1.36, 23.57, 1.26 Q 33.86, 1.59, 44.14, 1.33 Q 54.43, 1.73, 64.71, 1.97 Q 75.00, 1.78, 85.29, 1.65 Q 95.57, 2.51, 105.86,\
                        2.53 Q 116.14, 2.90, 126.43, 3.01 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput868019233_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput868019233_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 0.59, 23.57, 0.63 Q 33.86, 0.71, 44.14, 1.34 Q 54.43, 2.02, 64.71, 1.02 Q 75.00, 1.28, 85.29, 1.94 Q 95.57, 2.18, 105.86,\
                        2.97 Q 116.14, 3.07, 126.43, 2.21 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput868019233_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-1713085884-layer-textinput868019233input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1713085884-layer-textinput868019233_input_svg_border\',\'__containerId__-1713085884-layer-textinput868019233_line1\',\'__containerId__-1713085884-layer-textinput868019233_line2\',\'__containerId__-1713085884-layer-textinput868019233_line3\',\'__containerId__-1713085884-layer-textinput868019233_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1713085884-layer-textinput868019233_input_svg_border\',\'__containerId__-1713085884-layer-textinput868019233_line1\',\'__containerId__-1713085884-layer-textinput868019233_line2\',\'__containerId__-1713085884-layer-textinput868019233_line3\',\'__containerId__-1713085884-layer-textinput868019233_line4\'))" value="0 Option" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-textinput620690865" style="position: absolute; left: 335px; top: 555px; width: 150px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput620690865" data-review-reference-id="textinput620690865">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:150px;" width="150" height="30">\
                     <svg:g id="__containerId__-1713085884-layer-textinput620690865svg" width="150" height="30"><svg:path id="__containerId__-1713085884-layer-textinput620690865_input_svg_border" class=" svg_unselected_element" d="M 2.00,\
                        2.00 Q 12.43, 1.58, 22.86, 2.00 Q 33.29, 1.99, 43.71, 2.11 Q 54.14, 2.22, 64.57, 1.95 Q 75.00, 2.14, 85.43, 1.96 Q 95.86,\
                        2.36, 106.29, 2.20 Q 116.71, 1.77, 127.14, 2.28 Q 137.57, 2.52, 148.09, 1.91 Q 148.08, 14.97, 148.13, 28.13 Q 137.57, 27.99,\
                        127.07, 27.39 Q 116.67, 27.13, 106.27, 27.55 Q 95.84, 26.64, 85.43, 27.74 Q 75.00, 27.49, 64.57, 27.49 Q 54.14, 26.70, 43.71,\
                        27.42 Q 33.29, 28.66, 22.86, 28.97 Q 12.43, 28.69, 1.28, 28.72 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-1713085884-layer-textinput620690865_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 2.55, 23.57, 2.32 Q 33.86, 2.03, 44.14, 2.00 Q 54.43, 1.88, 64.71, 1.46 Q 75.00, 1.80, 85.29, 1.75 Q 95.57, 1.68, 105.86,\
                        1.65 Q 116.14, 1.37, 126.43, 1.63 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput620690865_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput620690865_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.29, 2.99, 23.57, 2.47 Q 33.86, 1.77, 44.14, 2.71 Q 54.43, 2.50, 64.71, 2.26 Q 75.00, 2.28, 85.29, 2.88 Q 95.57, 3.56, 105.86,\
                        1.69 Q 116.14, 1.96, 126.43, 1.98 Q 136.71, 3.00, 147.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-1713085884-layer-textinput620690865_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.00, 15.00, 3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-1713085884-layer-textinput620690865input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-1713085884-layer-textinput620690865_input_svg_border\',\'__containerId__-1713085884-layer-textinput620690865_line1\',\'__containerId__-1713085884-layer-textinput620690865_line2\',\'__containerId__-1713085884-layer-textinput620690865_line3\',\'__containerId__-1713085884-layer-textinput620690865_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-1713085884-layer-textinput620690865_input_svg_border\',\'__containerId__-1713085884-layer-textinput620690865_line1\',\'__containerId__-1713085884-layer-textinput620690865_line2\',\'__containerId__-1713085884-layer-textinput620690865_line3\',\'__containerId__-1713085884-layer-textinput620690865_line4\'))" value="-1 Option" style="width:143px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-iphoneButton513304050" style="position: absolute; left: 575px; top: 640px; width: 181px; height: 60px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton513304050" data-review-reference-id="iphoneButton513304050">\
            <div class="stencil-wrapper" style="width: 181px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 64px;width:185px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="185" height="64" viewBox="-2 -2 185 64">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 59.00 Q 3.01, 58.48, 1.48, 58.52 Q 0.60, 57.64, 0.23, 56.24 Q 0.29, 42.60,\
                        0.14, 29.06 Q 0.47, 15.52, 0.14, 1.81 Q 1.00, 0.82, 1.44, -0.50 Q 2.22, -1.54, 3.71, -1.90 Q 14.82, -1.81, 25.84, -1.43 Q\
                        36.80, -1.39, 47.74, -1.36 Q 58.69, -1.25, 69.63, -0.54 Q 80.56, -1.35, 91.50, -1.12 Q 102.44, -2.16, 113.37, -2.14 Q 124.31,\
                        -1.77, 135.25, -1.15 Q 146.19, -1.38, 157.12, -1.29 Q 168.06, -1.41, 179.17, -1.71 Q 180.17, -0.96, 181.43, -0.48 Q 181.99,\
                        0.63, 182.23, 1.93 Q 182.01, 15.50, 181.45, 29.04 Q 182.29, 42.49, 180.46, 55.66 Q 181.37, 56.95, 180.99, 57.99 Q 180.29,\
                        58.89, 179.00, 58.99 Q 168.15, 59.58, 157.23, 60.49 Q 146.24, 60.47, 135.28, 60.58 Q 124.31, 58.97, 113.38, 59.22 Q 102.44,\
                        58.72, 91.50, 58.75 Q 80.56, 59.19, 69.63, 59.31 Q 58.69, 59.26, 47.75, 59.04 Q 36.81, 59.89, 25.87, 58.23 Q 14.94, 59.00,\
                        4.00, 59.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="90.5" y="30" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Add Poll</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-266205665" style="position: absolute; left: 1065px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="266205665" data-review-reference-id="266205665">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e368-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e368"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-1089916482" style="position: absolute; left: 920px; top: 140px; width: 129px; height: 22px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1089916482" data-review-reference-id="1089916482">\
            <div class="stencil-wrapper" style="width: 129px; height: 22px">\
               <div title="" style="width:134px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><strong>Display Name</strong> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-1713085884-layer-1559692532" style="position: absolute; left: 175px; top: 15px; width: 95px; height: 80px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1559692532" data-review-reference-id="1559692532">\
            <div class="stencil-wrapper" style="width: 95px; height: 80px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 80px;width:95px;" width="95" height="80">\
                     <svg:g width="95" height="80"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.38, -0.49, 24.75, 0.24 Q 36.12, -0.11, 47.50, 0.77\
                        Q 58.88, 0.51, 70.25, 0.32 Q 81.62, 1.15, 93.20, 1.80 Q 93.41, 14.53, 93.15, 27.31 Q 93.63, 39.96, 94.19, 52.63 Q 94.50, 65.31,\
                        93.80, 78.80 Q 82.03, 79.23, 70.47, 79.59 Q 59.00, 79.95, 47.56, 79.89 Q 36.14, 79.19, 24.76, 78.67 Q 13.38, 78.80, 1.66,\
                        78.34 Q 1.27, 65.58, 1.02, 52.81 Q 1.30, 40.05, 0.74, 27.37 Q 2.00, 14.67, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 10.85, 9.90, 19.70, 17.80 Q 28.72, 25.49, 37.70, 33.24 Q 47.15,\
                        40.42, 56.34, 47.91 Q 65.43, 55.52, 74.53, 63.13 Q 83.90, 70.40, 93.00, 78.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 78.00 Q 9.55, 71.43, 17.33, 65.13 Q 25.01, 58.71, 32.68, 52.27 Q 40.34,\
                        45.83, 48.02, 39.41 Q 55.77, 33.08, 63.46, 26.68 Q 71.15, 20.27, 79.11, 14.19 Q 87.25, 8.33, 95.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="1713085884"] .border-wrapper, body[data-current-page-id="1713085884"] .simulation-container{\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="1713085884"] .border-wrapper, body.has-frame[data-current-page-id="1713085884"] .simulation-container{\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="1713085884"] .svg-border-1366-768{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="1713085884"] .border-wrapper .border-div{\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "1713085884",\
      			"name": "add poll",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
   <div id="border-wrapper">\
      <div xmlns="http://www.w3.org/1999/xhtml" xmlns:json="http://json.org/" class="svg-border svg-border-1366-768" style="display: none;">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="svg_border" style="position:absolute;left:-43px;top:-13px;width:1423px;height:792px;"><svg:path class=" svg_unselected_element" d="M 32.00, 3.00 Q 42.12, 3.66, 52.24, 2.99 Q 62.35, 2.73, 72.47, 2.60 Q 82.59,\
            2.93, 92.71, 2.73 Q 102.82, 2.77, 112.94, 2.71 Q 123.06, 1.92, 133.18, 2.50 Q 143.29, 2.06, 153.41, 2.17 Q 163.53, 2.13, 173.65,\
            2.31 Q 183.76, 2.95, 193.88, 2.60 Q 204.00, 2.10, 214.12, 1.37 Q 224.24, 1.29, 234.35, 2.44 Q 244.47, 2.53, 254.59, 1.92 Q\
            264.71, 1.85, 274.82, 2.10 Q 284.94, 2.16, 295.06, 1.83 Q 305.18, 1.54, 315.29, 1.99 Q 325.41, 2.66, 335.53, 3.23 Q 345.65,\
            3.18, 355.76, 2.95 Q 365.88, 2.73, 376.00, 2.57 Q 386.12, 3.00, 396.24, 2.21 Q 406.35, 1.58, 416.47, 1.48 Q 426.59, 2.52,\
            436.71, 1.90 Q 446.82, 1.47, 456.94, 2.33 Q 467.06, 2.08, 477.18, 2.44 Q 487.29, 1.97, 497.41, 1.81 Q 507.53, 1.74, 517.65,\
            1.57 Q 527.76, 1.44, 537.88, 1.24 Q 548.00, 1.79, 558.12, 1.57 Q 568.24, 1.68, 578.35, 1.28 Q 588.47, 1.20, 598.59, 0.87 Q\
            608.71, 1.41, 618.82, 1.54 Q 628.94, 1.67, 639.06, 2.83 Q 649.18, 1.91, 659.29, 2.31 Q 669.41, 1.71, 679.53, 2.11 Q 689.65,\
            2.43, 699.77, 2.20 Q 709.88, 2.04, 720.00, 2.11 Q 730.12, 2.31, 740.24, 3.15 Q 750.35, 3.04, 760.47, 2.74 Q 770.59, 2.87,\
            780.71, 1.95 Q 790.82, 2.97, 800.94, 1.80 Q 811.06, 2.02, 821.18, 3.11 Q 831.29, 3.04, 841.41, 2.53 Q 851.53, 1.91, 861.65,\
            1.81 Q 871.77, 2.23, 881.88, 2.98 Q 892.00, 2.98, 902.12, 2.69 Q 912.24, 1.97, 922.35, 3.21 Q 932.47, 3.14, 942.59, 3.23 Q\
            952.71, 3.49, 962.82, 2.35 Q 972.94, 2.22, 983.06, 2.18 Q 993.18, 2.10, 1003.30, 2.06 Q 1013.41, 2.49, 1023.53, 2.23 Q 1033.65,\
            1.94, 1043.77, 1.85 Q 1053.88, 1.66, 1064.00, 2.85 Q 1074.12, 2.57, 1084.24, 2.69 Q 1094.35, 2.68, 1104.47, 2.86 Q 1114.59,\
            2.83, 1124.71, 2.07 Q 1134.83, 2.42, 1144.94, 1.85 Q 1155.06, 1.83, 1165.18, 1.72 Q 1175.30, 2.01, 1185.41, 2.14 Q 1195.53,\
            1.79, 1205.65, 1.62 Q 1215.77, 1.38, 1225.88, 1.52 Q 1236.00, 2.77, 1246.12, 3.35 Q 1256.24, 2.49, 1266.35, 2.26 Q 1276.47,\
            1.98, 1286.59, 2.37 Q 1296.71, 1.56, 1306.83, 1.64 Q 1316.94, 1.48, 1327.06, 2.48 Q 1337.18, 3.32, 1347.30, 2.94 Q 1357.41,\
            2.80, 1367.53, 2.58 Q 1377.65, 1.99, 1387.77, 2.08 Q 1397.88, 2.22, 1408.40, 2.60 Q 1408.61, 12.97, 1407.92, 23.35 Q 1407.76,\
            33.53, 1406.63, 43.73 Q 1406.39, 53.88, 1407.26, 64.03 Q 1408.24, 74.20, 1407.99, 84.37 Q 1407.35, 94.54, 1407.61, 104.71\
            Q 1407.49, 114.88, 1408.32, 125.05 Q 1407.61, 135.22, 1407.05, 145.39 Q 1407.28, 155.57, 1408.88, 165.74 Q 1409.79, 175.91,\
            1409.48, 186.08 Q 1408.90, 196.25, 1408.71, 206.42 Q 1408.74, 216.59, 1409.28, 226.76 Q 1409.08, 236.93, 1408.87, 247.11 Q\
            1409.36, 257.28, 1409.43, 267.45 Q 1409.15, 277.62, 1409.16, 287.79 Q 1408.93, 297.96, 1408.72, 308.13 Q 1408.61, 318.30,\
            1408.15, 328.47 Q 1407.44, 338.64, 1407.90, 348.82 Q 1408.12, 358.99, 1408.22, 369.16 Q 1409.79, 379.33, 1410.02, 389.50 Q\
            1407.74, 399.67, 1407.82, 409.84 Q 1407.93, 420.01, 1407.62, 430.18 Q 1407.61, 440.36, 1407.86, 450.53 Q 1407.51, 460.70,\
            1407.61, 470.87 Q 1408.41, 481.04, 1408.88, 491.21 Q 1409.33, 501.38, 1409.10, 511.55 Q 1408.95, 521.72, 1409.08, 531.89 Q\
            1409.25, 542.07, 1409.45, 552.24 Q 1409.59, 562.41, 1409.56, 572.58 Q 1408.76, 582.75, 1408.61, 592.92 Q 1408.71, 603.09,\
            1408.90, 613.26 Q 1408.97, 623.43, 1409.12, 633.61 Q 1408.68, 643.78, 1408.59, 653.95 Q 1408.93, 664.12, 1409.09, 674.29 Q\
            1408.82, 684.46, 1407.47, 694.63 Q 1406.92, 704.80, 1407.29, 714.97 Q 1407.76, 725.15, 1406.96, 735.32 Q 1407.05, 745.49,\
            1407.46, 755.66 Q 1407.43, 765.83, 1407.66, 775.66 Q 1397.71, 775.47, 1387.69, 775.49 Q 1377.59, 775.14, 1367.53, 775.86 Q\
            1357.41, 775.96, 1347.29, 775.62 Q 1337.18, 776.01, 1327.06, 776.28 Q 1316.94, 776.30, 1306.83, 776.64 Q 1296.71, 776.83,\
            1286.59, 776.14 Q 1276.47, 776.75, 1266.35, 775.62 Q 1256.24, 775.95, 1246.12, 775.82 Q 1236.00, 775.97, 1225.88, 776.24 Q\
            1215.77, 776.28, 1205.65, 776.62 Q 1195.53, 776.23, 1185.41, 776.51 Q 1175.30, 776.98, 1165.18, 776.44 Q 1155.06, 776.72,\
            1144.94, 776.02 Q 1134.83, 775.88, 1124.71, 775.79 Q 1114.59, 775.61, 1104.47, 776.11 Q 1094.35, 777.24, 1084.24, 776.38 Q\
            1074.12, 777.07, 1064.00, 777.58 Q 1053.88, 776.55, 1043.77, 776.98 Q 1033.65, 777.18, 1023.53, 777.77 Q 1013.41, 777.66,\
            1003.30, 777.11 Q 993.18, 777.66, 983.06, 777.38 Q 972.94, 777.75, 962.82, 776.87 Q 952.71, 777.04, 942.59, 775.71 Q 932.47,\
            774.88, 922.35, 775.26 Q 912.24, 776.00, 902.12, 776.01 Q 892.00, 776.02, 881.88, 776.47 Q 871.77, 776.53, 861.65, 776.92\
            Q 851.53, 776.32, 841.41, 776.83 Q 831.29, 776.71, 821.18, 776.55 Q 811.06, 776.82, 800.94, 776.83 Q 790.82, 777.33, 780.71,\
            776.94 Q 770.59, 777.10, 760.47, 775.28 Q 750.35, 775.30, 740.24, 775.71 Q 730.12, 775.49, 720.00, 775.36 Q 709.88, 774.99,\
            699.77, 775.60 Q 689.65, 775.58, 679.53, 776.68 Q 669.41, 776.81, 659.29, 777.31 Q 649.18, 777.03, 639.06, 776.51 Q 628.94,\
            775.90, 618.82, 776.07 Q 608.71, 776.23, 598.59, 776.76 Q 588.47, 776.87, 578.35, 776.21 Q 568.24, 777.24, 558.12, 776.40\
            Q 548.00, 776.00, 537.88, 775.94 Q 527.76, 775.34, 517.65, 776.01 Q 507.53, 775.56, 497.41, 776.04 Q 487.29, 775.81, 477.18,\
            777.00 Q 467.06, 777.36, 456.94, 777.85 Q 446.82, 778.22, 436.71, 777.77 Q 426.59, 777.97, 416.47, 777.04 Q 406.35, 777.09,\
            396.24, 776.86 Q 386.12, 777.28, 376.00, 776.74 Q 365.88, 776.94, 355.76, 778.06 Q 345.65, 777.90, 335.53, 777.68 Q 325.41,\
            777.41, 315.29, 776.77 Q 305.18, 776.57, 295.06, 777.93 Q 284.94, 778.40, 274.82, 777.85 Q 264.71, 777.48, 254.59, 776.98\
            Q 244.47, 776.95, 234.35, 777.04 Q 224.24, 777.23, 214.12, 777.31 Q 204.00, 777.45, 193.88, 777.12 Q 183.76, 777.29, 173.65,\
            776.71 Q 163.53, 777.58, 153.41, 777.52 Q 143.29, 777.64, 133.18, 776.96 Q 123.06, 776.97, 112.94, 776.88 Q 102.82, 776.81,\
            92.71, 776.43 Q 82.59, 776.79, 72.47, 777.21 Q 62.35, 777.51, 52.24, 778.23 Q 42.12, 778.60, 30.87, 777.14 Q 31.14, 766.12,\
            31.28, 755.76 Q 30.93, 745.56, 30.38, 735.37 Q 29.47, 725.19, 30.19, 714.99 Q 30.35, 704.81, 30.76, 694.63 Q 31.20, 684.46,\
            31.15, 674.29 Q 30.91, 664.12, 31.44, 653.95 Q 32.06, 643.78, 31.81, 633.61 Q 31.96, 623.43, 31.22, 613.26 Q 30.45, 603.09,\
            30.25, 592.92 Q 30.60, 582.75, 31.28, 572.58 Q 31.50, 562.41, 30.81, 552.24 Q 30.83, 542.07, 30.70, 531.89 Q 30.56, 521.72,\
            30.49, 511.55 Q 30.27, 501.38, 30.17, 491.21 Q 29.90, 481.04, 30.17, 470.87 Q 30.26, 460.70, 30.00, 450.53 Q 29.91, 440.36,\
            29.78, 430.18 Q 29.84, 420.01, 30.28, 409.84 Q 31.45, 399.67, 31.42, 389.50 Q 31.39, 379.33, 31.42, 369.16 Q 31.40, 358.99,\
            31.20, 348.82 Q 31.24, 338.64, 30.95, 328.47 Q 31.27, 318.30, 31.24, 308.13 Q 31.29, 297.96, 30.93, 287.79 Q 30.98, 277.62,\
            31.39, 267.45 Q 31.68, 257.28, 31.47, 247.11 Q 31.10, 236.93, 31.31, 226.76 Q 31.42, 216.59, 31.45, 206.42 Q 31.63, 196.25,\
            31.10, 186.08 Q 31.31, 175.91, 31.64, 165.74 Q 31.44, 155.57, 31.69, 145.39 Q 31.32, 135.22, 32.07, 125.05 Q 32.92, 114.88,\
            32.43, 104.71 Q 33.55, 94.54, 32.57, 84.37 Q 32.62, 74.20, 31.95, 64.03 Q 31.58, 53.86, 30.94, 43.68 Q 31.69, 33.51, 31.81,\
            23.34 Q 32.00, 13.17, 32.00, 3.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 23.00, 7.00 Q 33.12, 8.35, 43.24, 8.38 Q 53.35, 7.61, 63.47, 7.21 Q 73.59,\
            6.36, 83.71, 6.34 Q 93.82, 6.43, 103.94, 6.09 Q 114.06, 5.50, 124.18, 4.92 Q 134.29, 4.75, 144.41, 4.90 Q 154.53, 5.71, 164.65,\
            5.48 Q 174.76, 5.04, 184.88, 5.37 Q 195.00, 5.34, 205.12, 5.13 Q 215.24, 5.06, 225.35, 4.89 Q 235.47, 4.70, 245.59, 4.68 Q\
            255.71, 4.94, 265.82, 5.29 Q 275.94, 5.81, 286.06, 6.29 Q 296.18, 6.02, 306.29, 6.18 Q 316.41, 5.63, 326.53, 6.18 Q 336.65,\
            6.04, 346.76, 6.20 Q 356.88, 6.19, 367.00, 6.00 Q 377.12, 6.41, 387.24, 5.65 Q 397.35, 5.89, 407.47, 6.29 Q 417.59, 5.70,\
            427.71, 5.65 Q 437.82, 5.42, 447.94, 5.38 Q 458.06, 5.34, 468.18, 5.47 Q 478.29, 5.58, 488.41, 5.72 Q 498.53, 5.89, 508.65,\
            6.30 Q 518.76, 5.36, 528.88, 6.32 Q 539.00, 6.42, 549.12, 6.35 Q 559.24, 6.72, 569.35, 5.58 Q 579.47, 6.02, 589.59, 6.39 Q\
            599.71, 7.33, 609.82, 7.06 Q 619.94, 7.38, 630.06, 7.28 Q 640.18, 6.87, 650.29, 6.45 Q 660.41, 6.80, 670.53, 6.54 Q 680.65,\
            6.33, 690.77, 6.96 Q 700.88, 5.99, 711.00, 6.66 Q 721.12, 6.16, 731.24, 6.39 Q 741.35, 6.58, 751.47, 5.31 Q 761.59, 5.12,\
            771.71, 6.72 Q 781.82, 6.79, 791.94, 6.52 Q 802.06, 5.65, 812.18, 5.57 Q 822.29, 5.68, 832.41, 5.36 Q 842.53, 6.18, 852.65,\
            5.74 Q 862.77, 5.49, 872.88, 5.89 Q 883.00, 5.30, 893.12, 5.22 Q 903.24, 5.15, 913.35, 5.33 Q 923.47, 5.97, 933.59, 5.90 Q\
            943.71, 6.52, 953.82, 6.16 Q 963.94, 6.88, 974.06, 6.36 Q 984.18, 7.23, 994.30, 7.39 Q 1004.41, 6.24, 1014.53, 5.85 Q 1024.65,\
            6.39, 1034.77, 6.64 Q 1044.88, 6.38, 1055.00, 6.16 Q 1065.12, 5.94, 1075.24, 5.64 Q 1085.35, 6.18, 1095.47, 6.73 Q 1105.59,\
            6.62, 1115.71, 5.24 Q 1125.83, 5.22, 1135.94, 6.07 Q 1146.06, 6.51, 1156.18, 6.18 Q 1166.30, 6.88, 1176.41, 7.72 Q 1186.53,\
            7.79, 1196.65, 7.42 Q 1206.77, 6.92, 1216.88, 7.93 Q 1227.00, 7.90, 1237.12, 7.25 Q 1247.24, 7.01, 1257.35, 7.22 Q 1267.47,\
            6.81, 1277.59, 6.56 Q 1287.71, 7.11, 1297.83, 7.24 Q 1307.94, 7.64, 1318.06, 6.62 Q 1328.18, 5.72, 1338.30, 6.16 Q 1348.41,\
            7.61, 1358.53, 7.27 Q 1368.65, 6.43, 1378.77, 6.56 Q 1388.88, 7.19, 1399.23, 6.77 Q 1399.83, 16.90, 1400.01, 27.20 Q 1400.15,\
            37.44, 1399.49, 47.67 Q 1398.93, 57.86, 1399.17, 68.03 Q 1399.95, 78.19, 1400.47, 88.37 Q 1401.04, 98.54, 1400.75, 108.71\
            Q 1399.94, 118.88, 1398.29, 129.05 Q 1398.37, 139.22, 1398.14, 149.39 Q 1398.21, 159.57, 1398.91, 169.74 Q 1399.37, 179.91,\
            1399.89, 190.08 Q 1399.75, 200.25, 1399.70, 210.42 Q 1400.35, 220.59, 1400.20, 230.76 Q 1399.86, 240.93, 1400.10, 251.11 Q\
            1399.50, 261.28, 1399.15, 271.45 Q 1399.44, 281.62, 1399.65, 291.79 Q 1400.04, 301.96, 1399.37, 312.13 Q 1399.24, 322.30,\
            1398.99, 332.47 Q 1399.79, 342.64, 1400.37, 352.82 Q 1400.10, 362.99, 1400.50, 373.16 Q 1400.51, 383.33, 1400.57, 393.50 Q\
            1400.62, 403.67, 1400.35, 413.84 Q 1399.23, 424.01, 1399.10, 434.18 Q 1399.28, 444.36, 1399.26, 454.53 Q 1398.89, 464.70,\
            1398.94, 474.87 Q 1399.20, 485.04, 1399.80, 495.21 Q 1399.62, 505.38, 1398.60, 515.55 Q 1399.18, 525.72, 1399.82, 535.89 Q\
            1399.35, 546.07, 1398.70, 556.24 Q 1398.30, 566.41, 1398.20, 576.58 Q 1398.51, 586.75, 1399.66, 596.92 Q 1400.51, 607.09,\
            1400.31, 617.26 Q 1399.91, 627.43, 1399.32, 637.61 Q 1398.90, 647.78, 1399.18, 657.95 Q 1398.89, 668.12, 1399.09, 678.29 Q\
            1399.50, 688.46, 1399.74, 698.63 Q 1400.08, 708.80, 1400.07, 718.97 Q 1400.03, 729.15, 1400.47, 739.32 Q 1400.35, 749.49,\
            1399.51, 759.66 Q 1398.94, 769.83, 1398.88, 779.88 Q 1388.82, 779.80, 1378.66, 779.26 Q 1368.72, 781.12, 1358.58, 781.52 Q\
            1348.43, 781.32, 1338.31, 781.76 Q 1328.18, 780.93, 1318.06, 780.44 Q 1307.94, 781.04, 1297.83, 780.25 Q 1287.71, 779.63,\
            1277.59, 780.74 Q 1267.47, 781.26, 1257.35, 781.23 Q 1247.24, 780.76, 1237.12, 781.01 Q 1227.00, 780.05, 1216.88, 779.49 Q\
            1206.77, 779.40, 1196.65, 778.35 Q 1186.53, 779.31, 1176.41, 779.66 Q 1166.30, 780.28, 1156.18, 779.67 Q 1146.06, 779.97,\
            1135.94, 780.63 Q 1125.83, 781.27, 1115.71, 781.30 Q 1105.59, 781.24, 1095.47, 781.02 Q 1085.35, 780.39, 1075.24, 779.84 Q\
            1065.12, 779.07, 1055.00, 780.29 Q 1044.88, 780.28, 1034.77, 780.26 Q 1024.65, 781.07, 1014.53, 780.14 Q 1004.41, 779.90,\
            994.30, 779.47 Q 984.18, 779.03, 974.06, 779.04 Q 963.94, 780.35, 953.82, 780.64 Q 943.71, 781.67, 933.59, 782.10 Q 923.47,\
            781.89, 913.35, 781.16 Q 903.24, 779.62, 893.12, 779.14 Q 883.00, 778.92, 872.88, 779.88 Q 862.77, 779.80, 852.65, 781.15\
            Q 842.53, 781.29, 832.41, 780.40 Q 822.29, 780.02, 812.18, 779.62 Q 802.06, 779.97, 791.94, 780.23 Q 781.82, 780.79, 771.71,\
            780.85 Q 761.59, 781.20, 751.47, 781.45 Q 741.35, 781.52, 731.24, 782.14 Q 721.12, 781.58, 711.00, 780.89 Q 700.88, 780.30,\
            690.77, 781.00 Q 680.65, 781.80, 670.53, 781.80 Q 660.41, 781.48, 650.29, 781.77 Q 640.18, 781.62, 630.06, 781.65 Q 619.94,\
            781.58, 609.82, 781.39 Q 599.71, 780.87, 589.59, 780.77 Q 579.47, 780.44, 569.35, 780.24 Q 559.24, 779.12, 549.12, 779.30\
            Q 539.00, 779.82, 528.88, 780.04 Q 518.76, 780.77, 508.65, 780.17 Q 498.53, 780.69, 488.41, 780.46 Q 478.29, 781.43, 468.18,\
            781.25 Q 458.06, 781.08, 447.94, 781.03 Q 437.82, 781.24, 427.71, 781.34 Q 417.59, 780.66, 407.47, 781.20 Q 397.35, 780.40,\
            387.24, 780.68 Q 377.12, 781.59, 367.00, 781.70 Q 356.88, 781.56, 346.76, 781.88 Q 336.65, 780.82, 326.53, 781.13 Q 316.41,\
            782.05, 306.29, 781.27 Q 296.18, 780.60, 286.06, 780.30 Q 275.94, 780.22, 265.82, 779.83 Q 255.71, 779.79, 245.59, 780.73\
            Q 235.47, 779.91, 225.35, 780.77 Q 215.24, 780.42, 205.12, 780.82 Q 195.00, 780.60, 184.88, 780.01 Q 174.76, 778.57, 164.65,\
            779.90 Q 154.53, 780.96, 144.41, 780.09 Q 134.29, 780.44, 124.18, 780.74 Q 114.06, 780.88, 103.94, 781.12 Q 93.82, 781.40,\
            83.71, 781.38 Q 73.59, 781.73, 63.47, 782.02 Q 53.35, 782.05, 43.24, 781.84 Q 33.12, 781.76, 22.25, 780.75 Q 21.80, 770.23,\
            21.57, 759.86 Q 20.74, 749.64, 20.64, 739.39 Q 20.91, 729.18, 20.96, 718.99 Q 21.31, 708.81, 21.24, 698.64 Q 21.44, 688.46,\
            21.80, 678.29 Q 21.86, 668.12, 21.82, 657.95 Q 22.04, 647.78, 22.00, 637.61 Q 21.95, 627.43, 21.60, 617.26 Q 21.58, 607.09,\
            21.39, 596.92 Q 21.35, 586.75, 21.66, 576.58 Q 22.62, 566.41, 22.09, 556.24 Q 22.12, 546.07, 22.55, 535.89 Q 21.93, 525.72,\
            21.60, 515.55 Q 21.57, 505.38, 21.52, 495.21 Q 21.62, 485.04, 22.21, 474.87 Q 21.70, 464.70, 21.92, 454.53 Q 22.49, 444.36,\
            22.51, 434.18 Q 22.48, 424.01, 23.02, 413.84 Q 23.24, 403.67, 24.11, 393.50 Q 23.45, 383.33, 23.17, 373.16 Q 22.69, 362.99,\
            22.48, 352.82 Q 22.44, 342.64, 22.31, 332.47 Q 22.86, 322.30, 22.48, 312.13 Q 22.72, 301.96, 23.13, 291.79 Q 22.44, 281.62,\
            22.71, 271.45 Q 23.11, 261.28, 21.89, 251.11 Q 21.94, 240.93, 22.29, 230.76 Q 22.22, 220.59, 22.58, 210.42 Q 21.65, 200.25,\
            21.65, 190.08 Q 21.69, 179.91, 21.84, 169.74 Q 21.95, 159.57, 21.39, 149.39 Q 21.86, 139.22, 21.92, 129.05 Q 21.28, 118.88,\
            21.62, 108.71 Q 21.37, 98.54, 21.95, 88.37 Q 21.74, 78.20, 21.54, 68.03 Q 22.08, 57.86, 21.91, 47.68 Q 22.61, 37.51, 22.25,\
            27.34 Q 23.00, 17.17, 23.00, 7.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 40.00, 11.00 Q 50.12, 10.58, 60.24, 10.54 Q 70.35, 10.42, 80.47, 10.86 Q 90.59,\
            10.71, 100.71, 9.87 Q 110.82, 10.69, 120.94, 10.75 Q 131.06, 11.38, 141.18, 11.17 Q 151.29, 10.10, 161.41, 9.89 Q 171.53,\
            9.93, 181.65, 10.37 Q 191.76, 10.04, 201.88, 10.60 Q 212.00, 11.75, 222.12, 11.44 Q 232.24, 12.32, 242.35, 11.64 Q 252.47,\
            10.29, 262.59, 9.75 Q 272.71, 10.06, 282.82, 9.48 Q 292.94, 9.46, 303.06, 10.46 Q 313.18, 11.05, 323.29, 10.91 Q 333.41, 9.98,\
            343.53, 9.17 Q 353.65, 8.98, 363.76, 9.48 Q 373.88, 9.61, 384.00, 10.47 Q 394.12, 10.63, 404.24, 9.51 Q 414.35, 10.63, 424.47,\
            11.05 Q 434.59, 11.09, 444.71, 11.30 Q 454.82, 11.11, 464.94, 10.58 Q 475.06, 10.27, 485.18, 10.43 Q 495.29, 10.65, 505.41,\
            10.76 Q 515.53, 10.44, 525.65, 9.87 Q 535.76, 9.72, 545.88, 9.46 Q 556.00, 9.31, 566.12, 9.19 Q 576.24, 9.51, 586.35, 9.25\
            Q 596.47, 10.20, 606.59, 9.68 Q 616.71, 9.24, 626.82, 9.03 Q 636.94, 8.74, 647.06, 8.91 Q 657.18, 9.18, 667.29, 9.15 Q 677.41,\
            9.03, 687.53, 9.81 Q 697.65, 9.16, 707.77, 9.12 Q 717.88, 9.47, 728.00, 9.83 Q 738.12, 10.95, 748.24, 10.68 Q 758.35, 9.89,\
            768.47, 9.60 Q 778.59, 10.22, 788.71, 10.93 Q 798.82, 10.69, 808.94, 10.76 Q 819.06, 10.59, 829.18, 10.67 Q 839.29, 11.19,\
            849.41, 10.84 Q 859.53, 10.59, 869.65, 10.90 Q 879.77, 10.63, 889.88, 10.12 Q 900.00, 9.80, 910.12, 10.05 Q 920.24, 10.69,\
            930.35, 10.26 Q 940.47, 10.17, 950.59, 11.08 Q 960.71, 11.36, 970.82, 10.77 Q 980.94, 9.96, 991.06, 9.92 Q 1001.18, 8.84,\
            1011.30, 8.73 Q 1021.41, 9.07, 1031.53, 9.76 Q 1041.65, 10.64, 1051.77, 10.56 Q 1061.88, 10.61, 1072.00, 10.78 Q 1082.12,\
            10.09, 1092.24, 10.36 Q 1102.35, 9.92, 1112.47, 9.98 Q 1122.59, 9.36, 1132.71, 10.20 Q 1142.83, 11.12, 1152.94, 11.38 Q 1163.06,\
            11.50, 1173.18, 10.47 Q 1183.30, 9.91, 1193.41, 9.75 Q 1203.53, 9.55, 1213.65, 9.90 Q 1223.77, 9.68, 1233.88, 9.30 Q 1244.00,\
            9.31, 1254.12, 9.21 Q 1264.24, 9.08, 1274.35, 8.96 Q 1284.47, 8.67, 1294.59, 8.80 Q 1304.71, 8.91, 1314.83, 9.03 Q 1324.94,\
            9.42, 1335.06, 10.25 Q 1345.18, 10.18, 1355.30, 9.50 Q 1365.41, 9.62, 1375.53, 9.79 Q 1385.65, 10.07, 1395.77, 10.24 Q 1405.88,\
            10.21, 1416.35, 10.65 Q 1416.48, 21.01, 1416.75, 31.23 Q 1416.57, 41.48, 1417.09, 51.65 Q 1417.51, 61.83, 1417.25, 72.02 Q\
            1417.17, 82.19, 1417.37, 92.37 Q 1415.88, 102.54, 1416.90, 112.71 Q 1416.18, 122.88, 1416.40, 133.05 Q 1416.56, 143.22, 1416.88,\
            153.39 Q 1416.35, 163.57, 1416.63, 173.74 Q 1417.30, 183.91, 1416.87, 194.08 Q 1417.54, 204.25, 1417.10, 214.42 Q 1416.96,\
            224.59, 1416.21, 234.76 Q 1416.41, 244.93, 1417.29, 255.11 Q 1417.79, 265.28, 1417.71, 275.45 Q 1416.66, 285.62, 1416.80,\
            295.79 Q 1416.58, 305.96, 1416.77, 316.13 Q 1417.06, 326.30, 1416.81, 336.47 Q 1416.67, 346.64, 1416.87, 356.82 Q 1417.18,\
            366.99, 1416.66, 377.16 Q 1417.13, 387.33, 1416.50, 397.50 Q 1416.79, 407.67, 1416.99, 417.84 Q 1417.13, 428.01, 1416.85,\
            438.18 Q 1417.19, 448.36, 1417.01, 458.53 Q 1416.68, 468.70, 1417.29, 478.87 Q 1415.69, 489.04, 1416.52, 499.21 Q 1416.56,\
            509.38, 1416.43, 519.55 Q 1416.70, 529.72, 1416.18, 539.89 Q 1417.98, 550.07, 1418.07, 560.24 Q 1418.12, 570.41, 1418.25,\
            580.58 Q 1417.97, 590.75, 1417.15, 600.92 Q 1417.13, 611.09, 1416.96, 621.26 Q 1416.93, 631.43, 1417.02, 641.61 Q 1417.49,\
            651.78, 1416.89, 661.95 Q 1416.42, 672.12, 1416.54, 682.29 Q 1415.67, 692.46, 1415.59, 702.63 Q 1415.98, 712.80, 1416.24,\
            722.97 Q 1416.45, 733.15, 1416.49, 743.32 Q 1417.41, 753.49, 1417.89, 763.66 Q 1417.84, 773.83, 1416.57, 784.57 Q 1406.20,\
            784.93, 1395.96, 785.32 Q 1385.72, 785.04, 1375.54, 784.33 Q 1365.41, 783.63, 1355.30, 783.82 Q 1345.18, 783.45, 1335.06,\
            784.26 Q 1324.94, 784.05, 1314.83, 783.70 Q 1304.71, 784.08, 1294.59, 784.37 Q 1284.47, 784.73, 1274.35, 784.70 Q 1264.24,\
            784.68, 1254.12, 784.63 Q 1244.00, 785.03, 1233.88, 785.02 Q 1223.77, 784.58, 1213.65, 784.61 Q 1203.53, 784.33, 1193.41,\
            784.56 Q 1183.30, 784.84, 1173.18, 784.92 Q 1163.06, 784.95, 1152.94, 784.85 Q 1142.83, 784.48, 1132.71, 784.76 Q 1122.59,\
            785.12, 1112.47, 784.99 Q 1102.35, 785.58, 1092.24, 785.45 Q 1082.12, 785.62, 1072.00, 785.86 Q 1061.88, 785.85, 1051.77,\
            785.54 Q 1041.65, 784.81, 1031.53, 785.09 Q 1021.41, 785.06, 1011.30, 785.26 Q 1001.18, 785.41, 991.06, 785.21 Q 980.94, 785.08,\
            970.82, 784.44 Q 960.71, 783.68, 950.59, 783.64 Q 940.47, 784.29, 930.35, 784.85 Q 920.24, 783.93, 910.12, 784.17 Q 900.00,\
            784.33, 889.88, 784.28 Q 879.77, 784.21, 869.65, 783.95 Q 859.53, 784.26, 849.41, 784.12 Q 839.29, 784.20, 829.18, 784.30\
            Q 819.06, 784.35, 808.94, 784.38 Q 798.82, 784.79, 788.71, 784.83 Q 778.59, 785.19, 768.47, 785.04 Q 758.35, 785.20, 748.24,\
            784.22 Q 738.12, 785.07, 728.00, 785.10 Q 717.88, 785.03, 707.77, 785.82 Q 697.65, 785.88, 687.53, 785.02 Q 677.41, 784.82,\
            667.29, 784.32 Q 657.18, 784.93, 647.06, 784.76 Q 636.94, 783.52, 626.82, 783.26 Q 616.71, 784.75, 606.59, 784.90 Q 596.47,\
            784.33, 586.35, 783.77 Q 576.24, 783.55, 566.12, 783.72 Q 556.00, 783.97, 545.88, 783.95 Q 535.76, 784.02, 525.65, 783.77\
            Q 515.53, 784.38, 505.41, 783.55 Q 495.29, 783.22, 485.18, 783.77 Q 475.06, 784.59, 464.94, 784.26 Q 454.82, 783.20, 444.71,\
            783.09 Q 434.59, 783.66, 424.47, 784.89 Q 414.35, 784.58, 404.24, 784.39 Q 394.12, 784.55, 384.00, 784.95 Q 373.88, 784.48,\
            363.76, 784.68 Q 353.65, 784.40, 343.53, 784.85 Q 333.41, 785.51, 323.29, 784.90 Q 313.18, 784.42, 303.06, 784.45 Q 292.94,\
            785.12, 282.82, 784.76 Q 272.71, 784.09, 262.59, 783.94 Q 252.47, 784.47, 242.35, 784.88 Q 232.24, 784.73, 222.12, 784.35\
            Q 212.00, 783.92, 201.88, 784.11 Q 191.76, 784.33, 181.65, 784.64 Q 171.53, 784.45, 161.41, 784.18 Q 151.29, 783.43, 141.18,\
            783.75 Q 131.06, 783.47, 120.94, 783.38 Q 110.82, 784.08, 100.71, 784.03 Q 90.59, 784.07, 80.47, 784.26 Q 70.35, 784.75, 60.24,\
            785.64 Q 50.12, 784.12, 39.94, 784.06 Q 39.98, 773.84, 39.79, 763.69 Q 39.91, 753.49, 39.38, 743.34 Q 39.17, 733.16, 39.01,\
            722.98 Q 39.28, 712.81, 39.56, 702.63 Q 39.46, 692.46, 39.70, 682.29 Q 39.33, 672.12, 39.79, 661.95 Q 39.45, 651.78, 39.64,\
            641.61 Q 39.40, 631.43, 39.15, 621.26 Q 40.40, 611.09, 41.54, 600.92 Q 41.21, 590.75, 40.56, 580.58 Q 40.45, 570.41, 40.56,\
            560.24 Q 40.99, 550.07, 40.35, 539.89 Q 39.38, 529.72, 40.11, 519.55 Q 40.36, 509.38, 41.19, 499.21 Q 39.17, 489.04, 38.16,\
            478.87 Q 37.87, 468.70, 37.98, 458.53 Q 38.37, 448.36, 38.33, 438.18 Q 39.11, 428.01, 37.98, 417.84 Q 37.70, 407.67, 38.00,\
            397.50 Q 38.79, 387.33, 38.58, 377.16 Q 38.65, 366.99, 38.37, 356.82 Q 38.20, 346.64, 38.62, 336.47 Q 37.91, 326.30, 38.56,\
            316.13 Q 38.76, 305.96, 38.36, 295.79 Q 38.16, 285.62, 38.20, 275.45 Q 38.64, 265.28, 39.06, 255.11 Q 39.47, 244.93, 39.87,\
            234.76 Q 40.03, 224.59, 40.03, 214.42 Q 41.12, 204.25, 40.85, 194.08 Q 40.89, 183.91, 40.84, 173.74 Q 39.95, 163.57, 40.33,\
            153.39 Q 39.64, 143.22, 40.24, 133.05 Q 39.79, 122.88, 39.95, 112.71 Q 40.18, 102.54, 39.74, 92.37 Q 38.94, 82.20, 38.65,\
            72.03 Q 38.31, 61.86, 38.15, 51.68 Q 38.02, 41.51, 38.78, 31.34 Q 40.00, 21.17, 40.00, 11.00" style=" fill:white;"/>\
         </svg:svg>\
      </div>\
   </div>\
</div>');