rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__502299397-layer" class="layer" name="__containerId__pageLayer" data-layer-id="502299397" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-502299397-layer-1717807677" style="position: absolute; left: 0px; top: 0px; width: 1375px; height: 820px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1717807677" data-review-reference-id="1717807677">\
            <div class="stencil-wrapper" style="width: 1375px; height: 820px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 820px;width:1375px;" width="1375" height="820">\
                     <svg:g width="1375" height="820"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.08, 1.80, 22.16, 1.61 Q 32.24, 1.33, 42.32, 1.19 Q\
                        52.40, 0.85, 62.49, 0.74 Q 72.57, 0.58, 82.65, 1.00 Q 92.73, 0.97, 102.81, 0.78 Q 112.89, 0.67, 122.97, 0.85 Q 133.05, 1.27,\
                        143.13, 0.50 Q 153.21, 0.37, 163.29, 0.59 Q 173.38, 0.81, 183.46, 0.76 Q 193.54, 1.23, 203.62, 1.11 Q 213.70, 1.19, 223.78,\
                        0.72 Q 233.86, 0.57, 243.94, 0.92 Q 254.02, 1.16, 264.10, 1.37 Q 274.18, 1.07, 284.26, 1.08 Q 294.35, 0.66, 304.43, 0.56 Q\
                        314.51, 1.35, 324.59, 1.17 Q 334.67, 1.95, 344.75, 1.28 Q 354.83, 1.64, 364.91, 1.16 Q 374.99, 1.39, 385.07, 1.67 Q 395.15,\
                        1.04, 405.24, 1.32 Q 415.32, 1.15, 425.40, 2.25 Q 435.48, 1.90, 445.56, 1.27 Q 455.64, 1.31, 465.72, 1.20 Q 475.80, 1.42,\
                        485.88, 1.25 Q 495.96, 0.94, 506.04, 1.78 Q 516.12, 1.75, 526.21, 1.80 Q 536.29, 2.20, 546.37, 2.02 Q 556.45, 1.86, 566.53,\
                        1.90 Q 576.61, 1.49, 586.69, 1.23 Q 596.77, 0.61, 606.85, 0.77 Q 616.93, 1.36, 627.01, 1.04 Q 637.10, 1.06, 647.18, 1.13 Q\
                        657.26, 1.29, 667.34, 2.36 Q 677.42, 0.59, 687.50, 0.47 Q 697.58, 0.41, 707.66, 1.03 Q 717.74, 2.02, 727.82, 1.21 Q 737.90,\
                        0.32, 747.98, 1.09 Q 758.07, 1.76, 768.15, 1.34 Q 778.23, 1.03, 788.31, 0.67 Q 798.39, 1.18, 808.47, 1.20 Q 818.55, 1.00,\
                        828.63, 0.95 Q 838.71, 1.46, 848.79, 2.37 Q 858.87, 2.65, 868.96, 1.71 Q 879.04, 0.98, 889.12, 0.86 Q 899.20, 1.24, 909.28,\
                        1.38 Q 919.36, 1.44, 929.44, 1.26 Q 939.52, 0.96, 949.60, 1.11 Q 959.68, 1.75, 969.76, 0.89 Q 979.84, 1.21, 989.93, 0.37 Q\
                        1000.01, 1.28, 1010.09, 1.86 Q 1020.17, 1.11, 1030.25, 0.92 Q 1040.33, 0.56, 1050.41, 1.04 Q 1060.49, 0.72, 1070.57, 1.67\
                        Q 1080.65, 1.94, 1090.73, 1.89 Q 1100.82, 2.40, 1110.90, 2.68 Q 1120.98, 2.79, 1131.06, 2.00 Q 1141.14, 1.99, 1151.22, 1.08\
                        Q 1161.30, 1.65, 1171.38, 1.66 Q 1181.46, 1.82, 1191.54, 1.45 Q 1201.63, 1.52, 1211.71, 1.06 Q 1221.79, 0.94, 1231.87, 0.78\
                        Q 1241.95, 0.96, 1252.03, 1.02 Q 1262.11, 1.57, 1272.19, 2.28 Q 1282.27, 2.98, 1292.35, 2.70 Q 1302.43, 1.73, 1312.52, 1.51\
                        Q 1322.60, 2.74, 1332.68, 2.08 Q 1342.76, 1.07, 1352.84, 0.95 Q 1362.92, 0.36, 1373.38, 1.62 Q 1373.64, 11.99, 1374.04, 22.25\
                        Q 1373.90, 32.54, 1373.96, 42.77 Q 1373.73, 52.99, 1372.81, 63.20 Q 1373.11, 73.40, 1373.43, 83.60 Q 1372.63, 93.80, 1373.59,\
                        104.00 Q 1373.77, 114.20, 1373.66, 124.40 Q 1373.27, 134.60, 1374.09, 144.80 Q 1374.95, 155.00, 1374.72, 165.20 Q 1373.87,\
                        175.40, 1373.17, 185.60 Q 1374.67, 195.80, 1374.40, 206.00 Q 1374.29, 216.20, 1374.52, 226.40 Q 1374.87, 236.60, 1374.50,\
                        246.80 Q 1374.70, 257.00, 1374.24, 267.20 Q 1373.81, 277.40, 1374.18, 287.60 Q 1374.56, 297.80, 1374.39, 308.00 Q 1374.26,\
                        318.20, 1373.81, 328.40 Q 1373.39, 338.60, 1373.23, 348.80 Q 1373.46, 359.00, 1373.96, 369.20 Q 1374.35, 379.40, 1374.47,\
                        389.60 Q 1374.41, 399.80, 1373.98, 410.00 Q 1373.46, 420.20, 1373.34, 430.40 Q 1373.42, 440.60, 1373.36, 450.80 Q 1373.72,\
                        461.00, 1373.73, 471.20 Q 1373.11, 481.40, 1373.36, 491.60 Q 1373.50, 501.80, 1373.16, 512.00 Q 1373.41, 522.20, 1373.51,\
                        532.40 Q 1373.32, 542.60, 1372.73, 552.80 Q 1372.57, 563.00, 1373.64, 573.20 Q 1374.19, 583.40, 1372.57, 593.60 Q 1374.33,\
                        603.80, 1374.28, 614.00 Q 1374.28, 624.20, 1372.95, 634.40 Q 1372.03, 644.60, 1372.18, 654.80 Q 1373.86, 665.00, 1373.85,\
                        675.20 Q 1373.21, 685.40, 1373.96, 695.60 Q 1374.00, 705.80, 1374.00, 716.00 Q 1373.41, 726.20, 1373.20, 736.40 Q 1373.37,\
                        746.60, 1373.59, 756.80 Q 1373.48, 767.00, 1372.72, 777.20 Q 1373.33, 787.40, 1373.23, 797.60 Q 1373.39, 807.80, 1373.15,\
                        818.15 Q 1363.04, 818.36, 1352.84, 818.03 Q 1342.79, 818.53, 1332.68, 818.18 Q 1322.59, 817.91, 1312.52, 818.39 Q 1302.44,\
                        819.09, 1292.36, 819.46 Q 1282.27, 818.92, 1272.19, 818.64 Q 1262.11, 819.33, 1252.03, 819.53 Q 1241.95, 818.87, 1231.87,\
                        818.98 Q 1221.79, 819.34, 1211.71, 818.79 Q 1201.63, 819.18, 1191.54, 818.55 Q 1181.46, 818.81, 1171.38, 819.05 Q 1161.30,\
                        818.86, 1151.22, 818.55 Q 1141.14, 818.64, 1131.06, 819.30 Q 1120.98, 819.05, 1110.90, 819.61 Q 1100.82, 818.49, 1090.73,\
                        819.15 Q 1080.65, 818.69, 1070.57, 819.11 Q 1060.49, 819.19, 1050.41, 819.18 Q 1040.33, 819.78, 1030.25, 818.55 Q 1020.17,\
                        818.42, 1010.09, 817.47 Q 1000.01, 816.77, 989.93, 816.82 Q 979.84, 817.06, 969.76, 817.55 Q 959.68, 817.75, 949.60, 818.69\
                        Q 939.52, 818.53, 929.44, 819.46 Q 919.36, 817.74, 909.28, 817.20 Q 899.20, 816.54, 889.12, 817.34 Q 879.04, 817.96, 868.96,\
                        818.44 Q 858.87, 818.76, 848.79, 818.84 Q 838.71, 819.77, 828.63, 819.81 Q 818.55, 819.31, 808.47, 819.02 Q 798.39, 818.92,\
                        788.31, 818.60 Q 778.23, 819.35, 768.15, 819.27 Q 758.07, 818.56, 747.98, 819.51 Q 737.90, 819.60, 727.82, 819.51 Q 717.74,\
                        819.21, 707.66, 819.01 Q 697.58, 819.01, 687.50, 818.58 Q 677.42, 818.65, 667.34, 818.88 Q 657.26, 818.71, 647.18, 818.89\
                        Q 637.10, 817.82, 627.01, 817.03 Q 616.93, 817.60, 606.85, 818.15 Q 596.77, 818.76, 586.69, 819.21 Q 576.61, 818.66, 566.53,\
                        819.31 Q 556.45, 818.54, 546.37, 818.71 Q 536.29, 819.48, 526.21, 819.95 Q 516.12, 820.04, 506.04, 820.24 Q 495.96, 820.19,\
                        485.88, 819.87 Q 475.80, 820.03, 465.72, 820.07 Q 455.64, 819.34, 445.56, 818.73 Q 435.48, 819.95, 425.40, 820.02 Q 415.32,\
                        819.79, 405.24, 819.13 Q 395.15, 818.92, 385.07, 818.92 Q 374.99, 819.06, 364.91, 819.07 Q 354.83, 819.23, 344.75, 819.44\
                        Q 334.67, 818.98, 324.59, 818.57 Q 314.51, 818.41, 304.43, 818.89 Q 294.35, 818.77, 284.26, 818.57 Q 274.18, 818.56, 264.10,\
                        818.88 Q 254.02, 819.09, 243.94, 819.46 Q 233.86, 818.94, 223.78, 819.21 Q 213.70, 819.30, 203.62, 819.45 Q 193.54, 819.86,\
                        183.46, 819.70 Q 173.38, 819.94, 163.29, 819.36 Q 153.21, 819.74, 143.13, 819.96 Q 133.05, 820.07, 122.97, 819.70 Q 112.89,\
                        819.05, 102.81, 819.24 Q 92.73, 819.40, 82.65, 819.92 Q 72.57, 819.91, 62.49, 820.14 Q 52.40, 819.83, 42.32, 819.33 Q 32.24,\
                        818.89, 22.16, 819.58 Q 12.08, 820.01, 1.33, 818.67 Q 1.26, 808.05, 1.43, 797.68 Q 2.00, 787.40, 1.63, 777.21 Q 1.34, 767.01,\
                        1.18, 756.81 Q 1.16, 746.60, 0.66, 736.40 Q 0.98, 726.20, 0.66, 716.00 Q 0.77, 705.80, 0.44, 695.60 Q 0.95, 685.40, 0.92,\
                        675.20 Q 0.67, 665.00, 0.66, 654.80 Q 0.19, 644.60, 1.93, 634.40 Q 1.44, 624.20, 1.87, 614.00 Q 2.14, 603.80, 1.51, 593.60\
                        Q 1.44, 583.40, 0.75, 573.20 Q 0.55, 563.00, 0.91, 552.80 Q 1.01, 542.60, 1.55, 532.40 Q 1.20, 522.20, 2.25, 512.00 Q 2.50,\
                        501.80, 1.99, 491.60 Q 1.09, 481.40, 0.85, 471.20 Q 1.72, 461.00, 2.10, 450.80 Q 1.20, 440.60, 0.33, 430.40 Q 1.13, 420.20,\
                        1.75, 410.00 Q 1.09, 399.80, 1.12, 389.60 Q 1.73, 379.40, 2.58, 369.20 Q 2.02, 359.00, 2.71, 348.80 Q 2.51, 338.60, 2.93,\
                        328.40 Q 2.24, 318.20, 1.37, 308.00 Q 1.24, 297.80, 1.57, 287.60 Q 1.67, 277.40, 1.68, 267.20 Q 1.61, 257.00, 0.58, 246.80\
                        Q 0.76, 236.60, 1.38, 226.40 Q 1.18, 216.20, 1.19, 206.00 Q 2.00, 195.80, 1.18, 185.60 Q 0.50, 175.40, 1.47, 165.20 Q 1.58,\
                        155.00, 1.73, 144.80 Q 1.85, 134.60, 1.46, 124.40 Q 1.77, 114.20, 0.83, 104.00 Q 1.52, 93.80, 1.62, 83.60 Q 1.11, 73.40, 0.78,\
                        63.20 Q 1.34, 53.00, 1.54, 42.80 Q 1.93, 32.60, 1.31, 22.40 Q 2.00, 12.20, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 10.94, 6.72, 19.73, 11.70 Q 28.45, 16.79, 37.23, 21.78 Q 45.90,\
                        26.96, 54.73, 31.87 Q 63.31, 37.19, 72.08, 42.21 Q 80.78, 47.32, 89.46, 52.49 Q 98.25, 57.47, 106.77, 62.89 Q 115.38, 68.17,\
                        124.13, 73.21 Q 132.70, 78.55, 141.36, 83.74 Q 150.25, 88.56, 158.69, 94.11 Q 167.41, 99.21, 175.98, 104.56 Q 184.81, 109.47,\
                        193.58, 114.48 Q 202.18, 119.77, 210.71, 125.18 Q 219.48, 130.19, 227.95, 135.70 Q 236.67, 140.80, 245.28, 146.08 Q 253.86,\
                        151.40, 262.48, 156.67 Q 270.78, 162.46, 280.00, 166.71 Q 288.83, 171.62, 297.66, 176.53 Q 306.32, 181.73, 314.41, 187.88\
                        Q 323.38, 192.55, 332.17, 197.53 Q 341.03, 202.37, 349.02, 208.69 Q 357.98, 213.39, 366.79, 218.33 Q 375.56, 223.34, 384.30,\
                        228.39 Q 392.64, 234.12, 401.17, 239.54 Q 409.62, 245.09, 418.30, 250.25 Q 427.16, 255.10, 436.05, 259.92 Q 444.95, 264.69,\
                        453.34, 270.35 Q 462.06, 275.43, 471.11, 279.98 Q 480.10, 284.61, 488.55, 290.17 Q 497.38, 295.06, 505.65, 300.92 Q 514.43,\
                        305.91, 522.90, 311.43 Q 531.15, 317.30, 539.77, 322.57 Q 548.87, 327.02, 557.93, 331.53 Q 566.53, 336.84, 575.04, 342.28\
                        Q 583.92, 347.11, 592.94, 351.70 Q 601.64, 356.83, 610.30, 362.01 Q 618.52, 367.95, 626.86, 373.67 Q 636.04, 378.01, 644.35,\
                        383.78 Q 653.21, 388.64, 661.90, 393.79 Q 670.71, 398.73, 679.54, 403.62 Q 687.98, 409.20, 695.87, 415.69 Q 704.55, 420.84,\
                        713.36, 425.79 Q 722.02, 430.98, 731.14, 435.40 Q 739.48, 441.13, 748.65, 445.47 Q 757.57, 450.21, 766.14, 455.56 Q 774.54,\
                        461.19, 782.81, 467.05 Q 791.77, 471.74, 800.21, 477.30 Q 809.10, 482.11, 817.20, 488.24 Q 826.18, 492.89, 834.89, 498.01\
                        Q 844.04, 502.37, 852.61, 507.71 Q 861.18, 513.07, 869.90, 518.15 Q 878.17, 524.01, 887.71, 527.73 Q 895.67, 534.09, 904.93,\
                        538.27 Q 913.64, 543.38, 922.39, 548.43 Q 931.08, 553.57, 939.97, 558.39 Q 948.80, 563.28, 957.34, 568.69 Q 965.57, 574.59,\
                        974.12, 579.97 Q 983.01, 584.79, 991.90, 589.60 Q 1000.23, 595.34, 1008.52, 601.16 Q 1017.19, 606.33, 1025.78, 611.64 Q 1034.71,\
                        616.37, 1043.24, 621.80 Q 1052.09, 626.67, 1060.83, 631.72 Q 1069.63, 636.68, 1078.23, 641.98 Q 1086.78, 647.36, 1095.60,\
                        652.29 Q 1104.73, 656.69, 1113.44, 661.80 Q 1121.67, 667.72, 1130.53, 672.57 Q 1139.46, 677.31, 1147.55, 683.46 Q 1156.34,\
                        688.43, 1165.05, 693.55 Q 1173.63, 698.88, 1182.71, 703.37 Q 1191.41, 708.49, 1199.96, 713.87 Q 1208.71, 718.90, 1217.75,\
                        723.47 Q 1226.56, 728.40, 1235.05, 733.89 Q 1243.34, 739.70, 1252.10, 744.72 Q 1260.74, 749.95, 1269.38, 755.17 Q 1277.75,\
                        760.85, 1286.24, 766.34 Q 1295.23, 770.98, 1304.26, 775.54 Q 1313.23, 780.22, 1321.99, 785.24 Q 1330.07, 791.42, 1338.96,\
                        796.22 Q 1347.91, 800.93, 1356.64, 806.01 Q 1364.33, 812.83, 1373.00, 818.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 818.00 Q 10.46, 812.46, 19.11, 807.22 Q 27.73, 801.94, 36.43, 796.79\
                        Q 45.44, 792.17, 54.05, 786.86 Q 62.79, 781.79, 71.22, 776.19 Q 79.97, 771.12, 88.98, 766.49 Q 97.28, 760.68, 106.22, 755.93\
                        Q 114.89, 750.72, 123.71, 745.78 Q 132.25, 740.37, 140.92, 735.16 Q 149.72, 730.19, 158.28, 724.81 Q 167.34, 720.26, 176.07,\
                        715.18 Q 184.45, 709.49, 193.06, 704.18 Q 202.24, 699.84, 211.06, 694.90 Q 219.54, 689.38, 228.43, 684.55 Q 236.86, 678.95,\
                        245.67, 673.99 Q 254.29, 668.70, 262.72, 663.11 Q 271.21, 657.60, 280.31, 653.13 Q 289.64, 649.05, 297.80, 642.98 Q 306.24,\
                        637.41, 314.87, 632.14 Q 323.18, 626.33, 331.88, 621.18 Q 340.88, 616.53, 349.31, 610.93 Q 357.72, 605.30, 367.01, 601.14\
                        Q 375.18, 595.11, 384.41, 590.85 Q 392.64, 584.91, 401.59, 580.19 Q 409.97, 574.50, 418.85, 569.66 Q 427.14, 563.82, 435.96,\
                        558.88 Q 444.49, 553.44, 454.15, 549.91 Q 462.34, 543.90, 470.99, 538.67 Q 479.37, 532.99, 487.98, 527.68 Q 496.88, 522.87,\
                        505.90, 518.27 Q 514.92, 513.66, 524.07, 509.26 Q 532.29, 503.31, 540.75, 497.75 Q 549.26, 492.29, 558.18, 487.52 Q 566.91,\
                        482.43, 576.21, 478.28 Q 584.29, 472.09, 592.73, 466.50 Q 601.71, 461.82, 610.12, 456.19 Q 619.01, 451.37, 627.59, 446.02\
                        Q 636.22, 440.75, 644.53, 434.95 Q 653.38, 430.04, 662.11, 424.96 Q 670.95, 420.04, 679.89, 415.30 Q 688.47, 409.95, 696.83,\
                        404.22 Q 705.07, 398.30, 714.06, 393.64 Q 723.40, 389.58, 732.30, 384.76 Q 740.52, 378.81, 749.06, 373.39 Q 757.87, 368.42,\
                        766.88, 363.80 Q 775.35, 358.27, 783.59, 352.36 Q 792.87, 348.18, 801.60, 343.08 Q 809.89, 337.24, 818.52, 331.97 Q 827.36,\
                        327.07, 836.22, 322.19 Q 844.68, 316.63, 852.82, 310.54 Q 861.55, 305.45, 870.66, 301.00 Q 879.11, 295.43, 887.93, 290.48\
                        Q 897.69, 287.12, 906.66, 282.42 Q 915.26, 277.11, 923.11, 270.53 Q 931.84, 265.42, 940.48, 260.19 Q 949.45, 255.50, 957.66,\
                        249.52 Q 966.17, 244.06, 974.84, 238.85 Q 983.69, 233.96, 992.24, 228.56 Q 1001.02, 223.54, 1009.78, 218.51 Q 1018.50, 213.39,\
                        1027.16, 208.17 Q 1036.11, 203.44, 1045.07, 198.73 Q 1053.31, 192.82, 1061.55, 186.89 Q 1070.58, 182.30, 1079.01, 176.69 Q\
                        1087.79, 171.69, 1096.48, 166.53 Q 1105.49, 161.89, 1114.04, 156.49 Q 1122.36, 150.70, 1131.09, 145.62 Q 1140.38, 141.46,\
                        1149.31, 136.69 Q 1158.16, 131.80, 1166.52, 126.09 Q 1175.15, 120.81, 1183.63, 115.30 Q 1192.36, 110.20, 1201.19, 105.28 Q\
                        1209.83, 100.03, 1218.17, 94.27 Q 1227.29, 89.83, 1236.06, 84.80 Q 1244.28, 78.84, 1253.00, 73.73 Q 1262.34, 69.66, 1270.51,\
                        63.63 Q 1279.00, 58.12, 1287.38, 52.43 Q 1295.98, 47.11, 1304.90, 42.34 Q 1313.58, 37.16, 1322.30, 32.05 Q 1331.41, 27.60,\
                        1339.97, 22.21 Q 1348.74, 17.17, 1357.18, 11.59 Q 1366.31, 7.17, 1375.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-1133179516" style="position: absolute; left: 170px; top: 0px; width: 970px; height: 120px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1133179516" data-review-reference-id="1133179516">\
            <div class="stencil-wrapper" style="width: 970px; height: 120px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 120px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 120px;width:970px;" width="970" height="120" viewBox="0 0 970 120">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="120" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-455443703" style="position: absolute; left: 455px; top: 15px; width: 410px; height: 48px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="455443703" data-review-reference-id="455443703">\
            <div class="stencil-wrapper" style="width: 410px; height: 48px">\
               <div title="" style="width:415px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 42px;">MONDAY MORNING</span> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-883124678" style="position: absolute; left: 295px; top: 85px; width: 731px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="883124678" data-review-reference-id="883124678">\
            <div class="stencil-wrapper" style="width: 731px; height: 37px">\
               <div title="" style="width:736px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">THE OFFICIAL MEDIA BODY OF NIT ROURKELA</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-914748283" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="914748283" data-review-reference-id="914748283">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e191" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e191</title>\
<path class="path1" d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM277.357 531.417q0 6.99 4.926 11.756t11.915 4.846h150.92v152.907q0 6.911 4.846 11.915t11.756 4.926h100.559q6.99 0 11.915-4.926t5.004-11.915v-152.907h150.601q6.911 0 11.915-4.846t4.926-11.756v-100.559q0-6.99-4.926-11.756t-11.915-4.846h-150.601v-150.92q0-6.911-5.004-11.915t-11.915-4.926h-100.559q-6.99 0-11.756 4.926t-4.846 11.915v150.92h-150.92q-6.911 0-11.915 4.846t-4.926 11.756v100.559z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e368" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e368</title>\
<path class="path1" d="M181.008 679.716v-364.035q0-54.969 38.921-93.729t93.491-38.682h364.035q54.969 0 93.729 38.682t38.682 93.729v364.035q0 54.969-38.682 93.65t-93.729 38.762h-364.035q-54.57 0-93.491-38.762t-38.921-93.65zM247.255 712.839q0 13.583 9.77 23.273t23.273 9.77h430.281q13.583 0 23.353-9.77t9.77-23.273v-430.281q0-13.583-9.77-23.353t-23.353-9.77h-430.281q-13.502 0-23.273 9.77t-9.77 23.353v430.281zM345.513 425.852q4.291-10.883 17.554-10.883h264.745q13.264 0 17.554 11.36t-3.972 22.4l-126.375 175.384q-7.944 10.961-19.539 11.756t-19.539-10.089l-126.455-178.086q-8.262-10.883-3.972-21.844z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path class="path1" d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e046" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e046</title>\
<path class="path1" d="M114.842 845.172v-529.492h761.193v529.492q0 13.583-9.77 23.353t-23.273 9.77h-695.028q-13.583 0-23.353-9.77t-9.77-23.353zM114.842 282.557v-99.289q0-13.583 9.77-23.353t23.353-9.77h66.167v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.044q13.583 0 23.353 9.77t9.77 23.353v33.044h364.035v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.124q13.583 0 23.273 9.77t9.77 23.353v33.044h66.246q13.583 0 23.273 9.77t9.77 23.353v99.289h-761.193zM181.008 812.128h99.289v-99.289h-99.289v99.289zM181.008 679.716h99.289v-99.289h-99.289v99.289zM181.008 547.303h99.289v-99.289h-99.289v99.289zM313.421 812.128h99.289v-99.289h-99.289v99.289zM313.421 679.716h99.289v-99.289h-99.289v99.289zM313.421 547.303h99.289v-99.289h-99.289v99.289zM445.833 812.128h99.289v-99.289h-99.289v99.289zM445.833 679.716h99.289v-99.289h-99.289v99.289zM445.833 547.303h99.289v-99.289h-99.289v99.289zM578.167 812.128h99.289v-99.289h-99.289v99.289zM578.167 679.716h99.289v-99.289h-99.289v99.289zM578.167 547.303h99.289v-99.289h-99.289v99.289zM710.579 812.128h99.289v-99.289h-99.289v99.289zM710.579 679.716h99.289v-99.289h-99.289v99.289zM710.579 547.303h99.289v-99.289h-99.289v99.289z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e212" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e212</title>\
<path class="path1" d="M181.008 563.586v-164.821q0-6.674 5.163-11.756t11.756-5.163h280.95v-171.413q0-6.99 3.972-8.817t9.294 2.463l345.208 266.812q5.639 4.291 5.639 10.247t-5.639 10.247l-344.893 267.129q-5.639 3.972-9.612 2.145t-3.972-8.817v-171.413h-280.95q-6.592 0-11.756-5.164t-5.163-11.677z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-1109037301" style="position: absolute; left: 170px; top: 120px; width: 970px; height: 60px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1109037301" data-review-reference-id="1109037301">\
            <div class="stencil-wrapper" style="width: 970px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 60px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 60px;width:970px;" width="970" height="60" viewBox="0 0 970 60">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="60" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-1495855311" style="position: absolute; left: 240px; top: 135px; width: 52px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1495855311" data-review-reference-id="1495855311">\
            <div class="stencil-wrapper" style="width: 52px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:56px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="56" height="34" viewBox="-2 -2 56 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.47, 29.56, 1.18, 28.82 Q 0.45, 27.75, -0.31, 26.41 Q -0.26,\
                        14.19, 0.13, 1.85 Q 0.40, 0.64, 1.09, -0.81 Q 2.19, -1.57, 3.64, -2.11 Q 15.39, -1.71, 26.94, -1.82 Q 38.45, -2.32, 50.29,\
                        -2.33 Q 51.49, -1.86, 52.74, -0.83 Q 53.44, 0.29, 54.22, 1.61 Q 54.15, 13.83, 53.76, 26.13 Q 52.76, 27.09, 52.08, 28.07 Q\
                        51.09, 28.62, 50.01, 29.03 Q 38.59, 29.61, 27.06, 29.88 Q 15.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="26" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Home</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-937609372" style="position: absolute; left: 340px; top: 135px; width: 550px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="937609372" data-review-reference-id="937609372">\
            <div class="stencil-wrapper" style="width: 550px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:550px;" width="550" height="30">\
                     <svg:g id="__containerId__-502299397-layer-937609372svg" width="550" height="30"><svg:path id="__containerId__-502299397-layer-937609372_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00\
                        Q 12.11, -0.23, 22.22, -0.31 Q 32.33, -0.40, 42.44, 0.44 Q 52.56, 0.48, 62.67, -0.13 Q 72.78, 0.99, 82.89, 1.09 Q 93.00, 0.49,\
                        103.11, 0.84 Q 113.22, 0.20, 123.33, 0.71 Q 133.44, 1.56, 143.56, 1.79 Q 153.67, 1.93, 163.78, 1.94 Q 173.89, 2.08, 184.00,\
                        1.07 Q 194.11, 1.79, 204.22, 2.05 Q 214.33, 1.60, 224.44, 1.01 Q 234.56, 1.69, 244.67, 1.50 Q 254.78, 1.63, 264.89, 1.86 Q\
                        275.00, 1.19, 285.11, 0.91 Q 295.22, 0.67, 305.33, 0.73 Q 315.44, 0.65, 325.56, 0.62 Q 335.67, 0.78, 345.78, 0.97 Q 355.89,\
                        0.83, 366.00, 0.09 Q 376.11, 0.08, 386.22, 0.51 Q 396.33, 0.61, 406.44, 0.37 Q 416.56, 0.10, 426.67, 0.14 Q 436.78, 0.52,\
                        446.89, 0.80 Q 457.00, 1.51, 467.11, 2.14 Q 477.22, 2.30, 487.33, 1.51 Q 497.44, 0.94, 507.56, 1.66 Q 517.67, 0.83, 527.78,\
                        1.79 Q 537.89, 2.12, 548.46, 1.54 Q 548.87, 14.71, 548.51, 28.51 Q 538.23, 29.24, 527.96, 29.64 Q 517.73, 29.31, 507.59, 29.39\
                        Q 497.46, 29.06, 487.34, 29.04 Q 477.22, 28.82, 467.11, 29.05 Q 457.00, 29.42, 446.89, 29.53 Q 436.78, 29.63, 426.67, 29.73\
                        Q 416.56, 29.22, 406.44, 28.97 Q 396.33, 29.53, 386.22, 29.11 Q 376.11, 29.56, 366.00, 29.18 Q 355.89, 29.03, 345.78, 28.52\
                        Q 335.67, 28.23, 325.56, 28.32 Q 315.44, 28.80, 305.33, 28.82 Q 295.22, 28.54, 285.11, 29.43 Q 275.00, 28.64, 264.89, 28.94\
                        Q 254.78, 27.97, 244.67, 28.40 Q 234.56, 28.35, 224.44, 28.22 Q 214.33, 28.83, 204.22, 28.25 Q 194.11, 29.14, 184.00, 29.28\
                        Q 173.89, 28.73, 163.78, 28.79 Q 153.67, 28.69, 143.56, 29.71 Q 133.44, 29.98, 123.33, 29.75 Q 113.22, 29.35, 103.11, 29.03\
                        Q 93.00, 29.43, 82.89, 29.96 Q 72.78, 29.60, 62.67, 29.52 Q 52.56, 29.37, 42.44, 29.03 Q 32.33, 29.51, 22.22, 29.54 Q 12.11,\
                        29.54, 1.62, 28.38 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-502299397-layer-937609372_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 1.96,\
                        23.15, 1.56 Q 33.22, 1.32, 43.30, 1.36 Q 53.37, 2.22, 63.44, 1.74 Q 73.52, 2.39, 83.59, 1.81 Q 93.67, 2.19, 103.74, 2.61 Q\
                        113.81, 2.24, 123.89, 2.02 Q 133.96, 2.85, 144.04, 3.24 Q 154.11, 2.70, 164.19, 2.43 Q 174.26, 2.05, 184.33, 2.40 Q 194.41,\
                        2.59, 204.48, 2.15 Q 214.56, 2.02, 224.63, 2.00 Q 234.70, 2.86, 244.78, 2.78 Q 254.85, 2.37, 264.93, 2.92 Q 275.00, 2.93,\
                        285.07, 2.80 Q 295.15, 2.45, 305.22, 2.47 Q 315.30, 2.55, 325.37, 2.79 Q 335.44, 2.48, 345.52, 1.88 Q 355.59, 2.20, 365.67,\
                        1.86 Q 375.74, 1.33, 385.81, 1.31 Q 395.89, 1.07, 405.96, 0.93 Q 416.04, 1.23, 426.11, 1.20 Q 436.18, 0.73, 446.26, 0.78 Q\
                        456.33, 2.14, 466.41, 2.18 Q 476.48, 1.92, 486.56, 1.95 Q 496.63, 1.26, 506.70, 1.14 Q 516.78, 1.32, 526.85, 2.29 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-502299397-layer-937609372_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-502299397-layer-937609372_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 3.43,\
                        23.15, 2.63 Q 33.22, 1.93, 43.30, 2.80 Q 53.37, 2.27, 63.44, 2.29 Q 73.52, 2.68, 83.59, 1.86 Q 93.67, 1.13, 103.74, 1.03 Q\
                        113.81, 1.77, 123.89, 1.74 Q 133.96, 2.11, 144.04, 2.90 Q 154.11, 2.58, 164.19, 2.70 Q 174.26, 2.30, 184.33, 1.31 Q 194.41,\
                        1.68, 204.48, 1.46 Q 214.56, 1.55, 224.63, 2.96 Q 234.70, 3.09, 244.78, 2.64 Q 254.85, 2.49, 264.93, 2.69 Q 275.00, 3.60,\
                        285.07, 3.33 Q 295.15, 3.62, 305.22, 2.70 Q 315.30, 2.45, 325.37, 2.75 Q 335.44, 2.38, 345.52, 2.30 Q 355.59, 1.43, 365.67,\
                        0.82 Q 375.74, 0.81, 385.81, 0.85 Q 395.89, 1.13, 405.96, 0.96 Q 416.04, 0.77, 426.11, 0.76 Q 436.18, 1.48, 446.26, 1.22 Q\
                        456.33, 2.48, 466.41, 1.37 Q 476.48, 1.43, 486.56, 1.33 Q 496.63, 1.56, 506.70, 1.97 Q 516.78, 1.88, 526.85, 1.36 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-502299397-layer-937609372_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-502299397-layer-937609372input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-502299397-layer-937609372_input_svg_border\',\'__containerId__-502299397-layer-937609372_line1\',\'__containerId__-502299397-layer-937609372_line2\',\'__containerId__-502299397-layer-937609372_line3\',\'__containerId__-502299397-layer-937609372_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-502299397-layer-937609372_input_svg_border\',\'__containerId__-502299397-layer-937609372_line1\',\'__containerId__-502299397-layer-937609372_line2\',\'__containerId__-502299397-layer-937609372_line3\',\'__containerId__-502299397-layer-937609372_line4\'))" value="Search Box" style="width:543px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-401890033" style="position: absolute; left: 955px; top: 135px; width: 50px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="401890033" data-review-reference-id="401890033">\
            <div class="stencil-wrapper" style="width: 50px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:54px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="54" height="34" viewBox="-2 -2 54 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.08, 30.33, 1.20, 28.80 Q 0.69, 27.58, 0.52, 26.15 Q 0.60, 14.06,\
                        0.94, 1.99 Q 2.08, 1.19, 1.87, -0.12 Q 2.75, -0.83, 3.65, -2.08 Q 14.86, -1.91, 25.91, -2.27 Q 36.96, -1.99, 48.18, -1.83\
                        Q 49.10, -0.77, 51.06, -1.19 Q 50.95, 0.66, 51.87, 1.72 Q 51.91, 13.86, 52.01, 26.17 Q 51.72, 27.40, 50.26, 28.23 Q 49.29,\
                        28.89, 48.13, 29.41 Q 37.15, 29.99, 26.01, 29.21 Q 15.00, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="25" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Login</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-1682187845" style="position: absolute; left: 1045px; top: 135px; width: 59px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1682187845" data-review-reference-id="1682187845">\
            <div class="stencil-wrapper" style="width: 59px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:63px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="63" height="34" viewBox="-2 -2 63 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.72, 29.05, 1.46, 28.54 Q 0.86, 27.46, 0.70, 26.10 Q 0.30, 14.10,\
                        0.85, 1.97 Q 1.21, 0.90, 2.10, 0.09 Q 2.83, -0.72, 3.81, -1.60 Q 17.29, -0.71, 30.54, -0.41 Q 43.75, -1.08, 56.90, -0.53 Q\
                        57.80, 0.07, 58.48, 0.58 Q 58.81, 1.52, 59.84, 2.05 Q 60.31, 13.95, 60.47, 26.08 Q 58.95, 26.82, 57.92, 27.04 Q 57.10, 27.31,\
                        56.44, 27.27 Q 43.74, 28.96, 30.48, 28.76 Q 17.25, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="29.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">SignUp</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-1863991629" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1863991629" data-review-reference-id="1863991629">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-51062820" style="position: absolute; left: 0px; top: 778px; width: 1375px; height: 40px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="51062820" data-review-reference-id="51062820">\
            <div class="stencil-wrapper" style="width: 1375px; height: 40px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 40px; width:1375px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 40px;width:1375px;" width="1375" height="40" viewBox="0 0 1375 40">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="1375" height="40" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-88926350" style="position: absolute; left: 455px; top: 783px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="88926350" data-review-reference-id="88926350">\
            <div class="stencil-wrapper" style="width: 403px; height: 20px">\
               <div title="" style="width:408px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Fixed footer for ASK A QUESTION AND FORUM </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-1734703617" style="position: absolute; left: 170px; top: 180px; width: 970px; height: 600px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1734703617" data-review-reference-id="1734703617">\
            <div class="stencil-wrapper" style="width: 970px; height: 600px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 600px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 600px;width:970px;" width="970" height="600" viewBox="0 0 970 600">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="600" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-502299397-layer-800472426" style="position: absolute; left: 175px; top: 15px; width: 95px; height: 80px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="800472426" data-review-reference-id="800472426">\
            <div class="stencil-wrapper" style="width: 95px; height: 80px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 80px;width:95px;" width="95" height="80">\
                     <svg:g width="95" height="80"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.38, 1.05, 24.75, 2.09 Q 36.12, 1.65, 47.50, 2.50 Q\
                        58.88, 1.35, 70.25, 0.72 Q 81.62, 1.52, 93.20, 1.80 Q 93.75, 14.42, 93.49, 27.26 Q 93.52, 39.97, 94.22, 52.63 Q 93.58, 65.32,\
                        93.47, 78.47 Q 81.74, 78.34, 70.45, 79.41 Q 58.96, 79.25, 47.56, 79.84 Q 36.15, 79.54, 24.75, 78.15 Q 13.38, 78.07, 2.50,\
                        77.50 Q 1.38, 65.54, 1.69, 52.71 Q 2.24, 39.98, 2.46, 27.32 Q 2.00, 14.67, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.71, 8.87, 20.83, 16.45 Q 30.11, 23.82, 39.28, 31.34 Q 48.16,\
                        39.21, 57.30, 46.76 Q 66.13, 54.69, 75.67, 61.76 Q 83.90, 70.40, 93.00, 78.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 78.00 Q 10.26, 72.28, 17.38, 65.19 Q 24.97, 58.66, 32.36, 51.88 Q 40.25,\
                        45.72, 48.21, 39.65 Q 55.81, 33.12, 62.97, 26.07 Q 71.07, 20.17, 78.51, 13.45 Q 87.25, 8.33, 95.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="502299397"] .border-wrapper, body[data-current-page-id="502299397"] .simulation-container{\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="502299397"] .border-wrapper, body.has-frame[data-current-page-id="502299397"] .simulation-container{\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="502299397"] .svg-border-1366-768{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="502299397"] .border-wrapper .border-div{\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "502299397",\
      			"name": "header n footer",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
   <div id="border-wrapper">\
      <div xmlns="http://www.w3.org/1999/xhtml" xmlns:json="http://json.org/" class="svg-border svg-border-1366-768" style="display: none;">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="svg_border" style="position:absolute;left:-43px;top:-13px;width:1423px;height:792px;"><svg:path class=" svg_unselected_element" d="M 32.00, 3.00 Q 42.12, 1.89, 52.24, 1.85 Q 62.35, 1.73, 72.47, 1.47 Q 82.59,\
            1.25, 92.71, 1.56 Q 102.82, 1.66, 112.94, 1.44 Q 123.06, 1.30, 133.18, 1.07 Q 143.29, 1.03, 153.41, 1.41 Q 163.53, 2.36, 173.65,\
            1.73 Q 183.76, 2.06, 193.88, 1.46 Q 204.00, 1.40, 214.12, 1.19 Q 224.24, 1.54, 234.35, 0.83 Q 244.47, 0.74, 254.59, 0.94 Q\
            264.71, 1.11, 274.82, 1.63 Q 284.94, 2.30, 295.06, 2.47 Q 305.18, 2.87, 315.29, 2.53 Q 325.41, 2.40, 335.53, 2.85 Q 345.65,\
            2.51, 355.76, 1.97 Q 365.88, 1.84, 376.00, 1.83 Q 386.12, 2.09, 396.24, 1.87 Q 406.35, 1.84, 416.47, 2.36 Q 426.59, 2.09,\
            436.71, 1.64 Q 446.82, 2.23, 456.94, 1.44 Q 467.06, 2.18, 477.18, 1.36 Q 487.29, 1.33, 497.41, 1.80 Q 507.53, 1.59, 517.65,\
            1.70 Q 527.76, 1.03, 537.88, 1.34 Q 548.00, 1.01, 558.12, 1.44 Q 568.24, 1.54, 578.35, 2.32 Q 588.47, 1.67, 598.59, 3.08 Q\
            608.71, 3.47, 618.82, 2.75 Q 628.94, 2.69, 639.06, 2.38 Q 649.18, 2.02, 659.29, 1.65 Q 669.41, 1.84, 679.53, 1.58 Q 689.65,\
            1.83, 699.77, 1.94 Q 709.88, 2.06, 720.00, 1.96 Q 730.12, 2.22, 740.24, 2.84 Q 750.35, 1.96, 760.47, 2.33 Q 770.59, 1.91,\
            780.71, 2.17 Q 790.82, 2.60, 800.94, 2.90 Q 811.06, 3.35, 821.18, 2.55 Q 831.29, 1.52, 841.41, 1.57 Q 851.53, 2.44, 861.65,\
            2.53 Q 871.77, 1.62, 881.88, 1.32 Q 892.00, 1.66, 902.12, 2.90 Q 912.24, 3.62, 922.35, 1.30 Q 932.47, 1.56, 942.59, 1.28 Q\
            952.71, 1.87, 962.82, 1.99 Q 972.94, 1.87, 983.06, 2.38 Q 993.18, 2.75, 1003.30, 2.01 Q 1013.41, 1.26, 1023.53, 1.01 Q 1033.65,\
            1.10, 1043.77, 1.38 Q 1053.88, 1.39, 1064.00, 1.48 Q 1074.12, 1.62, 1084.24, 2.01 Q 1094.35, 1.40, 1104.47, 1.90 Q 1114.59,\
            2.97, 1124.71, 2.89 Q 1134.83, 2.08, 1144.94, 1.62 Q 1155.06, 1.87, 1165.18, 3.43 Q 1175.30, 3.52, 1185.41, 3.54 Q 1195.53,\
            2.38, 1205.65, 2.61 Q 1215.77, 2.35, 1225.88, 2.65 Q 1236.00, 2.24, 1246.12, 2.23 Q 1256.24, 2.17, 1266.35, 2.37 Q 1276.47,\
            2.94, 1286.59, 1.71 Q 1296.71, 2.15, 1306.83, 1.43 Q 1316.94, 1.49, 1327.06, 1.13 Q 1337.18, 1.46, 1347.30, 1.52 Q 1357.41,\
            1.24, 1367.53, 2.35 Q 1377.65, 2.70, 1387.77, 1.95 Q 1397.88, 1.96, 1408.50, 2.50 Q 1408.81, 12.90, 1408.59, 23.26 Q 1407.75,\
            33.53, 1407.24, 43.71 Q 1407.59, 53.86, 1408.52, 64.02 Q 1408.30, 74.20, 1408.40, 84.37 Q 1409.00, 94.54, 1408.97, 104.71\
            Q 1409.02, 114.88, 1408.29, 125.05 Q 1408.05, 135.22, 1407.90, 145.39 Q 1408.26, 155.57, 1408.61, 165.74 Q 1409.13, 175.91,\
            1408.33, 186.08 Q 1408.37, 196.25, 1408.59, 206.42 Q 1408.23, 216.59, 1409.44, 226.76 Q 1408.07, 236.93, 1408.31, 247.11 Q\
            1408.82, 257.28, 1408.60, 267.45 Q 1408.63, 277.62, 1408.72, 287.79 Q 1408.84, 297.96, 1409.34, 308.13 Q 1409.81, 318.30,\
            1408.64, 328.47 Q 1408.31, 338.64, 1408.86, 348.82 Q 1409.41, 358.99, 1408.85, 369.16 Q 1408.54, 379.33, 1408.29, 389.50 Q\
            1408.82, 399.67, 1410.13, 409.84 Q 1408.96, 420.01, 1408.59, 430.18 Q 1408.53, 440.36, 1409.51, 450.53 Q 1409.60, 460.70,\
            1409.58, 470.87 Q 1409.20, 481.04, 1409.22, 491.21 Q 1409.45, 501.38, 1409.36, 511.55 Q 1408.95, 521.72, 1408.55, 531.89 Q\
            1408.38, 542.07, 1407.84, 552.24 Q 1407.85, 562.41, 1408.70, 572.58 Q 1409.47, 582.75, 1409.72, 592.92 Q 1409.84, 603.09,\
            1409.85, 613.26 Q 1409.67, 623.43, 1409.72, 633.61 Q 1409.08, 643.78, 1409.10, 653.95 Q 1409.23, 664.12, 1409.11, 674.29 Q\
            1409.03, 684.46, 1408.44, 694.63 Q 1408.30, 704.80, 1408.32, 714.97 Q 1408.08, 725.15, 1407.85, 735.32 Q 1408.46, 745.49,\
            1409.00, 755.66 Q 1409.00, 765.83, 1408.60, 776.60 Q 1398.22, 777.01, 1387.90, 776.90 Q 1377.73, 777.19, 1367.57, 777.14 Q\
            1357.43, 777.18, 1347.31, 777.48 Q 1337.19, 777.99, 1327.07, 778.26 Q 1316.95, 777.79, 1306.83, 777.40 Q 1296.71, 776.52,\
            1286.59, 775.88 Q 1276.47, 775.94, 1266.35, 777.10 Q 1256.24, 776.73, 1246.12, 776.57 Q 1236.00, 776.42, 1225.88, 777.02 Q\
            1215.77, 776.77, 1205.65, 776.29 Q 1195.53, 776.13, 1185.41, 776.22 Q 1175.30, 776.10, 1165.18, 776.21 Q 1155.06, 776.09,\
            1144.94, 776.69 Q 1134.83, 776.59, 1124.71, 776.17 Q 1114.59, 775.70, 1104.47, 776.17 Q 1094.35, 776.51, 1084.24, 776.45 Q\
            1074.12, 775.78, 1064.00, 775.56 Q 1053.88, 776.59, 1043.77, 776.77 Q 1033.65, 776.01, 1023.53, 776.13 Q 1013.41, 775.71,\
            1003.30, 777.29 Q 993.18, 777.32, 983.06, 777.26 Q 972.94, 777.53, 962.82, 777.96 Q 952.71, 777.55, 942.59, 776.82 Q 932.47,\
            776.21, 922.35, 777.42 Q 912.24, 778.10, 902.12, 777.85 Q 892.00, 777.07, 881.88, 776.02 Q 871.77, 775.82, 861.65, 775.28\
            Q 851.53, 775.41, 841.41, 776.44 Q 831.29, 775.91, 821.18, 776.70 Q 811.06, 776.55, 800.94, 776.64 Q 790.82, 776.42, 780.71,\
            776.98 Q 770.59, 776.87, 760.47, 776.84 Q 750.35, 776.61, 740.24, 775.93 Q 730.12, 776.27, 720.00, 775.18 Q 709.88, 775.12,\
            699.77, 775.49 Q 689.65, 776.31, 679.53, 776.87 Q 669.41, 776.32, 659.29, 775.76 Q 649.18, 775.89, 639.06, 776.26 Q 628.94,\
            776.43, 618.82, 777.17 Q 608.71, 777.28, 598.59, 777.40 Q 588.47, 777.79, 578.35, 777.48 Q 568.24, 776.97, 558.12, 775.95\
            Q 548.00, 776.28, 537.88, 775.67 Q 527.76, 775.94, 517.65, 775.56 Q 507.53, 775.95, 497.41, 776.01 Q 487.29, 775.22, 477.18,\
            775.96 Q 467.06, 775.91, 456.94, 776.47 Q 446.82, 775.55, 436.71, 775.77 Q 426.59, 775.74, 416.47, 776.05 Q 406.35, 776.52,\
            396.24, 775.96 Q 386.12, 775.28, 376.00, 775.54 Q 365.88, 777.37, 355.76, 776.97 Q 345.65, 776.24, 335.53, 776.09 Q 325.41,\
            777.17, 315.29, 776.68 Q 305.18, 776.36, 295.06, 776.63 Q 284.94, 776.57, 274.82, 776.53 Q 264.71, 777.18, 254.59, 777.65\
            Q 244.47, 777.98, 234.35, 778.17 Q 224.24, 778.03, 214.12, 777.85 Q 204.00, 778.10, 193.88, 777.35 Q 183.76, 777.34, 173.65,\
            777.64 Q 163.53, 777.08, 153.41, 776.80 Q 143.29, 777.19, 133.18, 776.56 Q 123.06, 776.55, 112.94, 776.46 Q 102.82, 776.39,\
            92.71, 777.40 Q 82.59, 776.63, 72.47, 776.68 Q 62.35, 776.79, 52.24, 776.99 Q 42.12, 776.41, 31.71, 776.29 Q 31.56, 765.98,\
            31.14, 755.78 Q 30.16, 745.61, 30.01, 735.38 Q 31.31, 725.16, 31.85, 714.98 Q 31.70, 704.80, 31.25, 694.63 Q 31.19, 684.46,\
            30.91, 674.29 Q 30.79, 664.12, 30.22, 653.95 Q 30.23, 643.78, 30.07, 633.61 Q 29.82, 623.43, 29.79, 613.26 Q 29.92, 603.09,\
            30.28, 592.92 Q 30.31, 582.75, 30.82, 572.58 Q 30.42, 562.41, 30.39, 552.24 Q 30.26, 542.07, 30.37, 531.89 Q 30.49, 521.72,\
            30.71, 511.55 Q 32.05, 501.38, 31.60, 491.21 Q 31.90, 481.04, 32.07, 470.87 Q 31.99, 460.70, 32.75, 450.53 Q 32.41, 440.36,\
            32.64, 430.18 Q 32.39, 420.01, 31.74, 409.84 Q 31.60, 399.67, 30.68, 389.50 Q 30.44, 379.33, 30.68, 369.16 Q 30.48, 358.99,\
            30.03, 348.82 Q 30.05, 338.64, 29.83, 328.47 Q 30.20, 318.30, 30.43, 308.13 Q 29.92, 297.96, 30.07, 287.79 Q 30.45, 277.62,\
            30.68, 267.45 Q 30.21, 257.28, 30.87, 247.11 Q 30.52, 236.93, 30.36, 226.76 Q 30.40, 216.59, 30.97, 206.42 Q 31.46, 196.25,\
            31.50, 186.08 Q 32.07, 175.91, 31.44, 165.74 Q 31.37, 155.57, 31.16, 145.39 Q 31.39, 135.22, 31.29, 125.05 Q 31.67, 114.88,\
            31.44, 104.71 Q 31.48, 94.54, 31.35, 84.37 Q 31.02, 74.20, 30.80, 64.03 Q 30.59, 53.86, 30.30, 43.68 Q 30.62, 33.51, 30.73,\
            23.34 Q 32.00, 13.17, 32.00, 3.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 23.00, 7.00 Q 33.12, 7.28, 43.24, 6.34 Q 53.35, 6.24, 63.47, 5.40 Q 73.59,\
            6.16, 83.71, 5.98 Q 93.82, 6.14, 103.94, 5.30 Q 114.06, 5.32, 124.18, 4.81 Q 134.29, 4.76, 144.41, 4.52 Q 154.53, 5.11, 164.65,\
            6.10 Q 174.76, 6.53, 184.88, 6.19 Q 195.00, 6.09, 205.12, 5.53 Q 215.24, 5.54, 225.35, 4.89 Q 235.47, 5.57, 245.59, 4.73 Q\
            255.71, 5.36, 265.82, 4.80 Q 275.94, 4.97, 286.06, 5.48 Q 296.18, 6.27, 306.29, 6.84 Q 316.41, 7.78, 326.53, 8.09 Q 336.65,\
            7.32, 346.76, 7.51 Q 356.88, 7.31, 367.00, 6.76 Q 377.12, 6.62, 387.24, 6.04 Q 397.35, 6.89, 407.47, 6.79 Q 417.59, 5.22,\
            427.71, 5.09 Q 437.82, 5.68, 447.94, 5.81 Q 458.06, 5.22, 468.18, 5.20 Q 478.29, 5.48, 488.41, 6.20 Q 498.53, 5.84, 508.65,\
            5.31 Q 518.76, 4.98, 528.88, 5.16 Q 539.00, 5.37, 549.12, 4.95 Q 559.24, 5.28, 569.35, 5.03 Q 579.47, 5.02, 589.59, 5.08 Q\
            599.71, 5.07, 609.82, 6.31 Q 619.94, 7.01, 630.06, 7.54 Q 640.18, 6.81, 650.29, 6.82 Q 660.41, 6.92, 670.53, 7.17 Q 680.65,\
            7.76, 690.77, 7.50 Q 700.88, 7.23, 711.00, 6.90 Q 721.12, 7.47, 731.24, 6.73 Q 741.35, 5.77, 751.47, 5.08 Q 761.59, 5.43,\
            771.71, 5.68 Q 781.82, 6.40, 791.94, 6.64 Q 802.06, 5.60, 812.18, 5.38 Q 822.29, 5.58, 832.41, 5.22 Q 842.53, 5.32, 852.65,\
            5.15 Q 862.77, 5.30, 872.88, 5.63 Q 883.00, 4.84, 893.12, 5.64 Q 903.24, 5.01, 913.35, 5.62 Q 923.47, 5.59, 933.59, 5.19 Q\
            943.71, 5.59, 953.82, 6.25 Q 963.94, 6.80, 974.06, 6.47 Q 984.18, 6.47, 994.30, 6.50 Q 1004.41, 6.13, 1014.53, 5.52 Q 1024.65,\
            5.74, 1034.77, 5.57 Q 1044.88, 5.59, 1055.00, 6.49 Q 1065.12, 5.22, 1075.24, 6.06 Q 1085.35, 5.93, 1095.47, 5.59 Q 1105.59,\
            5.38, 1115.71, 5.29 Q 1125.83, 5.27, 1135.94, 5.55 Q 1146.06, 6.32, 1156.18, 6.18 Q 1166.30, 5.92, 1176.41, 5.97 Q 1186.53,\
            6.32, 1196.65, 6.34 Q 1206.77, 6.02, 1216.88, 6.51 Q 1227.00, 6.81, 1237.12, 7.49 Q 1247.24, 6.67, 1257.35, 6.69 Q 1267.47,\
            6.73, 1277.59, 6.90 Q 1287.71, 6.83, 1297.83, 6.67 Q 1307.94, 6.13, 1318.06, 6.42 Q 1328.18, 6.92, 1338.30, 7.20 Q 1348.41,\
            6.00, 1358.53, 6.59 Q 1368.65, 6.05, 1378.77, 6.00 Q 1388.88, 5.72, 1399.68, 6.33 Q 1399.48, 17.01, 1399.63, 27.25 Q 1399.88,\
            37.45, 1400.27, 47.64 Q 1400.43, 57.83, 1400.03, 68.02 Q 1400.11, 78.19, 1400.54, 88.37 Q 1400.60, 98.54, 1399.99, 108.71\
            Q 1399.70, 118.88, 1400.27, 129.05 Q 1400.10, 139.22, 1399.22, 149.39 Q 1398.53, 159.57, 1398.42, 169.74 Q 1398.76, 179.91,\
            1399.89, 190.08 Q 1400.19, 200.25, 1400.12, 210.42 Q 1400.34, 220.59, 1400.25, 230.76 Q 1399.79, 240.93, 1400.24, 251.11 Q\
            1400.32, 261.28, 1399.89, 271.45 Q 1399.53, 281.62, 1400.01, 291.79 Q 1400.29, 301.96, 1400.35, 312.13 Q 1400.13, 322.30,\
            1399.85, 332.47 Q 1400.42, 342.64, 1400.52, 352.82 Q 1398.89, 362.99, 1399.33, 373.16 Q 1399.16, 383.33, 1400.23, 393.50 Q\
            1399.36, 403.67, 1399.77, 413.84 Q 1399.13, 424.01, 1399.64, 434.18 Q 1398.96, 444.36, 1399.75, 454.53 Q 1399.37, 464.70,\
            1400.22, 474.87 Q 1399.51, 485.04, 1399.66, 495.21 Q 1399.96, 505.38, 1399.19, 515.55 Q 1399.76, 525.72, 1399.60, 535.89 Q\
            1399.59, 546.07, 1399.75, 556.24 Q 1400.14, 566.41, 1399.78, 576.58 Q 1399.18, 586.75, 1399.56, 596.92 Q 1400.12, 607.09,\
            1400.35, 617.26 Q 1399.61, 627.43, 1400.59, 637.61 Q 1400.46, 647.78, 1400.89, 657.95 Q 1401.14, 668.12, 1400.39, 678.29 Q\
            1400.51, 688.46, 1399.54, 698.63 Q 1399.06, 708.80, 1400.57, 718.97 Q 1400.12, 729.15, 1399.81, 739.32 Q 1399.71, 749.49,\
            1400.17, 759.66 Q 1400.34, 769.83, 1399.84, 780.83 Q 1389.14, 780.75, 1378.91, 781.02 Q 1368.72, 781.12, 1358.58, 781.62 Q\
            1348.44, 781.68, 1338.31, 781.89 Q 1328.19, 781.97, 1318.06, 781.61 Q 1307.94, 781.32, 1297.83, 780.66 Q 1287.71, 780.82,\
            1277.59, 780.29 Q 1267.47, 780.42, 1257.35, 780.33 Q 1247.24, 781.55, 1237.12, 780.53 Q 1227.00, 780.17, 1216.88, 781.19 Q\
            1206.77, 781.87, 1196.65, 781.89 Q 1186.53, 782.09, 1176.41, 781.93 Q 1166.30, 781.39, 1156.18, 780.73 Q 1146.06, 781.04,\
            1135.94, 780.43 Q 1125.83, 779.93, 1115.71, 779.77 Q 1105.59, 780.91, 1095.47, 780.94 Q 1085.35, 780.78, 1075.24, 780.97 Q\
            1065.12, 780.81, 1055.00, 781.13 Q 1044.88, 780.85, 1034.77, 780.99 Q 1024.65, 780.72, 1014.53, 780.55 Q 1004.41, 780.40,\
            994.30, 780.57 Q 984.18, 780.52, 974.06, 780.86 Q 963.94, 780.67, 953.82, 780.79 Q 943.71, 780.87, 933.59, 780.60 Q 923.47,\
            779.14, 913.35, 779.13 Q 903.24, 779.90, 893.12, 780.70 Q 883.00, 780.10, 872.88, 780.05 Q 862.77, 779.98, 852.65, 780.75\
            Q 842.53, 781.30, 832.41, 779.77 Q 822.29, 780.32, 812.18, 779.65 Q 802.06, 781.02, 791.94, 780.13 Q 781.82, 779.55, 771.71,\
            779.75 Q 761.59, 780.17, 751.47, 780.28 Q 741.35, 780.89, 731.24, 780.36 Q 721.12, 781.34, 711.00, 780.82 Q 700.88, 780.89,\
            690.77, 781.22 Q 680.65, 780.96, 670.53, 780.21 Q 660.41, 780.95, 650.29, 780.89 Q 640.18, 781.34, 630.06, 780.71 Q 619.94,\
            781.09, 609.82, 781.04 Q 599.71, 781.11, 589.59, 781.01 Q 579.47, 781.06, 569.35, 781.41 Q 559.24, 781.14, 549.12, 780.87\
            Q 539.00, 781.42, 528.88, 780.54 Q 518.76, 779.84, 508.65, 780.05 Q 498.53, 780.18, 488.41, 780.04 Q 478.29, 780.23, 468.18,\
            780.31 Q 458.06, 779.87, 447.94, 779.89 Q 437.82, 780.41, 427.71, 780.69 Q 417.59, 780.74, 407.47, 780.39 Q 397.35, 780.36,\
            387.24, 780.87 Q 377.12, 780.44, 367.00, 780.90 Q 356.88, 780.73, 346.76, 780.88 Q 336.65, 780.24, 326.53, 780.20 Q 316.41,\
            780.97, 306.29, 780.56 Q 296.18, 780.50, 286.06, 780.65 Q 275.94, 780.75, 265.82, 780.19 Q 255.71, 780.50, 245.59, 779.23\
            Q 235.47, 778.97, 225.35, 779.79 Q 215.24, 780.21, 205.12, 780.66 Q 195.00, 780.59, 184.88, 780.91 Q 174.76, 780.22, 164.65,\
            780.39 Q 154.53, 779.54, 144.41, 779.60 Q 134.29, 779.61, 124.18, 780.58 Q 114.06, 781.18, 103.94, 780.57 Q 93.82, 779.88,\
            83.71, 778.67 Q 73.59, 779.08, 63.47, 778.80 Q 53.35, 778.50, 43.24, 778.67 Q 33.12, 779.64, 22.38, 780.62 Q 22.33, 770.05,\
            22.63, 759.71 Q 22.67, 749.51, 21.85, 739.35 Q 22.45, 729.15, 22.63, 718.98 Q 23.43, 708.80, 22.57, 698.63 Q 22.77, 688.46,\
            23.72, 678.29 Q 22.57, 668.12, 22.50, 657.95 Q 22.48, 647.78, 22.73, 637.61 Q 22.46, 627.43, 21.32, 617.26 Q 21.55, 607.09,\
            22.63, 596.92 Q 22.87, 586.75, 23.07, 576.58 Q 23.19, 566.41, 22.53, 556.24 Q 23.50, 546.07, 23.08, 535.89 Q 22.74, 525.72,\
            22.08, 515.55 Q 22.46, 505.38, 22.59, 495.21 Q 23.11, 485.04, 23.24, 474.87 Q 23.74, 464.70, 22.61, 454.53 Q 21.96, 444.36,\
            21.75, 434.18 Q 22.32, 424.01, 22.59, 413.84 Q 24.47, 403.67, 23.87, 393.50 Q 22.26, 383.33, 22.82, 373.16 Q 22.54, 362.99,\
            22.36, 352.82 Q 22.05, 342.64, 22.48, 332.47 Q 22.71, 322.30, 23.43, 312.13 Q 23.09, 301.96, 21.87, 291.79 Q 22.11, 281.62,\
            21.90, 271.45 Q 21.66, 261.28, 21.37, 251.11 Q 21.67, 240.93, 21.49, 230.76 Q 21.51, 220.59, 22.36, 210.42 Q 21.82, 200.25,\
            22.02, 190.08 Q 22.85, 179.91, 23.20, 169.74 Q 23.12, 159.57, 23.19, 149.39 Q 21.99, 139.22, 21.74, 129.05 Q 22.26, 118.88,\
            23.76, 108.71 Q 23.33, 98.54, 24.04, 88.37 Q 23.60, 78.20, 23.07, 68.03 Q 22.27, 57.86, 21.41, 47.68 Q 21.18, 37.51, 21.19,\
            27.34 Q 23.00, 17.17, 23.00, 7.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 40.00, 11.00 Q 50.12, 9.59, 60.24, 9.31 Q 70.35, 9.10, 80.47, 8.77 Q 90.59,\
            8.68, 100.71, 8.90 Q 110.82, 8.93, 120.94, 8.83 Q 131.06, 8.71, 141.18, 8.70 Q 151.29, 9.10, 161.41, 9.12 Q 171.53, 9.44,\
            181.65, 9.29 Q 191.76, 9.11, 201.88, 9.10 Q 212.00, 9.58, 222.12, 9.45 Q 232.24, 9.74, 242.35, 9.00 Q 252.47, 9.22, 262.59,\
            9.72 Q 272.71, 9.79, 282.82, 9.64 Q 292.94, 9.89, 303.06, 10.08 Q 313.18, 10.65, 323.29, 10.38 Q 333.41, 10.10, 343.53, 9.70\
            Q 353.65, 10.02, 363.76, 9.61 Q 373.88, 10.44, 384.00, 10.73 Q 394.12, 10.89, 404.24, 10.63 Q 414.35, 10.73, 424.47, 10.88\
            Q 434.59, 9.87, 444.71, 9.33 Q 454.82, 9.62, 464.94, 9.71 Q 475.06, 9.75, 485.18, 10.00 Q 495.29, 10.30, 505.41, 10.12 Q 515.53,\
            9.86, 525.65, 10.03 Q 535.76, 10.23, 545.88, 10.20 Q 556.00, 10.30, 566.12, 10.43 Q 576.24, 10.80, 586.35, 10.73 Q 596.47,\
            10.24, 606.59, 10.55 Q 616.71, 10.53, 626.82, 10.81 Q 636.94, 11.08, 647.06, 10.31 Q 657.18, 10.55, 667.29, 10.15 Q 677.41,\
            10.02, 687.53, 9.34 Q 697.65, 10.69, 707.77, 11.02 Q 717.88, 12.03, 728.00, 11.81 Q 738.12, 12.27, 748.24, 12.01 Q 758.35,\
            11.57, 768.47, 11.13 Q 778.59, 10.53, 788.71, 11.20 Q 798.82, 10.58, 808.94, 12.07 Q 819.06, 11.49, 829.18, 10.09 Q 839.29,\
            9.41, 849.41, 9.40 Q 859.53, 9.93, 869.65, 9.73 Q 879.77, 10.38, 889.88, 10.37 Q 900.00, 10.64, 910.12, 10.61 Q 920.24, 10.82,\
            930.35, 9.98 Q 940.47, 9.89, 950.59, 9.80 Q 960.71, 9.62, 970.82, 9.74 Q 980.94, 10.08, 991.06, 9.87 Q 1001.18, 10.18, 1011.30,\
            10.03 Q 1021.41, 10.14, 1031.53, 10.49 Q 1041.65, 10.53, 1051.77, 10.39 Q 1061.88, 9.97, 1072.00, 10.02 Q 1082.12, 10.03,\
            1092.24, 9.98 Q 1102.35, 9.92, 1112.47, 10.37 Q 1122.59, 10.40, 1132.71, 10.27 Q 1142.83, 10.83, 1152.94, 10.03 Q 1163.06,\
            10.72, 1173.18, 10.47 Q 1183.30, 10.82, 1193.41, 11.13 Q 1203.53, 10.88, 1213.65, 10.90 Q 1223.77, 11.48, 1233.88, 11.42 Q\
            1244.00, 10.77, 1254.12, 10.59 Q 1264.24, 9.78, 1274.35, 11.45 Q 1284.47, 10.55, 1294.59, 10.27 Q 1304.71, 10.15, 1314.83,\
            10.04 Q 1324.94, 9.79, 1335.06, 9.08 Q 1345.18, 10.61, 1355.30, 11.29 Q 1365.41, 11.64, 1375.53, 11.00 Q 1385.65, 10.65, 1395.77,\
            11.92 Q 1405.88, 11.58, 1415.93, 11.07 Q 1416.14, 21.12, 1415.19, 31.46 Q 1416.05, 41.51, 1415.88, 51.69 Q 1416.22, 61.85,\
            1415.65, 72.03 Q 1416.28, 82.20, 1416.14, 92.37 Q 1416.76, 102.54, 1417.07, 112.71 Q 1416.32, 122.88, 1415.45, 133.05 Q 1415.94,\
            143.22, 1416.62, 153.39 Q 1416.74, 163.57, 1414.99, 173.74 Q 1415.34, 183.91, 1415.76, 194.08 Q 1417.29, 204.25, 1417.21,\
            214.42 Q 1416.36, 224.59, 1417.62, 234.76 Q 1417.90, 244.93, 1417.63, 255.11 Q 1417.62, 265.28, 1417.49, 275.45 Q 1417.64,\
            285.62, 1417.73, 295.79 Q 1416.70, 305.96, 1416.30, 316.13 Q 1415.92, 326.30, 1415.50, 336.47 Q 1416.66, 346.64, 1416.05,\
            356.82 Q 1416.33, 366.99, 1416.43, 377.16 Q 1416.97, 387.33, 1416.45, 397.50 Q 1417.02, 407.67, 1417.25, 417.84 Q 1417.33,\
            428.01, 1417.52, 438.18 Q 1417.70, 448.36, 1417.67, 458.53 Q 1417.02, 468.70, 1417.24, 478.87 Q 1417.42, 489.04, 1417.32,\
            499.21 Q 1416.46, 509.38, 1417.05, 519.55 Q 1417.41, 529.72, 1417.52, 539.89 Q 1417.49, 550.07, 1417.03, 560.24 Q 1416.39,\
            570.41, 1416.81, 580.58 Q 1417.01, 590.75, 1416.67, 600.92 Q 1416.39, 611.09, 1416.52, 621.26 Q 1415.96, 631.43, 1416.25,\
            641.61 Q 1415.92, 651.78, 1415.94, 661.95 Q 1415.83, 672.12, 1416.51, 682.29 Q 1416.60, 692.46, 1416.87, 702.63 Q 1416.67,\
            712.80, 1416.76, 722.97 Q 1417.03, 733.15, 1416.91, 743.32 Q 1417.12, 753.49, 1417.59, 763.66 Q 1417.31, 773.83, 1416.70,\
            784.70 Q 1406.29, 785.20, 1396.00, 785.63 Q 1385.78, 785.89, 1375.58, 785.63 Q 1365.43, 785.20, 1355.30, 784.90 Q 1345.18,\
            784.95, 1335.06, 784.94 Q 1324.94, 784.76, 1314.83, 784.05 Q 1304.71, 783.99, 1294.59, 784.75 Q 1284.47, 784.73, 1274.35,\
            784.43 Q 1264.24, 783.38, 1254.12, 783.06 Q 1244.00, 784.08, 1233.88, 783.47 Q 1223.77, 783.67, 1213.65, 783.63 Q 1203.53,\
            783.16, 1193.41, 783.23 Q 1183.30, 783.42, 1173.18, 783.83 Q 1163.06, 783.94, 1152.94, 784.35 Q 1142.83, 783.29, 1132.71,\
            783.36 Q 1122.59, 783.60, 1112.47, 784.99 Q 1102.35, 784.10, 1092.24, 783.07 Q 1082.12, 784.66, 1072.00, 784.69 Q 1061.88,\
            785.36, 1051.77, 785.15 Q 1041.65, 784.76, 1031.53, 784.89 Q 1021.41, 784.69, 1011.30, 784.67 Q 1001.18, 784.58, 991.06, 785.02\
            Q 980.94, 785.29, 970.82, 785.80 Q 960.71, 785.14, 950.59, 784.37 Q 940.47, 783.79, 930.35, 784.67 Q 920.24, 784.95, 910.12,\
            783.89 Q 900.00, 783.26, 889.88, 783.76 Q 879.77, 784.53, 869.65, 784.40 Q 859.53, 783.79, 849.41, 783.50 Q 839.29, 783.98,\
            829.18, 783.40 Q 819.06, 783.68, 808.94, 784.18 Q 798.82, 784.21, 788.71, 784.41 Q 778.59, 783.41, 768.47, 783.66 Q 758.35,\
            784.86, 748.24, 785.27 Q 738.12, 785.36, 728.00, 785.00 Q 717.88, 784.94, 707.77, 785.44 Q 697.65, 784.67, 687.53, 784.43\
            Q 677.41, 783.82, 667.29, 784.51 Q 657.18, 785.37, 647.06, 784.94 Q 636.94, 785.03, 626.82, 785.50 Q 616.71, 785.78, 606.59,\
            785.95 Q 596.47, 785.76, 586.35, 785.17 Q 576.24, 784.60, 566.12, 784.58 Q 556.00, 784.38, 545.88, 784.15 Q 535.76, 783.79,\
            525.65, 784.46 Q 515.53, 784.43, 505.41, 784.59 Q 495.29, 783.80, 485.18, 782.45 Q 475.06, 783.67, 464.94, 782.79 Q 454.82,\
            783.90, 444.71, 783.16 Q 434.59, 784.18, 424.47, 785.34 Q 414.35, 785.53, 404.24, 785.55 Q 394.12, 785.59, 384.00, 784.26\
            Q 373.88, 785.41, 363.76, 785.23 Q 353.65, 785.79, 343.53, 785.64 Q 333.41, 785.02, 323.29, 785.31 Q 313.18, 785.40, 303.06,\
            785.05 Q 292.94, 786.02, 282.82, 785.94 Q 272.71, 786.11, 262.59, 786.23 Q 252.47, 786.38, 242.35, 786.42 Q 232.24, 785.52,\
            222.12, 784.78 Q 212.00, 785.85, 201.88, 784.45 Q 191.76, 785.71, 181.65, 784.97 Q 171.53, 783.50, 161.41, 783.76 Q 151.29,\
            784.50, 141.18, 784.59 Q 131.06, 783.83, 120.94, 784.08 Q 110.82, 784.35, 100.71, 784.61 Q 90.59, 784.77, 80.47, 784.43 Q\
            70.35, 784.77, 60.24, 785.01 Q 50.12, 784.63, 39.81, 784.19 Q 39.32, 774.06, 38.78, 763.83 Q 38.34, 753.60, 38.19, 743.37\
            Q 38.14, 733.17, 38.14, 722.99 Q 38.37, 712.81, 38.23, 702.64 Q 38.09, 692.46, 37.90, 682.29 Q 38.06, 672.12, 37.97, 661.95\
            Q 38.93, 651.78, 39.14, 641.61 Q 38.74, 631.43, 38.81, 621.26 Q 38.89, 611.09, 39.08, 600.92 Q 39.34, 590.75, 38.81, 580.58\
            Q 39.17, 570.41, 39.83, 560.24 Q 39.62, 550.07, 38.90, 539.89 Q 38.40, 529.72, 38.33, 519.55 Q 38.78, 509.38, 38.65, 499.21\
            Q 38.61, 489.04, 38.38, 478.87 Q 38.26, 468.70, 39.27, 458.53 Q 39.15, 448.36, 39.23, 438.18 Q 39.09, 428.01, 38.91, 417.84\
            Q 39.21, 407.67, 38.85, 397.50 Q 38.48, 387.33, 38.85, 377.16 Q 38.30, 366.99, 38.73, 356.82 Q 38.48, 346.64, 38.48, 336.47\
            Q 39.47, 326.30, 39.27, 316.13 Q 39.87, 305.96, 39.77, 295.79 Q 39.47, 285.62, 40.17, 275.45 Q 39.80, 265.28, 39.91, 255.11\
            Q 40.57, 244.93, 40.39, 234.76 Q 39.67, 224.59, 39.98, 214.42 Q 39.18, 204.25, 39.00, 194.08 Q 39.11, 183.91, 38.67, 173.74\
            Q 39.26, 163.57, 39.39, 153.39 Q 39.68, 143.22, 39.03, 133.05 Q 38.86, 122.88, 38.35, 112.71 Q 38.19, 102.54, 38.12, 92.37\
            Q 38.29, 82.20, 38.38, 72.03 Q 38.57, 61.86, 38.41, 51.68 Q 38.02, 41.51, 38.41, 31.34 Q 40.00, 21.17, 40.00, 11.00" style="\
            fill:white;"/>\
         </svg:svg>\
      </div>\
   </div>\
</div>');