rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__523657174-layer" class="layer" name="__containerId__pageLayer" data-layer-id="523657174" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-523657174-layer-1351386262" style="position: absolute; left: 0px; top: 0px; width: 1375px; height: 820px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1351386262" data-review-reference-id="1351386262">\
            <div class="stencil-wrapper" style="width: 1375px; height: 820px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 820px;width:1375px;" width="1375" height="820">\
                     <svg:g width="1375" height="820"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.08, 0.23, 22.16, -0.13 Q 32.24, -0.27, 42.32, -0.30\
                        Q 52.40, -0.31, 62.49, -0.07 Q 72.57, -0.23, 82.65, -0.19 Q 92.73, -0.13, 102.81, -0.36 Q 112.89, 0.32, 122.97, 0.29 Q 133.05,\
                        0.37, 143.13, 0.24 Q 153.21, 0.21, 163.29, 0.35 Q 173.38, 0.93, 183.46, 0.68 Q 193.54, 0.62, 203.62, 0.39 Q 213.70, 0.11,\
                        223.78, 1.04 Q 233.86, 0.61, 243.94, 1.02 Q 254.02, 1.12, 264.10, 1.33 Q 274.18, 1.50, 284.26, 1.39 Q 294.35, 1.03, 304.43,\
                        0.97 Q 314.51, 1.07, 324.59, 0.98 Q 334.67, 1.85, 344.75, 1.61 Q 354.83, 1.83, 364.91, 1.89 Q 374.99, 1.98, 385.07, 1.81 Q\
                        395.15, 0.97, 405.24, 1.19 Q 415.32, 0.85, 425.40, 1.02 Q 435.48, 1.61, 445.56, 1.99 Q 455.64, 1.43, 465.72, 0.74 Q 475.80,\
                        0.72, 485.88, 1.17 Q 495.96, 1.75, 506.04, 1.44 Q 516.12, 1.42, 526.21, 1.86 Q 536.29, 2.35, 546.37, 1.66 Q 556.45, 1.67,\
                        566.53, 1.78 Q 576.61, 1.38, 586.69, 1.86 Q 596.77, 1.63, 606.85, 1.65 Q 616.93, 1.91, 627.01, 1.46 Q 637.10, 0.70, 647.18,\
                        1.16 Q 657.26, 2.25, 667.34, 2.53 Q 677.42, 3.24, 687.50, 2.87 Q 697.58, 3.51, 707.66, 2.95 Q 717.74, 3.08, 727.82, 2.40 Q\
                        737.90, 2.20, 747.98, 2.92 Q 758.07, 2.77, 768.15, 3.04 Q 778.23, 1.83, 788.31, 1.42 Q 798.39, 1.51, 808.47, 1.60 Q 818.55,\
                        1.31, 828.63, 1.04 Q 838.71, 1.51, 848.79, 1.39 Q 858.87, 1.65, 868.96, 1.81 Q 879.04, 1.75, 889.12, 0.90 Q 899.20, 0.72,\
                        909.28, 0.69 Q 919.36, 0.56, 929.44, 0.89 Q 939.52, 0.94, 949.60, 0.91 Q 959.68, 1.44, 969.76, 0.92 Q 979.84, 1.61, 989.93,\
                        1.80 Q 1000.01, 1.41, 1010.09, 1.32 Q 1020.17, 1.03, 1030.25, 1.12 Q 1040.33, 1.12, 1050.41, 1.59 Q 1060.49, 1.57, 1070.57,\
                        2.32 Q 1080.65, 1.65, 1090.73, 1.66 Q 1100.82, 1.39, 1110.90, 1.70 Q 1120.98, 1.92, 1131.06, 1.68 Q 1141.14, 2.13, 1151.22,\
                        1.86 Q 1161.30, 1.87, 1171.38, 2.27 Q 1181.46, 2.25, 1191.54, 2.05 Q 1201.63, 1.65, 1211.71, 1.87 Q 1221.79, 2.12, 1231.87,\
                        2.35 Q 1241.95, 1.09, 1252.03, 1.66 Q 1262.11, 0.98, 1272.19, 0.64 Q 1282.27, 0.42, 1292.35, 1.00 Q 1302.43, 2.18, 1312.52,\
                        1.46 Q 1322.60, 1.78, 1332.68, 1.74 Q 1342.76, 2.41, 1352.84, 2.94 Q 1362.92, 1.76, 1372.93, 2.07 Q 1372.03, 12.52, 1372.01,\
                        22.54 Q 1373.27, 32.58, 1372.71, 42.81 Q 1373.36, 52.99, 1372.69, 63.20 Q 1373.12, 73.40, 1372.51, 83.60 Q 1372.81, 93.80,\
                        1373.03, 104.00 Q 1372.22, 114.20, 1372.60, 124.40 Q 1373.64, 134.60, 1373.53, 144.80 Q 1372.50, 155.00, 1371.78, 165.20 Q\
                        1372.55, 175.40, 1372.86, 185.60 Q 1373.97, 195.80, 1373.75, 206.00 Q 1374.11, 216.20, 1374.31, 226.40 Q 1374.55, 236.60,\
                        1374.48, 246.80 Q 1374.33, 257.00, 1374.28, 267.20 Q 1374.40, 277.40, 1374.02, 287.60 Q 1373.62, 297.80, 1373.19, 308.00 Q\
                        1373.31, 318.20, 1373.70, 328.40 Q 1372.96, 338.60, 1373.52, 348.80 Q 1373.42, 359.00, 1373.39, 369.20 Q 1373.21, 379.40,\
                        1373.58, 389.60 Q 1374.21, 399.80, 1374.39, 410.00 Q 1374.44, 420.20, 1374.59, 430.40 Q 1374.59, 440.60, 1374.44, 450.80 Q\
                        1374.30, 461.00, 1374.31, 471.20 Q 1374.17, 481.40, 1374.17, 491.60 Q 1374.67, 501.80, 1374.26, 512.00 Q 1374.37, 522.20,\
                        1374.27, 532.40 Q 1373.75, 542.60, 1373.19, 552.80 Q 1373.60, 563.00, 1373.91, 573.20 Q 1373.51, 583.40, 1373.11, 593.60 Q\
                        1372.61, 603.80, 1372.84, 614.00 Q 1372.94, 624.20, 1373.12, 634.40 Q 1372.70, 644.60, 1372.71, 654.80 Q 1373.25, 665.00,\
                        1373.27, 675.20 Q 1372.99, 685.40, 1373.26, 695.60 Q 1373.50, 705.80, 1373.69, 716.00 Q 1373.47, 726.20, 1373.58, 736.40 Q\
                        1374.20, 746.60, 1374.57, 756.80 Q 1373.91, 767.00, 1373.68, 777.20 Q 1374.22, 787.40, 1374.81, 797.60 Q 1374.84, 807.80,\
                        1373.47, 818.47 Q 1363.04, 818.37, 1352.96, 818.88 Q 1342.81, 818.84, 1332.70, 818.62 Q 1322.60, 818.36, 1312.52, 818.73 Q\
                        1302.44, 818.73, 1292.35, 818.68 Q 1282.27, 817.69, 1272.19, 817.47 Q 1262.11, 817.25, 1252.03, 817.88 Q 1241.95, 818.28,\
                        1231.87, 818.02 Q 1221.79, 817.49, 1211.71, 817.04 Q 1201.63, 816.96, 1191.54, 816.99 Q 1181.46, 816.79, 1171.38, 817.25 Q\
                        1161.30, 817.85, 1151.22, 817.87 Q 1141.14, 817.53, 1131.06, 817.64 Q 1120.98, 818.17, 1110.90, 818.14 Q 1100.82, 818.35,\
                        1090.73, 817.69 Q 1080.65, 818.77, 1070.57, 819.34 Q 1060.49, 818.58, 1050.41, 818.33 Q 1040.33, 818.46, 1030.25, 818.40 Q\
                        1020.17, 818.49, 1010.09, 819.32 Q 1000.01, 818.68, 989.93, 819.04 Q 979.84, 819.48, 969.76, 818.98 Q 959.68, 818.41, 949.60,\
                        818.47 Q 939.52, 818.48, 929.44, 819.28 Q 919.36, 819.30, 909.28, 817.97 Q 899.20, 817.99, 889.12, 818.33 Q 879.04, 818.44,\
                        868.96, 818.24 Q 858.87, 817.93, 848.79, 817.71 Q 838.71, 817.82, 828.63, 817.70 Q 818.55, 817.06, 808.47, 817.57 Q 798.39,\
                        817.18, 788.31, 817.13 Q 778.23, 817.30, 768.15, 818.18 Q 758.07, 819.24, 747.98, 819.43 Q 737.90, 818.80, 727.82, 818.11\
                        Q 717.74, 818.99, 707.66, 819.14 Q 697.58, 818.71, 687.50, 818.50 Q 677.42, 818.66, 667.34, 818.99 Q 657.26, 818.94, 647.18,\
                        818.70 Q 637.10, 819.25, 627.01, 819.54 Q 616.93, 819.67, 606.85, 819.77 Q 596.77, 818.97, 586.69, 818.39 Q 576.61, 818.06,\
                        566.53, 818.54 Q 556.45, 818.97, 546.37, 818.62 Q 536.29, 818.42, 526.21, 818.63 Q 516.12, 818.08, 506.04, 817.95 Q 495.96,\
                        817.75, 485.88, 816.95 Q 475.80, 817.70, 465.72, 817.25 Q 455.64, 817.17, 445.56, 817.08 Q 435.48, 819.33, 425.40, 819.52\
                        Q 415.32, 819.38, 405.24, 819.56 Q 395.15, 819.02, 385.07, 819.45 Q 374.99, 820.15, 364.91, 819.56 Q 354.83, 819.72, 344.75,\
                        819.61 Q 334.67, 819.10, 324.59, 819.44 Q 314.51, 819.45, 304.43, 819.53 Q 294.35, 819.86, 284.26, 820.02 Q 274.18, 820.13,\
                        264.10, 820.31 Q 254.02, 820.36, 243.94, 819.88 Q 233.86, 818.45, 223.78, 819.37 Q 213.70, 818.75, 203.62, 818.50 Q 193.54,\
                        818.83, 183.46, 818.63 Q 173.38, 819.37, 163.29, 819.04 Q 153.21, 817.85, 143.13, 817.67 Q 133.05, 818.21, 122.97, 818.76\
                        Q 112.89, 818.64, 102.81, 818.56 Q 92.73, 818.59, 82.65, 818.12 Q 72.57, 818.00, 62.49, 817.92 Q 52.40, 818.15, 42.32, 818.58\
                        Q 32.24, 819.22, 22.16, 819.71 Q 12.08, 819.78, 1.04, 818.96 Q 0.62, 808.26, 0.61, 797.80 Q 0.31, 787.51, 0.21, 777.26 Q 0.07,\
                        767.03, 0.02, 756.82 Q 0.24, 746.61, 0.31, 736.40 Q 1.30, 726.20, 0.88, 716.00 Q 0.94, 705.80, 1.03, 695.60 Q 1.35, 685.40,\
                        1.44, 675.20 Q 1.62, 665.00, 1.19, 654.80 Q 0.42, 644.60, -0.17, 634.40 Q 0.40, 624.20, 0.92, 614.00 Q 0.75, 603.80, 1.40,\
                        593.60 Q 0.54, 583.40, 0.39, 573.20 Q 0.27, 563.00, 0.21, 552.80 Q 0.21, 542.60, 1.01, 532.40 Q 1.02, 522.20, 0.91, 512.00\
                        Q 0.82, 501.80, 0.81, 491.60 Q 0.78, 481.40, 0.58, 471.20 Q 0.93, 461.00, 0.91, 450.80 Q 0.77, 440.60, 1.22, 430.40 Q 0.87,\
                        420.20, 1.21, 410.00 Q 1.26, 399.80, 1.49, 389.60 Q 2.15, 379.40, 1.64, 369.20 Q 2.42, 359.00, 1.85, 348.80 Q 2.02, 338.60,\
                        2.26, 328.40 Q 2.16, 318.20, 1.83, 308.00 Q 1.88, 297.80, 1.85, 287.60 Q 1.87, 277.40, 2.54, 267.20 Q 1.41, 257.00, 1.91,\
                        246.80 Q 1.66, 236.60, 1.04, 226.40 Q 0.88, 216.20, 0.64, 206.00 Q 0.76, 195.80, 0.69, 185.60 Q 0.79, 175.40, 0.69, 165.20\
                        Q 0.70, 155.00, 0.56, 144.80 Q 0.47, 134.60, 0.15, 124.40 Q 0.80, 114.20, 0.79, 104.00 Q 0.95, 93.80, 1.13, 83.60 Q 1.09,\
                        73.40, 0.25, 63.20 Q 0.08, 53.00, 0.00, 42.80 Q 0.02, 32.60, -0.00, 22.40 Q 2.00, 12.20, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 10.62, 7.26, 19.67, 11.80 Q 28.69, 16.39, 37.53, 21.29 Q 46.23,\
                        26.40, 54.71, 31.91 Q 63.46, 36.94, 72.16, 42.06 Q 80.93, 47.07, 89.65, 52.17 Q 98.31, 57.36, 106.83, 62.80 Q 115.55, 67.89,\
                        124.33, 72.88 Q 133.04, 77.98, 141.52, 83.47 Q 150.22, 88.61, 158.96, 93.67 Q 167.71, 98.71, 176.45, 103.77 Q 185.09, 109.00,\
                        193.53, 114.55 Q 202.10, 119.90, 210.73, 125.15 Q 219.46, 130.23, 228.06, 135.53 Q 236.93, 140.36, 245.75, 145.28 Q 254.37,\
                        150.54, 262.91, 155.94 Q 271.36, 161.48, 280.07, 166.60 Q 288.74, 171.78, 297.48, 176.82 Q 306.24, 181.86, 314.90, 187.06\
                        Q 323.66, 192.07, 332.46, 197.03 Q 340.92, 202.56, 349.54, 207.82 Q 358.30, 212.84, 366.84, 218.25 Q 375.30, 223.77, 384.29,\
                        228.42 Q 393.09, 233.37, 401.85, 238.40 Q 410.40, 243.78, 419.13, 248.84 Q 427.59, 254.38, 436.32, 259.45 Q 444.93, 264.73,\
                        453.75, 269.65 Q 462.62, 274.49, 471.63, 279.10 Q 480.28, 284.32, 489.10, 289.24 Q 497.20, 295.37, 506.05, 300.25 Q 514.31,\
                        306.11, 523.15, 311.00 Q 531.64, 316.48, 540.57, 321.23 Q 549.48, 325.99, 558.06, 331.32 Q 566.41, 337.04, 575.12, 342.16\
                        Q 583.56, 347.72, 592.59, 352.28 Q 601.36, 357.29, 610.11, 362.33 Q 618.84, 367.42, 627.48, 372.64 Q 635.78, 378.44, 644.64,\
                        383.29 Q 653.18, 388.69, 662.40, 392.94 Q 670.59, 398.93, 679.42, 403.83 Q 687.90, 409.33, 696.58, 414.50 Q 705.15, 419.83,\
                        713.82, 425.01 Q 722.86, 429.57, 731.42, 434.93 Q 740.09, 440.11, 748.26, 446.12 Q 756.99, 451.20, 765.86, 456.04 Q 774.48,\
                        461.29, 783.36, 466.12 Q 792.15, 471.10, 800.91, 476.12 Q 808.78, 482.64, 817.97, 486.95 Q 826.42, 492.50, 835.44, 497.08\
                        Q 843.75, 502.86, 852.37, 508.13 Q 861.26, 512.93, 869.88, 518.19 Q 878.52, 523.42, 886.87, 529.13 Q 896.14, 533.30, 904.56,\
                        538.90 Q 913.33, 543.90, 922.24, 548.68 Q 931.18, 553.41, 940.00, 558.32 Q 948.26, 564.19, 957.14, 569.02 Q 965.81, 574.19,\
                        974.75, 578.91 Q 982.80, 585.13, 991.40, 590.43 Q 1000.12, 595.52, 1009.04, 600.28 Q 1017.49, 605.82, 1025.77, 611.66 Q 1034.16,\
                        617.30, 1043.16, 621.93 Q 1052.10, 626.65, 1060.28, 632.65 Q 1069.14, 637.51, 1077.99, 642.39 Q 1086.84, 647.26, 1095.56,\
                        652.35 Q 1104.62, 656.88, 1113.26, 662.09 Q 1122.12, 666.95, 1130.05, 673.38 Q 1138.79, 678.43, 1147.72, 683.17 Q 1155.96,\
                        689.07, 1164.72, 694.09 Q 1173.81, 698.58, 1182.58, 703.58 Q 1191.35, 708.59, 1200.07, 713.68 Q 1208.59, 719.11, 1217.41,\
                        724.04 Q 1226.10, 729.17, 1234.93, 734.09 Q 1243.50, 739.42, 1252.12, 744.68 Q 1260.64, 750.12, 1268.66, 756.39 Q 1278.32,\
                        759.90, 1286.31, 766.22 Q 1295.35, 770.77, 1303.92, 776.11 Q 1313.03, 780.55, 1321.76, 785.64 Q 1330.09, 791.37, 1338.71,\
                        796.65 Q 1346.92, 802.59, 1355.81, 807.41 Q 1364.33, 812.83, 1373.00, 818.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 818.00 Q 9.52, 810.87, 18.13, 805.57 Q 26.80, 800.37, 35.62, 795.43 Q\
                        44.28, 790.20, 52.98, 785.07 Q 61.86, 780.22, 70.56, 775.07 Q 79.55, 770.40, 88.05, 764.92 Q 96.82, 759.90, 105.40, 754.54\
                        Q 114.16, 749.50, 123.17, 744.87 Q 131.80, 739.61, 140.71, 734.82 Q 149.65, 730.08, 158.35, 724.92 Q 167.03, 719.75, 175.44,\
                        714.11 Q 184.26, 709.15, 192.88, 703.88 Q 201.39, 698.41, 210.11, 693.30 Q 218.87, 688.25, 227.42, 682.84 Q 236.51, 678.36,\
                        245.06, 672.96 Q 253.87, 668.00, 262.20, 662.23 Q 270.93, 657.14, 279.94, 652.50 Q 288.37, 646.90, 297.65, 642.74 Q 306.18,\
                        637.29, 314.84, 632.08 Q 323.91, 627.56, 332.35, 621.98 Q 340.92, 616.60, 349.49, 611.24 Q 357.98, 605.74, 367.08, 601.26\
                        Q 375.73, 596.03, 384.12, 590.37 Q 392.98, 585.48, 401.20, 579.52 Q 410.47, 575.33, 418.92, 569.77 Q 427.52, 564.47, 436.15,\
                        559.19 Q 444.57, 553.57, 453.58, 548.95 Q 462.37, 543.95, 471.34, 539.27 Q 480.21, 534.40, 488.55, 528.64 Q 497.15, 523.34,\
                        506.14, 518.67 Q 514.77, 513.40, 523.36, 508.07 Q 531.73, 502.37, 540.53, 497.39 Q 549.99, 493.52, 558.25, 487.63 Q 566.70,\
                        482.07, 575.12, 476.45 Q 584.08, 471.73, 593.08, 467.09 Q 601.71, 461.83, 610.06, 456.09 Q 618.72, 450.87, 627.11, 445.21\
                        Q 635.92, 440.25, 644.78, 435.37 Q 653.53, 430.30, 662.16, 425.04 Q 670.64, 419.52, 679.64, 414.87 Q 688.67, 410.28, 696.97,\
                        404.47 Q 705.65, 399.28, 713.96, 393.48 Q 722.86, 388.67, 731.62, 383.62 Q 740.19, 378.25, 748.95, 373.21 Q 757.55, 367.89,\
                        766.14, 362.56 Q 775.07, 357.80, 784.00, 353.04 Q 792.59, 347.72, 800.73, 341.62 Q 809.60, 336.76, 819.01, 332.80 Q 827.71,\
                        327.65, 836.13, 322.04 Q 844.47, 316.28, 853.60, 311.86 Q 861.97, 306.15, 870.68, 301.03 Q 879.12, 295.44, 887.60, 289.92\
                        Q 896.28, 284.74, 905.45, 280.39 Q 914.53, 275.88, 923.09, 270.50 Q 932.00, 265.70, 940.59, 260.36 Q 949.25, 255.15, 957.86,\
                        249.85 Q 966.23, 244.15, 974.95, 239.04 Q 983.72, 234.00, 992.47, 228.94 Q 1001.22, 223.88, 1009.95, 218.79 Q 1018.74, 213.79,\
                        1027.35, 208.49 Q 1036.24, 203.66, 1044.80, 198.28 Q 1053.05, 192.37, 1061.93, 187.53 Q 1070.94, 182.91, 1079.47, 177.47 Q\
                        1088.49, 172.86, 1097.63, 168.45 Q 1105.96, 162.68, 1113.97, 156.38 Q 1122.52, 150.97, 1131.11, 145.65 Q 1139.82, 140.51,\
                        1148.18, 134.79 Q 1156.95, 129.76, 1165.68, 124.66 Q 1174.53, 119.77, 1183.40, 114.91 Q 1192.07, 109.72, 1200.69, 104.43 Q\
                        1209.17, 98.92, 1217.99, 93.97 Q 1227.00, 89.35, 1236.02, 84.73 Q 1244.27, 78.83, 1252.61, 73.07 Q 1261.52, 68.27, 1269.89,\
                        62.57 Q 1279.19, 58.44, 1287.76, 53.07 Q 1296.38, 47.80, 1305.53, 43.40 Q 1314.15, 38.12, 1322.45, 32.29 Q 1330.76, 26.49,\
                        1339.45, 21.34 Q 1348.18, 16.24, 1357.18, 11.58 Q 1366.31, 7.17, 1375.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-690043766" style="position: absolute; left: 170px; top: 0px; width: 970px; height: 120px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="690043766" data-review-reference-id="690043766">\
            <div class="stencil-wrapper" style="width: 970px; height: 120px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 120px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 120px;width:970px;" width="970" height="120" viewBox="0 0 970 120">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="120" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-1004935317" style="position: absolute; left: 455px; top: 15px; width: 410px; height: 48px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1004935317" data-review-reference-id="1004935317">\
            <div class="stencil-wrapper" style="width: 410px; height: 48px">\
               <div title="" style="width:415px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 42px;">MONDAY MORNING</span> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-658215250" style="position: absolute; left: 295px; top: 85px; width: 731px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="658215250" data-review-reference-id="658215250">\
            <div class="stencil-wrapper" style="width: 731px; height: 37px">\
               <div title="" style="width:736px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">THE OFFICIAL MEDIA BODY OF NIT ROURKELA</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-1838347723" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1838347723" data-review-reference-id="1838347723">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e191" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e191</title>\
<path class="path1" d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM277.357 531.417q0 6.99 4.926 11.756t11.915 4.846h150.92v152.907q0 6.911 4.846 11.915t11.756 4.926h100.559q6.99 0 11.915-4.926t5.004-11.915v-152.907h150.601q6.911 0 11.915-4.846t4.926-11.756v-100.559q0-6.99-4.926-11.756t-11.915-4.846h-150.601v-150.92q0-6.911-5.004-11.915t-11.915-4.926h-100.559q-6.99 0-11.756 4.926t-4.846 11.915v150.92h-150.92q-6.911 0-11.915 4.846t-4.926 11.756v100.559z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e368" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e368</title>\
<path class="path1" d="M181.008 679.716v-364.035q0-54.969 38.921-93.729t93.491-38.682h364.035q54.969 0 93.729 38.682t38.682 93.729v364.035q0 54.969-38.682 93.65t-93.729 38.762h-364.035q-54.57 0-93.491-38.762t-38.921-93.65zM247.255 712.839q0 13.583 9.77 23.273t23.273 9.77h430.281q13.583 0 23.353-9.77t9.77-23.273v-430.281q0-13.583-9.77-23.353t-23.353-9.77h-430.281q-13.502 0-23.273 9.77t-9.77 23.353v430.281zM345.513 425.852q4.291-10.883 17.554-10.883h264.745q13.264 0 17.554 11.36t-3.972 22.4l-126.375 175.384q-7.944 10.961-19.539 11.756t-19.539-10.089l-126.455-178.086q-8.262-10.883-3.972-21.844z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path class="path1" d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e046" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e046</title>\
<path class="path1" d="M114.842 845.172v-529.492h761.193v529.492q0 13.583-9.77 23.353t-23.273 9.77h-695.028q-13.583 0-23.353-9.77t-9.77-23.353zM114.842 282.557v-99.289q0-13.583 9.77-23.353t23.353-9.77h66.167v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.044q13.583 0 23.353 9.77t9.77 23.353v33.044h364.035v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.124q13.583 0 23.273 9.77t9.77 23.353v33.044h66.246q13.583 0 23.273 9.77t9.77 23.353v99.289h-761.193zM181.008 812.128h99.289v-99.289h-99.289v99.289zM181.008 679.716h99.289v-99.289h-99.289v99.289zM181.008 547.303h99.289v-99.289h-99.289v99.289zM313.421 812.128h99.289v-99.289h-99.289v99.289zM313.421 679.716h99.289v-99.289h-99.289v99.289zM313.421 547.303h99.289v-99.289h-99.289v99.289zM445.833 812.128h99.289v-99.289h-99.289v99.289zM445.833 679.716h99.289v-99.289h-99.289v99.289zM445.833 547.303h99.289v-99.289h-99.289v99.289zM578.167 812.128h99.289v-99.289h-99.289v99.289zM578.167 679.716h99.289v-99.289h-99.289v99.289zM578.167 547.303h99.289v-99.289h-99.289v99.289zM710.579 812.128h99.289v-99.289h-99.289v99.289zM710.579 679.716h99.289v-99.289h-99.289v99.289zM710.579 547.303h99.289v-99.289h-99.289v99.289z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e212" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e212</title>\
<path class="path1" d="M181.008 563.586v-164.821q0-6.674 5.163-11.756t11.756-5.163h280.95v-171.413q0-6.99 3.972-8.817t9.294 2.463l345.208 266.812q5.639 4.291 5.639 10.247t-5.639 10.247l-344.893 267.129q-5.639 3.972-9.612 2.145t-3.972-8.817v-171.413h-280.95q-6.592 0-11.756-5.164t-5.163-11.677z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-1669834058" style="position: absolute; left: 170px; top: 120px; width: 970px; height: 60px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1669834058" data-review-reference-id="1669834058">\
            <div class="stencil-wrapper" style="width: 970px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 60px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 60px;width:970px;" width="970" height="60" viewBox="0 0 970 60">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="60" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-131780468" style="position: absolute; left: 240px; top: 135px; width: 52px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="131780468" data-review-reference-id="131780468">\
            <div class="stencil-wrapper" style="width: 52px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:56px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="56" height="34" viewBox="-2 -2 56 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 3.12, 28.25, 1.83, 28.17 Q 0.98, 27.37, -0.09, 26.34 Q 0.16,\
                        14.12, 0.78, 1.96 Q 1.23, 0.91, 1.78, -0.19 Q 2.31, -1.41, 3.76, -1.74 Q 15.28, -2.48, 26.96, -1.57 Q 38.46, -2.13, 50.02,\
                        -1.11 Q 51.05, -0.64, 52.32, -0.35 Q 52.73, 0.83, 53.76, 1.75 Q 53.24, 13.96, 53.65, 26.11 Q 53.52, 27.34, 53.19, 29.06 Q\
                        51.56, 29.24, 50.08, 29.25 Q 38.47, 28.78, 27.01, 29.09 Q 15.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="26" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Home</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-1564079099" style="position: absolute; left: 340px; top: 135px; width: 550px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1564079099" data-review-reference-id="1564079099">\
            <div class="stencil-wrapper" style="width: 550px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:550px;" width="550" height="30">\
                     <svg:g id="__containerId__-523657174-layer-1564079099svg" width="550" height="30"><svg:path id="__containerId__-523657174-layer-1564079099_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00\
                        Q 12.11, 1.96, 22.22, 2.89 Q 32.33, 3.29, 42.44, 3.19 Q 52.56, 3.66, 62.67, 2.74 Q 72.78, 2.96, 82.89, 2.46 Q 93.00, 3.05,\
                        103.11, 3.14 Q 113.22, 1.50, 123.33, 1.84 Q 133.44, 2.91, 143.56, 3.01 Q 153.67, 2.24, 163.78, 1.98 Q 173.89, 1.98, 184.00,\
                        2.67 Q 194.11, 2.15, 204.22, 3.05 Q 214.33, 2.21, 224.44, 0.92 Q 234.56, 0.98, 244.67, 1.44 Q 254.78, 2.43, 264.89, 2.39 Q\
                        275.00, 1.57, 285.11, 1.67 Q 295.22, 1.41, 305.33, 2.82 Q 315.44, 3.01, 325.56, 2.39 Q 335.67, 1.55, 345.78, 2.15 Q 355.89,\
                        2.47, 366.00, 2.73 Q 376.11, 1.24, 386.22, 2.86 Q 396.33, 3.11, 406.44, 3.63 Q 416.56, 3.55, 426.67, 1.89 Q 436.78, 1.51,\
                        446.89, 0.07 Q 457.00, 0.47, 467.11, 0.21 Q 477.22, 0.69, 487.33, 1.36 Q 497.44, 2.54, 507.56, 2.83 Q 517.67, 2.32, 527.78,\
                        2.60 Q 537.89, 0.85, 548.72, 1.28 Q 549.00, 14.67, 548.44, 28.44 Q 538.14, 28.93, 527.90, 29.06 Q 517.71, 28.89, 507.55, 27.62\
                        Q 497.44, 27.69, 487.33, 27.82 Q 477.22, 28.13, 467.11, 28.64 Q 457.00, 29.17, 446.89, 28.99 Q 436.78, 28.16, 426.67, 27.71\
                        Q 416.56, 28.09, 406.44, 28.42 Q 396.33, 28.30, 386.22, 27.84 Q 376.11, 28.22, 366.00, 29.16 Q 355.89, 28.85, 345.78, 26.70\
                        Q 335.67, 25.91, 325.56, 27.40 Q 315.44, 26.88, 305.33, 27.19 Q 295.22, 26.77, 285.11, 27.49 Q 275.00, 28.97, 264.89, 29.52\
                        Q 254.78, 28.21, 244.67, 27.72 Q 234.56, 28.25, 224.44, 28.78 Q 214.33, 28.66, 204.22, 28.72 Q 194.11, 28.40, 184.00, 29.27\
                        Q 173.89, 29.28, 163.78, 28.81 Q 153.67, 29.07, 143.56, 28.31 Q 133.44, 28.21, 123.33, 28.35 Q 113.22, 28.17, 103.11, 28.66\
                        Q 93.00, 28.79, 82.89, 28.72 Q 72.78, 27.68, 62.67, 27.38 Q 52.56, 28.27, 42.44, 29.15 Q 32.33, 28.84, 22.22, 29.61 Q 12.11,\
                        29.78, 1.03, 28.97 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-523657174-layer-1564079099_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 1.29,\
                        23.15, 1.64 Q 33.22, 1.83, 43.30, 2.14 Q 53.37, 2.06, 63.44, 2.75 Q 73.52, 3.23, 83.59, 3.01 Q 93.67, 2.25, 103.74, 2.20 Q\
                        113.81, 3.19, 123.89, 3.10 Q 133.96, 2.43, 144.04, 2.84 Q 154.11, 2.10, 164.19, 2.53 Q 174.26, 2.31, 184.33, 1.92 Q 194.41,\
                        1.92, 204.48, 1.80 Q 214.56, 2.90, 224.63, 2.98 Q 234.70, 3.25, 244.78, 3.04 Q 254.85, 2.70, 264.93, 1.61 Q 275.00, 1.63,\
                        285.07, 2.35 Q 295.15, 2.34, 305.22, 1.78 Q 315.30, 1.85, 325.37, 2.37 Q 335.44, 2.39, 345.52, 1.97 Q 355.59, 2.60, 365.67,\
                        1.48 Q 375.74, 1.76, 385.81, 1.67 Q 395.89, 1.90, 405.96, 1.55 Q 416.04, 1.79, 426.11, 2.50 Q 436.18, 2.91, 446.26, 2.90 Q\
                        456.33, 3.34, 466.41, 3.30 Q 476.48, 1.97, 486.56, 2.96 Q 496.63, 2.13, 506.70, 2.40 Q 516.78, 1.85, 526.85, 2.44 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-523657174-layer-1564079099_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-523657174-layer-1564079099_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 2.31,\
                        23.15, 2.51 Q 33.22, 2.28, 43.30, 2.68 Q 53.37, 2.65, 63.44, 2.49 Q 73.52, 2.89, 83.59, 2.89 Q 93.67, 2.53, 103.74, 2.49 Q\
                        113.81, 2.53, 123.89, 2.98 Q 133.96, 2.02, 144.04, 2.66 Q 154.11, 2.25, 164.19, 2.44 Q 174.26, 2.74, 184.33, 2.98 Q 194.41,\
                        2.43, 204.48, 2.85 Q 214.56, 2.87, 224.63, 1.98 Q 234.70, 2.85, 244.78, 3.21 Q 254.85, 3.02, 264.93, 1.85 Q 275.00, 1.88,\
                        285.07, 2.40 Q 295.15, 1.88, 305.22, 1.51 Q 315.30, 1.17, 325.37, 2.53 Q 335.44, 2.36, 345.52, 2.94 Q 355.59, 2.74, 365.67,\
                        2.56 Q 375.74, 1.57, 385.81, 1.65 Q 395.89, 1.88, 405.96, 2.44 Q 416.04, 2.23, 426.11, 3.38 Q 436.18, 2.59, 446.26, 2.22 Q\
                        456.33, 2.81, 466.41, 3.28 Q 476.48, 2.98, 486.56, 2.92 Q 496.63, 2.63, 506.70, 3.01 Q 516.78, 1.98, 526.85, 1.96 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-523657174-layer-1564079099_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-523657174-layer-1564079099input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-523657174-layer-1564079099_input_svg_border\',\'__containerId__-523657174-layer-1564079099_line1\',\'__containerId__-523657174-layer-1564079099_line2\',\'__containerId__-523657174-layer-1564079099_line3\',\'__containerId__-523657174-layer-1564079099_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-523657174-layer-1564079099_input_svg_border\',\'__containerId__-523657174-layer-1564079099_line1\',\'__containerId__-523657174-layer-1564079099_line2\',\'__containerId__-523657174-layer-1564079099_line3\',\'__containerId__-523657174-layer-1564079099_line4\'))" value="Search Box" style="width:543px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-96045148" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="96045148" data-review-reference-id="96045148">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-424994570" style="position: absolute; left: 0px; top: 778px; width: 1375px; height: 40px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="424994570" data-review-reference-id="424994570">\
            <div class="stencil-wrapper" style="width: 1375px; height: 40px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 40px; width:1375px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 40px;width:1375px;" width="1375" height="40" viewBox="0 0 1375 40">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="1375" height="40" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-882974477" style="position: absolute; left: 455px; top: 783px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="882974477" data-review-reference-id="882974477">\
            <div class="stencil-wrapper" style="width: 403px; height: 20px">\
               <div title="" style="width:408px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Fixed footer for ASK A QUESTION AND FORUM </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-373472106" style="position: absolute; left: 170px; top: 180px; width: 970px; height: 600px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="373472106" data-review-reference-id="373472106">\
            <div class="stencil-wrapper" style="width: 970px; height: 600px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 600px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 600px;width:970px;" width="970" height="600" viewBox="0 0 970 600">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="600" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-text826615143" style="position: absolute; left: 590px; top: 205px; width: 187px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text826615143" data-review-reference-id="text826615143">\
            <div class="stencil-wrapper" style="width: 187px; height: 37px">\
               <div title="" style="width:192px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Admin Panel</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-group421491835" style="position: absolute; left: 280px; top: 590px; width: 816px; height: 150px" data-interactive-element-type="group" class="group stencil mobile-interaction-potential-trigger " data-stencil-id="group421491835" data-review-reference-id="group421491835">\
            <div class="stencil-wrapper" style="width: 816px; height: 150px">\
               <div id="group421491835-iphoneButton35673912" style="position: absolute; left: 0px; top: 90px; width: 82px; height: 60px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton35673912" data-review-reference-id="iphoneButton35673912">\
                  <div class="stencil-wrapper" style="width: 82px; height: 60px">\
                     <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 64px;width:86px;">\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="86" height="64" viewBox="-2 -2 86 64">\
                           <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 59.00 Q 2.54, 59.42, 1.13, 58.87 Q 0.16, 57.96, -0.26, 56.39 Q -0.48,\
                              42.72, -1.00, 29.14 Q -1.04, 15.57, -0.21, 1.74 Q 0.70, 0.72, 1.10, -0.81 Q 1.94, -1.91, 3.46, -2.67 Q 16.36, -3.03, 29.18,\
                              -3.06 Q 41.93, -3.03, 54.64, -2.56 Q 67.32, -1.97, 80.34, -2.47 Q 81.50, -1.89, 82.99, -1.10 Q 83.91, -0.06, 84.71, 1.45 Q\
                              84.58, 15.26, 84.54, 28.89 Q 84.70, 42.44, 85.01, 56.44 Q 84.48, 57.71, 83.44, 59.29 Q 82.11, 59.97, 80.51, 60.58 Q 67.39,\
                              59.40, 54.73, 59.93 Q 42.02, 59.43, 29.34, 59.20 Q 16.67, 59.00, 4.00, 59.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                              <svg:text x="41" y="30" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Users</svg:text>\
                           </svg:a>\
                        </svg:svg>\
                     </div>\
                  </div>\
                  <div class="interactive-stencil-highlighter" style="width: 82px; height: 60px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'group421491835-iphoneButton35673912\', \'1133755734\', {"button":"left","id":"401567595","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction920830483","options":"reloadOnly","target":"1294283414","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
               <div id="group421491835-iphoneButton177778800" style="position: absolute; left: 340px; top: 90px; width: 117px; height: 60px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton177778800" data-review-reference-id="iphoneButton177778800">\
                  <div class="stencil-wrapper" style="width: 117px; height: 60px">\
                     <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 64px;width:121px;">\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="121" height="64" viewBox="-2 -2 121 64">\
                           <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 59.00 Q 2.11, 60.28, 1.12, 58.88 Q 1.10, 57.28, -0.04, 56.33 Q -0.71,\
                              42.75, 0.22, 29.06 Q 0.11, 15.53, -0.40, 1.69 Q -0.09, 0.43, 0.83, -1.05 Q 2.49, -1.18, 3.80, -1.62 Q 14.93, -2.12, 26.13,\
                              -1.91 Q 37.27, -1.94, 48.37, -2.89 Q 59.48, -2.84, 70.59, -2.52 Q 81.70, -2.20, 92.80, -2.34 Q 103.90, -2.93, 115.39, -2.67\
                              Q 116.68, -2.37, 118.26, -1.40 Q 119.25, -0.31, 120.06, 1.34 Q 120.10, 15.18, 118.31, 28.98 Q 117.98, 42.50, 118.14, 56.03\
                              Q 118.49, 57.35, 118.14, 59.02 Q 117.07, 59.93, 115.44, 60.37 Q 103.98, 59.50, 92.86, 59.80 Q 81.72, 59.64, 70.61, 59.34 Q\
                              59.51, 59.67, 48.40, 59.66 Q 37.30, 60.14, 26.20, 60.64 Q 15.10, 59.00, 4.00, 59.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                              <svg:text x="58.5" y="30" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Authors</svg:text>\
                           </svg:a>\
                        </svg:svg>\
                     </div>\
                  </div>\
                  <div class="interactive-stencil-highlighter" style="width: 117px; height: 60px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'group421491835-iphoneButton177778800\', \'882209625\', {"button":"left","id":"963560856","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction800685763","options":"reloadOnly","target":"1294283414","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
               <div id="group421491835-iphoneButton373609266" style="position: absolute; left: 700px; top: 90px; width: 116px; height: 60px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton373609266" data-review-reference-id="iphoneButton373609266">\
                  <div class="stencil-wrapper" style="width: 116px; height: 60px">\
                     <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 64px;width:120px;">\
                        <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="120" height="64" viewBox="-2 -2 120 64">\
                           <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 59.00 Q 1.91, 60.69, 0.42, 59.58 Q -0.33, 58.31, -0.10, 56.34 Q -0.55,\
                              42.73, -0.50, 29.11 Q -0.51, 15.55, 0.91, 1.98 Q 0.75, 0.73, 1.82, -0.16 Q 2.70, -0.90, 3.80, -1.61 Q 14.77, -2.54, 25.95,\
                              -1.72 Q 37.02, -0.41, 48.03, 0.62 Q 59.01, -0.14, 70.00, -1.13 Q 81.00, -1.82, 92.00, -1.75 Q 103.00, -2.25, 114.31, -2.33\
                              Q 114.98, -0.44, 116.07, -0.08 Q 116.02, 1.36, 117.06, 1.98 Q 116.88, 15.52, 116.83, 29.01 Q 117.20, 42.49, 117.13, 56.03\
                              Q 117.16, 57.24, 115.67, 57.70 Q 115.05, 58.57, 113.79, 58.36 Q 102.91, 58.40, 92.00, 58.95 Q 81.01, 59.33, 70.01, 59.43 Q\
                              59.00, 59.21, 48.00, 59.37 Q 37.00, 59.10, 26.00, 59.61 Q 15.00, 59.00, 4.00, 59.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                              <svg:text x="58" y="30" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Admins</svg:text>\
                           </svg:a>\
                        </svg:svg>\
                     </div>\
                  </div>\
                  <div class="interactive-stencil-highlighter" style="width: 116px; height: 60px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'group421491835-iphoneButton373609266\', \'1299882875\', {"button":"left","id":"1005117459","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction963316529","options":"reloadOnly","target":"1294283414","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
               <div id="group421491835-text688465480" style="position: absolute; left: 305px; top: 0px; width: 194px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text688465480" data-review-reference-id="text688465480">\
                  <div class="stencil-wrapper" style="width: 194px; height: 37px">\
                     <div title="" style="width:199px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">MM includes </span></p></span></span></div>\
                  </div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-text757763075" style="position: absolute; left: 280px; top: 300px; width: 200px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text757763075" data-review-reference-id="text757763075">\
            <div class="stencil-wrapper" style="width: 200px; height: 37px">\
               <div title="" style="width:205px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">Admin Name </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-text703777227" style="position: absolute; left: 280px; top: 345px; width: 154px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text703777227" data-review-reference-id="text703777227">\
            <div class="stencil-wrapper" style="width: 154px; height: 20px">\
               <div title="" style="width:159px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline22"><p><span style="font-size: 18px;">POSITION AT MM</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-iphoneButton457243839" style="position: absolute; left: 275px; top: 385px; width: 290px; height: 50px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton457243839" data-review-reference-id="iphoneButton457243839">\
            <div class="stencil-wrapper" style="width: 290px; height: 50px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 54px;width:294px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="294" height="54" viewBox="-2 -2 294 54">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 49.00 Q 2.45, 49.61, 0.82, 49.18 Q 0.04, 48.04, -0.85, 46.58 Q 0.09,\
                        35.13, -0.31, 24.09 Q 0.19, 13.03, -1.06, 1.55 Q 0.39, 0.61, 1.66, -0.31 Q 2.47, -1.20, 3.73, -1.85 Q 14.09, -1.38, 24.30,\
                        -0.80 Q 34.41, -1.63, 44.54, -2.72 Q 54.70, -2.76, 64.85, -1.71 Q 75.00, -1.05, 85.14, -1.44 Q 95.29, -1.79, 105.43, -1.70\
                        Q 115.57, -1.87, 125.71, -1.11 Q 135.86, -1.86, 146.00, -0.54 Q 156.14, -1.01, 166.29, -0.68 Q 176.43, -1.71, 186.57, -2.40\
                        Q 196.71, -2.48, 206.86, -2.94 Q 217.00, -2.87, 227.14, -2.89 Q 237.29, -2.89, 247.43, -2.65 Q 257.57, -2.26, 267.71, -2.45\
                        Q 277.86, -1.99, 288.22, -1.92 Q 289.63, -2.23, 290.63, -0.70 Q 291.26, 0.43, 292.32, 1.57 Q 293.13, 12.68, 293.12, 23.85\
                        Q 292.74, 34.94, 291.73, 46.16 Q 292.44, 47.69, 291.50, 49.34 Q 289.98, 49.80, 288.17, 49.52 Q 277.93, 49.46, 267.79, 49.97\
                        Q 257.58, 49.35, 247.44, 49.46 Q 237.30, 50.35, 227.15, 50.63 Q 217.00, 50.51, 206.86, 50.59 Q 196.72, 50.91, 186.57, 50.16\
                        Q 176.43, 50.77, 166.29, 50.76 Q 156.14, 50.15, 146.00, 50.50 Q 135.86, 50.61, 125.71, 50.68 Q 115.57, 50.46, 105.43, 50.77\
                        Q 95.29, 50.60, 85.14, 49.94 Q 75.00, 49.00, 64.86, 49.34 Q 54.71, 49.03, 44.57, 49.15 Q 34.43, 48.54, 24.29, 49.00 Q 14.14,\
                        49.00, 4.00, 49.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="145" y="25" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Add New Article</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 290px; height: 50px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-523657174-layer-iphoneButton457243839\', \'952265098\', {"button":"left","id":"1152889124","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction167713353","options":"reloadOnly","target":"1151130604","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-523657174-layer-1579054899" style="position: absolute; left: 765px; top: 385px; width: 290px; height: 50px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="1579054899" data-review-reference-id="1579054899">\
            <div class="stencil-wrapper" style="width: 290px; height: 50px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 54px;width:294px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="294" height="54" viewBox="-2 -2 294 54">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 49.00 Q 1.91, 50.67, 0.49, 49.51 Q -0.25, 48.25, -0.67, 46.52 Q -0.66,\
                        35.24, -0.79, 24.13 Q -0.53, 13.05, 0.27, 1.84 Q 0.83, 0.76, 1.42, -0.52 Q 2.50, -1.17, 3.70, -1.94 Q 13.98, -2.06, 24.21,\
                        -2.03 Q 34.41, -1.44, 44.57, -1.28 Q 54.71, -1.24, 64.85, -1.57 Q 75.00, -2.34, 85.14, -1.89 Q 95.29, -1.84, 105.43, -2.01\
                        Q 115.57, -2.07, 125.71, -2.23 Q 135.86, -2.13, 146.00, -1.83 Q 156.14, -2.14, 166.29, -1.73 Q 176.43, -0.54, 186.57, -1.33\
                        Q 196.71, -0.46, 206.86, -0.87 Q 217.00, -0.67, 227.14, -0.82 Q 237.29, -0.56, 247.43, -0.80 Q 257.57, -1.47, 267.71, -2.02\
                        Q 277.86, -1.57, 288.17, -1.74 Q 289.17, -0.98, 290.38, -0.42 Q 290.87, 0.72, 291.27, 1.91 Q 291.48, 12.93, 291.39, 23.97\
                        Q 291.01, 35.00, 292.09, 46.24 Q 291.04, 47.19, 290.78, 48.70 Q 289.20, 48.77, 288.11, 49.33 Q 277.84, 48.91, 267.78, 49.94\
                        Q 257.61, 50.08, 247.44, 49.84 Q 237.29, 49.29, 227.14, 48.73 Q 217.00, 49.85, 206.86, 50.04 Q 196.71, 49.32, 186.57, 48.41\
                        Q 176.43, 48.92, 166.29, 49.64 Q 156.14, 48.68, 146.00, 49.19 Q 135.86, 49.71, 125.71, 49.31 Q 115.57, 48.40, 105.43, 48.85\
                        Q 95.29, 48.98, 85.14, 49.20 Q 75.00, 49.02, 64.86, 48.48 Q 54.71, 49.59, 44.57, 49.39 Q 34.43, 49.80, 24.29, 49.39 Q 14.14,\
                        49.00, 4.00, 49.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="145" y="25" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Add New Poll</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 290px; height: 50px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-523657174-layer-1579054899\', \'1869748727\', {"button":"left","id":"874456236","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction253153709","options":"reloadOnly","target":"1713085884","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-523657174-layer-762725278" style="position: absolute; left: 1065px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="762725278" data-review-reference-id="762725278">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e368-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e368"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-1206516305" style="position: absolute; left: 920px; top: 140px; width: 129px; height: 22px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1206516305" data-review-reference-id="1206516305">\
            <div class="stencil-wrapper" style="width: 129px; height: 22px">\
               <div title="" style="width:134px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;"><strong>Display Name</strong> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-277810003" style="position: absolute; left: 175px; top: 15px; width: 95px; height: 80px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="277810003" data-review-reference-id="277810003">\
            <div class="stencil-wrapper" style="width: 95px; height: 80px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 80px;width:95px;" width="95" height="80">\
                     <svg:g width="95" height="80"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.38, 0.34, 24.75, 0.32 Q 36.12, 0.17, 47.50, 0.14 Q\
                        58.88, 0.13, 70.25, 0.30 Q 81.62, 0.30, 93.92, 1.08 Q 94.39, 14.20, 94.40, 27.13 Q 94.31, 39.91, 94.51, 52.62 Q 94.20, 65.31,\
                        93.49, 78.49 Q 81.94, 78.96, 70.46, 79.47 Q 58.98, 79.65, 47.56, 79.79 Q 36.15, 79.84, 24.76, 79.46 Q 13.38, 78.35, 1.65,\
                        78.35 Q 1.81, 65.40, 1.20, 52.78 Q 1.24, 40.05, 1.92, 27.34 Q 2.00, 14.67, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.82, 8.74, 20.98, 16.26 Q 30.14, 23.80, 39.35, 31.26 Q 48.27,\
                        39.08, 57.28, 46.78 Q 66.51, 54.22, 75.68, 61.74 Q 83.90, 70.40, 93.00, 78.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 78.00 Q 9.05, 70.80, 17.27, 65.05 Q 25.46, 59.26, 33.32, 53.06 Q 40.74,\
                        46.32, 48.26, 39.71 Q 56.00, 33.36, 64.20, 27.57 Q 71.91, 21.20, 79.20, 14.30 Q 87.25, 8.33, 95.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-icon70615896" style="position: absolute; left: 530px; top: 395px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon70615896" data-review-reference-id="icon70615896">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e191-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e191"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-icon585013496" style="position: absolute; left: 1020px; top: 395px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon585013496" data-review-reference-id="icon585013496">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e191-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e191"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-882095455" style="position: absolute; left: 275px; top: 385px; width: 290px; height: 50px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="882095455" data-review-reference-id="882095455">\
            <div class="stencil-wrapper" style="width: 290px; height: 50px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 54px;width:294px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="294" height="54" viewBox="-2 -2 294 54">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 49.00 Q 2.68, 49.14, 1.79, 48.21 Q 1.80, 46.79, 0.03, 46.30 Q 0.33, 35.10,\
                        1.66, 23.95 Q 0.69, 13.01, 0.02, 1.79 Q 0.34, 0.59, 1.42, -0.52 Q 2.79, -0.79, 4.07, -0.79 Q 13.99, -2.01, 24.20, -2.13 Q\
                        34.39, -2.12, 44.54, -2.86 Q 54.70, -2.76, 64.85, -2.94 Q 75.00, -3.01, 85.14, -3.19 Q 95.28, -3.14, 105.43, -3.26 Q 115.57,\
                        -2.90, 125.71, -2.13 Q 135.86, -2.66, 146.00, -3.17 Q 156.14, -2.99, 166.29, -2.08 Q 176.43, -1.98, 186.57, -0.74 Q 196.71,\
                        -1.58, 206.86, -2.23 Q 217.00, -1.97, 227.14, -2.18 Q 237.29, -2.40, 247.43, -2.58 Q 257.57, -2.03, 267.71, -2.67 Q 277.86,\
                        -2.64, 288.33, -2.39 Q 289.52, -1.92, 290.97, -1.08 Q 291.82, 0.01, 292.57, 1.50 Q 292.60, 12.76, 292.80, 23.87 Q 292.46,\
                        34.95, 291.80, 46.18 Q 291.47, 47.35, 290.46, 48.41 Q 289.87, 49.67, 288.23, 49.73 Q 278.05, 50.30, 267.79, 50.02 Q 257.59,\
                        49.45, 247.44, 49.45 Q 237.30, 50.22, 227.15, 50.48 Q 217.00, 49.47, 206.86, 47.76 Q 196.71, 49.52, 186.57, 48.73 Q 176.43,\
                        49.77, 166.29, 49.85 Q 156.14, 49.15, 146.00, 49.03 Q 135.86, 50.18, 125.71, 49.19 Q 115.57, 50.65, 105.43, 50.58 Q 95.29,\
                        50.89, 85.14, 51.02 Q 75.00, 49.90, 64.86, 49.68 Q 54.71, 50.37, 44.57, 50.32 Q 34.43, 50.15, 24.29, 50.40 Q 14.14, 49.00,\
                        4.00, 49.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="145" y="25" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Add New Article</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 290px; height: 50px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-523657174-layer-882095455\', \'1161515645\', {"button":"left","id":"743689576","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"1670749731","options":"reloadOnly","target":"1151130604","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-523657174-layer-1076956631" style="position: absolute; left: 530px; top: 395px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1076956631" data-review-reference-id="1076956631">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e191-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e191"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-523657174-layer-729913182" style="position: absolute; left: 510px; top: 485px; width: 291px; height: 50px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="729913182" data-review-reference-id="729913182">\
            <div class="stencil-wrapper" style="width: 291px; height: 50px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 54px;width:295px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="295" height="54" viewBox="-2 -2 295 54">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 49.00 Q 2.66, 49.18, 1.71, 48.29 Q 0.93, 47.41, 0.57, 46.13 Q -0.01,\
                        35.15, 0.04, 24.07 Q 0.27, 13.03, 0.62, 1.92 Q 0.51, 0.65, 0.92, -0.97 Q 2.11, -1.68, 3.54, -2.42 Q 13.93, -2.64, 24.23, -2.72\
                        Q 34.49, -2.22, 44.70, -2.04 Q 54.88, -2.03, 65.07, -2.30 Q 75.25, -2.44, 85.43, -2.62 Q 95.61, -2.57, 105.79, -2.70 Q 115.96,\
                        -2.76, 126.14, -2.59 Q 136.32, -2.21, 146.50, -2.60 Q 156.68, -2.66, 166.86, -2.46 Q 177.04, -1.21, 187.21, -1.82 Q 197.39,\
                        -2.15, 207.57, -1.78 Q 217.75, -1.42, 227.93, -1.53 Q 238.11, -1.50, 248.29, -1.64 Q 258.46, -1.51, 268.64, -1.68 Q 278.82,\
                        -2.07, 289.18, -1.76 Q 290.37, -1.52, 291.62, -0.69 Q 292.54, 0.22, 293.02, 1.67 Q 292.91, 12.86, 293.16, 23.92 Q 293.07,\
                        34.96, 292.95, 46.21 Q 292.17, 47.24, 291.36, 48.33 Q 290.31, 48.91, 289.34, 50.06 Q 278.99, 50.11, 268.74, 50.30 Q 258.51,\
                        50.25, 248.31, 50.47 Q 238.11, 49.86, 227.93, 49.33 Q 217.75, 49.34, 207.57, 50.21 Q 197.39, 50.04, 187.21, 50.53 Q 177.04,\
                        49.58, 166.86, 50.46 Q 156.68, 49.36, 146.50, 49.75 Q 136.32, 49.76, 126.14, 49.58 Q 115.96, 50.26, 105.79, 49.61 Q 95.61,\
                        50.23, 85.43, 49.90 Q 75.25, 50.07, 65.07, 49.43 Q 54.89, 49.33, 44.71, 49.66 Q 34.54, 49.91, 24.36, 50.22 Q 14.18, 49.00,\
                        4.00, 49.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="145.5" y="25" dy="0.3em" fill="#FFFFFF" style="font-size:2.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Comments Approval</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 291px; height: 50px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-523657174-layer-729913182\', \'1547214278\', {"button":"left","id":"1245551579","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"1876283675","options":"reloadOnly","target":"800258728","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="523657174"] .border-wrapper, body[data-current-page-id="523657174"] .simulation-container{\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="523657174"] .border-wrapper, body.has-frame[data-current-page-id="523657174"] .simulation-container{\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="523657174"] .svg-border-1366-768{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="523657174"] .border-wrapper .border-div{\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "523657174",\
      			"name": "Admin Panel",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
   <div id="border-wrapper">\
      <div xmlns="http://www.w3.org/1999/xhtml" xmlns:json="http://json.org/" class="svg-border svg-border-1366-768" style="display: none;">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="svg_border" style="position:absolute;left:-43px;top:-13px;width:1423px;height:792px;"><svg:path class=" svg_unselected_element" d="M 32.00, 3.00 Q 42.12, 1.17, 52.24, 1.12 Q 62.35, 1.46, 72.47, 1.39 Q 82.59,\
            1.70, 92.71, 1.83 Q 102.82, 1.76, 112.94, 1.48 Q 123.06, 1.69, 133.18, 1.99 Q 143.29, 2.13, 153.41, 2.10 Q 163.53, 2.43, 173.65,\
            2.37 Q 183.76, 2.19, 193.88, 1.87 Q 204.00, 1.83, 214.12, 2.10 Q 224.24, 1.79, 234.35, 1.40 Q 244.47, 1.81, 254.59, 1.78 Q\
            264.71, 1.60, 274.82, 1.88 Q 284.94, 2.28, 295.06, 2.44 Q 305.18, 2.60, 315.29, 1.85 Q 325.41, 2.19, 335.53, 2.00 Q 345.65,\
            1.59, 355.76, 1.51 Q 365.88, 1.47, 376.00, 1.73 Q 386.12, 1.89, 396.24, 2.06 Q 406.35, 1.91, 416.47, 1.06 Q 426.59, 1.57,\
            436.71, 0.72 Q 446.82, 1.48, 456.94, 1.84 Q 467.06, 2.17, 477.18, 1.77 Q 487.29, 2.17, 497.41, 1.56 Q 507.53, 1.39, 517.65,\
            1.44 Q 527.76, 0.92, 537.88, 2.05 Q 548.00, 2.48, 558.12, 2.93 Q 568.24, 3.31, 578.35, 3.30 Q 588.47, 3.06, 598.59, 1.70 Q\
            608.71, 2.07, 618.82, 1.96 Q 628.94, 1.80, 639.06, 1.79 Q 649.18, 1.63, 659.29, 1.88 Q 669.41, 2.59, 679.53, 1.75 Q 689.65,\
            1.77, 699.77, 1.64 Q 709.88, 1.47, 720.00, 1.85 Q 730.12, 1.75, 740.24, 2.42 Q 750.35, 3.24, 760.47, 3.26 Q 770.59, 3.35,\
            780.71, 2.38 Q 790.82, 1.84, 800.94, 1.09 Q 811.06, 1.93, 821.18, 1.70 Q 831.29, 1.12, 841.41, 0.96 Q 851.53, 1.34, 861.65,\
            2.04 Q 871.77, 2.31, 881.88, 2.54 Q 892.00, 2.56, 902.12, 3.32 Q 912.24, 2.93, 922.35, 2.68 Q 932.47, 2.10, 942.59, 2.90 Q\
            952.71, 2.62, 962.82, 2.64 Q 972.94, 2.86, 983.06, 2.67 Q 993.18, 2.88, 1003.30, 2.04 Q 1013.41, 1.26, 1023.53, 1.20 Q 1033.65,\
            2.18, 1043.77, 2.84 Q 1053.88, 2.71, 1064.00, 2.85 Q 1074.12, 2.40, 1084.24, 3.07 Q 1094.35, 3.48, 1104.47, 3.76 Q 1114.59,\
            3.97, 1124.71, 3.85 Q 1134.83, 3.53, 1144.94, 3.32 Q 1155.06, 2.34, 1165.18, 1.44 Q 1175.30, 2.20, 1185.41, 1.91 Q 1195.53,\
            2.51, 1205.65, 2.16 Q 1215.77, 2.08, 1225.88, 1.74 Q 1236.00, 1.72, 1246.12, 1.75 Q 1256.24, 2.46, 1266.35, 2.30 Q 1276.47,\
            2.60, 1286.59, 2.15 Q 1296.71, 2.40, 1306.83, 3.18 Q 1316.94, 2.96, 1327.06, 2.09 Q 1337.18, 1.89, 1347.30, 2.54 Q 1357.41,\
            2.47, 1367.53, 1.88 Q 1377.65, 1.63, 1387.77, 1.77 Q 1397.88, 2.13, 1408.39, 2.61 Q 1408.53, 13.00, 1408.45, 23.28 Q 1407.86,\
            33.52, 1407.44, 43.70 Q 1407.98, 53.86, 1406.60, 64.04 Q 1407.35, 74.20, 1407.63, 84.37 Q 1407.75, 94.54, 1408.07, 104.71\
            Q 1408.62, 114.88, 1409.50, 125.05 Q 1409.20, 135.22, 1408.93, 145.39 Q 1409.30, 155.57, 1409.79, 165.74 Q 1409.56, 175.91,\
            1409.37, 186.08 Q 1409.27, 196.25, 1409.17, 206.42 Q 1409.76, 216.59, 1408.94, 226.76 Q 1409.84, 236.93, 1408.80, 247.11 Q\
            1409.33, 257.28, 1409.45, 267.45 Q 1409.01, 277.62, 1409.38, 287.79 Q 1409.49, 297.96, 1409.42, 308.13 Q 1408.67, 318.30,\
            1408.80, 328.47 Q 1408.74, 338.64, 1408.83, 348.82 Q 1408.13, 358.99, 1407.94, 369.16 Q 1407.74, 379.33, 1408.02, 389.50 Q\
            1408.22, 399.67, 1407.51, 409.84 Q 1409.47, 420.01, 1409.34, 430.18 Q 1408.01, 440.36, 1408.29, 450.53 Q 1408.43, 460.70,\
            1408.21, 470.87 Q 1408.41, 481.04, 1407.94, 491.21 Q 1408.12, 501.38, 1407.55, 511.55 Q 1408.68, 521.72, 1407.82, 531.89 Q\
            1407.10, 542.07, 1408.05, 552.24 Q 1409.06, 562.41, 1409.61, 572.58 Q 1409.69, 582.75, 1409.85, 592.92 Q 1410.06, 603.09,\
            1410.05, 613.26 Q 1409.72, 623.43, 1409.28, 633.61 Q 1409.16, 643.78, 1409.25, 653.95 Q 1409.51, 664.12, 1409.03, 674.29 Q\
            1408.52, 684.46, 1408.66, 694.63 Q 1409.24, 704.80, 1409.23, 714.97 Q 1408.22, 725.15, 1408.08, 735.32 Q 1408.28, 745.49,\
            1407.81, 755.66 Q 1407.33, 765.83, 1408.05, 776.05 Q 1397.85, 775.90, 1387.78, 776.09 Q 1377.63, 775.64, 1367.52, 775.65 Q\
            1357.41, 775.85, 1347.30, 776.00 Q 1337.18, 775.93, 1327.06, 776.32 Q 1316.94, 776.02, 1306.83, 776.67 Q 1296.71, 777.37,\
            1286.59, 777.32 Q 1276.47, 776.23, 1266.35, 776.34 Q 1256.24, 776.66, 1246.12, 777.84 Q 1236.00, 777.46, 1225.88, 777.05 Q\
            1215.77, 777.27, 1205.65, 777.46 Q 1195.53, 777.48, 1185.41, 777.11 Q 1175.30, 776.95, 1165.18, 777.29 Q 1155.06, 777.04,\
            1144.94, 778.03 Q 1134.83, 777.77, 1124.71, 777.89 Q 1114.59, 777.56, 1104.47, 776.67 Q 1094.35, 776.65, 1084.24, 776.96 Q\
            1074.12, 777.17, 1064.00, 776.55 Q 1053.88, 776.10, 1043.77, 777.09 Q 1033.65, 776.60, 1023.53, 776.52 Q 1013.41, 775.52,\
            1003.30, 775.48 Q 993.18, 775.54, 983.06, 775.50 Q 972.94, 776.02, 962.82, 776.45 Q 952.71, 776.95, 942.59, 776.55 Q 932.47,\
            776.94, 922.35, 776.55 Q 912.24, 776.96, 902.12, 776.35 Q 892.00, 775.95, 881.88, 777.12 Q 871.77, 777.16, 861.65, 777.35\
            Q 851.53, 777.46, 841.41, 777.48 Q 831.29, 777.15, 821.18, 777.21 Q 811.06, 777.34, 800.94, 777.49 Q 790.82, 777.33, 780.71,\
            777.24 Q 770.59, 777.15, 760.47, 776.78 Q 750.35, 777.63, 740.24, 776.65 Q 730.12, 776.21, 720.00, 776.06 Q 709.88, 776.42,\
            699.77, 776.98 Q 689.65, 776.38, 679.53, 774.89 Q 669.41, 774.92, 659.29, 775.54 Q 649.18, 775.44, 639.06, 775.81 Q 628.94,\
            775.84, 618.82, 775.56 Q 608.71, 775.36, 598.59, 775.76 Q 588.47, 775.65, 578.35, 776.72 Q 568.24, 777.50, 558.12, 777.98\
            Q 548.00, 777.55, 537.88, 777.85 Q 527.76, 777.53, 517.65, 776.68 Q 507.53, 775.82, 497.41, 776.67 Q 487.29, 777.13, 477.18,\
            777.07 Q 467.06, 776.77, 456.94, 777.28 Q 446.82, 777.35, 436.71, 777.14 Q 426.59, 776.77, 416.47, 776.77 Q 406.35, 776.55,\
            396.24, 776.86 Q 386.12, 777.74, 376.00, 777.90 Q 365.88, 777.07, 355.76, 776.15 Q 345.65, 775.87, 335.53, 776.99 Q 325.41,\
            775.75, 315.29, 775.63 Q 305.18, 775.81, 295.06, 776.88 Q 284.94, 777.34, 274.82, 777.51 Q 264.71, 777.53, 254.59, 777.78\
            Q 244.47, 777.90, 234.35, 777.03 Q 224.24, 777.05, 214.12, 777.53 Q 204.00, 777.59, 193.88, 777.93 Q 183.76, 777.69, 173.65,\
            777.58 Q 163.53, 777.47, 153.41, 776.77 Q 143.29, 776.21, 133.18, 776.04 Q 123.06, 776.25, 112.94, 776.85 Q 102.82, 777.17,\
            92.71, 777.24 Q 82.59, 777.44, 72.47, 777.36 Q 62.35, 776.96, 52.24, 776.39 Q 42.12, 776.43, 31.78, 776.22 Q 31.35, 766.05,\
            31.00, 755.80 Q 32.17, 745.48, 32.75, 735.29 Q 32.12, 725.14, 31.08, 714.98 Q 31.06, 704.81, 30.79, 694.63 Q 31.04, 684.46,\
            31.07, 674.29 Q 30.24, 664.12, 29.78, 653.95 Q 29.97, 643.78, 30.11, 633.61 Q 30.46, 623.43, 30.90, 613.26 Q 30.85, 603.09,\
            31.17, 592.92 Q 31.90, 582.75, 31.74, 572.58 Q 30.99, 562.41, 31.23, 552.24 Q 31.97, 542.07, 32.36, 531.89 Q 31.52, 521.72,\
            31.10, 511.55 Q 31.61, 501.38, 32.41, 491.21 Q 31.92, 481.04, 32.40, 470.87 Q 31.39, 460.70, 31.22, 450.53 Q 31.06, 440.36,\
            31.06, 430.18 Q 30.56, 420.01, 30.91, 409.84 Q 30.60, 399.67, 30.61, 389.50 Q 30.76, 379.33, 30.60, 369.16 Q 30.48, 358.99,\
            30.10, 348.82 Q 29.95, 338.64, 29.67, 328.47 Q 29.87, 318.30, 30.20, 308.13 Q 31.05, 297.96, 31.01, 287.79 Q 30.85, 277.62,\
            30.76, 267.45 Q 30.98, 257.28, 31.09, 247.11 Q 30.93, 236.93, 30.92, 226.76 Q 31.41, 216.59, 31.44, 206.42 Q 31.81, 196.25,\
            31.06, 186.08 Q 30.98, 175.91, 30.30, 165.74 Q 30.30, 155.57, 30.32, 145.39 Q 30.67, 135.22, 30.40, 125.05 Q 30.72, 114.88,\
            31.35, 104.71 Q 30.64, 94.54, 31.18, 84.37 Q 31.16, 74.20, 31.74, 64.03 Q 32.15, 53.86, 32.70, 43.68 Q 33.43, 33.51, 32.65,\
            23.34 Q 32.00, 13.17, 32.00, 3.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 23.00, 7.00 Q 33.12, 7.31, 43.24, 7.42 Q 53.35, 7.12, 63.47, 7.14 Q 73.59,\
            6.80, 83.71, 6.22 Q 93.82, 6.06, 103.94, 6.41 Q 114.06, 6.40, 124.18, 6.26 Q 134.29, 5.88, 144.41, 5.73 Q 154.53, 6.00, 164.65,\
            5.43 Q 174.76, 5.57, 184.88, 5.73 Q 195.00, 6.00, 205.12, 5.96 Q 215.24, 6.41, 225.35, 6.44 Q 235.47, 6.36, 245.59, 6.01 Q\
            255.71, 5.80, 265.82, 6.27 Q 275.94, 5.49, 286.06, 6.27 Q 296.18, 6.08, 306.29, 5.29 Q 316.41, 6.34, 326.53, 5.79 Q 336.65,\
            6.81, 346.76, 5.67 Q 356.88, 5.84, 367.00, 6.06 Q 377.12, 6.41, 387.24, 6.17 Q 397.35, 6.48, 407.47, 7.24 Q 417.59, 6.02,\
            427.71, 6.57 Q 437.82, 6.46, 447.94, 6.57 Q 458.06, 6.58, 468.18, 6.18 Q 478.29, 6.65, 488.41, 6.32 Q 498.53, 6.83, 508.65,\
            7.13 Q 518.76, 6.05, 528.88, 5.96 Q 539.00, 6.13, 549.12, 6.75 Q 559.24, 7.15, 569.35, 6.71 Q 579.47, 5.66, 589.59, 5.41 Q\
            599.71, 5.76, 609.82, 6.75 Q 619.94, 6.06, 630.06, 6.07 Q 640.18, 6.50, 650.29, 6.83 Q 660.41, 6.04, 670.53, 4.84 Q 680.65,\
            5.26, 690.77, 4.85 Q 700.88, 5.64, 711.00, 5.57 Q 721.12, 5.14, 731.24, 5.68 Q 741.35, 6.02, 751.47, 5.47 Q 761.59, 5.02,\
            771.71, 6.11 Q 781.82, 6.93, 791.94, 7.49 Q 802.06, 6.05, 812.18, 5.62 Q 822.29, 6.10, 832.41, 6.31 Q 842.53, 6.55, 852.65,\
            6.44 Q 862.77, 7.05, 872.88, 7.25 Q 883.00, 7.38, 893.12, 6.60 Q 903.24, 5.84, 913.35, 5.91 Q 923.47, 6.48, 933.59, 6.57 Q\
            943.71, 6.42, 953.82, 6.72 Q 963.94, 6.56, 974.06, 7.19 Q 984.18, 6.95, 994.30, 7.72 Q 1004.41, 7.85, 1014.53, 6.02 Q 1024.65,\
            5.43, 1034.77, 6.10 Q 1044.88, 5.87, 1055.00, 6.53 Q 1065.12, 6.87, 1075.24, 6.81 Q 1085.35, 6.17, 1095.47, 6.36 Q 1105.59,\
            6.50, 1115.71, 6.17 Q 1125.83, 5.92, 1135.94, 6.08 Q 1146.06, 6.02, 1156.18, 5.68 Q 1166.30, 5.34, 1176.41, 5.36 Q 1186.53,\
            6.17, 1196.65, 7.09 Q 1206.77, 6.97, 1216.88, 6.66 Q 1227.00, 6.75, 1237.12, 6.69 Q 1247.24, 6.93, 1257.35, 6.95 Q 1267.47,\
            7.00, 1277.59, 7.46 Q 1287.71, 6.77, 1297.83, 6.98 Q 1307.94, 6.37, 1318.06, 5.50 Q 1328.18, 5.97, 1338.30, 5.99 Q 1348.41,\
            5.67, 1358.53, 5.41 Q 1368.65, 6.47, 1378.77, 6.70 Q 1388.88, 5.82, 1399.36, 6.64 Q 1399.94, 16.86, 1400.33, 27.15 Q 1400.05,\
            37.44, 1400.08, 47.65 Q 1400.22, 57.84, 1400.34, 68.02 Q 1400.21, 78.19, 1400.73, 88.37 Q 1401.10, 98.54, 1400.08, 108.71\
            Q 1399.68, 118.88, 1399.48, 129.05 Q 1399.55, 139.22, 1399.45, 149.39 Q 1398.99, 159.57, 1399.34, 169.74 Q 1399.69, 179.91,\
            1399.34, 190.08 Q 1400.84, 200.25, 1400.42, 210.42 Q 1400.61, 220.59, 1400.69, 230.76 Q 1400.26, 240.93, 1400.94, 251.11 Q\
            1400.85, 261.28, 1400.22, 271.45 Q 1400.20, 281.62, 1400.45, 291.79 Q 1400.55, 301.96, 1399.84, 312.13 Q 1400.52, 322.30,\
            1400.04, 332.47 Q 1399.95, 342.64, 1399.99, 352.82 Q 1400.05, 362.99, 1400.18, 373.16 Q 1400.47, 383.33, 1400.52, 393.50 Q\
            1400.74, 403.67, 1400.87, 413.84 Q 1400.36, 424.01, 1400.44, 434.18 Q 1400.00, 444.36, 1399.95, 454.53 Q 1400.07, 464.70,\
            1399.78, 474.87 Q 1398.86, 485.04, 1398.65, 495.21 Q 1399.53, 505.38, 1399.51, 515.55 Q 1399.11, 525.72, 1398.74, 535.89 Q\
            1399.28, 546.07, 1399.00, 556.24 Q 1398.66, 566.41, 1399.23, 576.58 Q 1398.08, 586.75, 1399.07, 596.92 Q 1399.34, 607.09,\
            1400.72, 617.26 Q 1400.70, 627.43, 1400.81, 637.61 Q 1400.07, 647.78, 1399.48, 657.95 Q 1398.78, 668.12, 1398.97, 678.29 Q\
            1399.00, 688.46, 1398.26, 698.63 Q 1398.43, 708.80, 1398.99, 718.97 Q 1400.27, 729.15, 1399.76, 739.32 Q 1399.68, 749.49,\
            1400.48, 759.66 Q 1399.93, 769.83, 1399.37, 780.37 Q 1389.03, 780.43, 1378.85, 780.56 Q 1368.69, 780.64, 1358.58, 781.41 Q\
            1348.44, 781.46, 1338.31, 781.80 Q 1328.19, 781.83, 1318.06, 781.57 Q 1307.94, 780.14, 1297.83, 780.93 Q 1287.71, 781.39,\
            1277.59, 781.68 Q 1267.47, 781.64, 1257.35, 781.53 Q 1247.24, 781.61, 1237.12, 781.63 Q 1227.00, 781.03, 1216.88, 781.00 Q\
            1206.77, 780.78, 1196.65, 780.38 Q 1186.53, 780.97, 1176.41, 780.77 Q 1166.30, 780.85, 1156.18, 780.75 Q 1146.06, 780.23,\
            1135.94, 780.70 Q 1125.83, 779.90, 1115.71, 780.91 Q 1105.59, 780.46, 1095.47, 780.80 Q 1085.35, 780.64, 1075.24, 780.81 Q\
            1065.12, 780.91, 1055.00, 780.80 Q 1044.88, 780.51, 1034.77, 780.17 Q 1024.65, 780.82, 1014.53, 781.41 Q 1004.41, 781.29,\
            994.30, 780.71 Q 984.18, 780.57, 974.06, 780.05 Q 963.94, 780.33, 953.82, 781.12 Q 943.71, 780.83, 933.59, 781.49 Q 923.47,\
            780.61, 913.35, 781.11 Q 903.24, 781.51, 893.12, 781.46 Q 883.00, 781.18, 872.88, 781.39 Q 862.77, 781.35, 852.65, 779.54\
            Q 842.53, 780.74, 832.41, 779.65 Q 822.29, 781.73, 812.18, 781.25 Q 802.06, 780.36, 791.94, 780.12 Q 781.82, 780.98, 771.71,\
            780.51 Q 761.59, 779.87, 751.47, 780.92 Q 741.35, 780.54, 731.24, 780.77 Q 721.12, 780.83, 711.00, 780.32 Q 700.88, 779.91,\
            690.77, 780.46 Q 680.65, 781.34, 670.53, 781.17 Q 660.41, 781.37, 650.29, 781.54 Q 640.18, 781.56, 630.06, 781.29 Q 619.94,\
            781.88, 609.82, 781.29 Q 599.71, 781.70, 589.59, 780.73 Q 579.47, 780.69, 569.35, 781.38 Q 559.24, 780.94, 549.12, 781.41\
            Q 539.00, 780.86, 528.88, 779.94 Q 518.76, 779.65, 508.65, 779.62 Q 498.53, 780.27, 488.41, 780.10 Q 478.29, 780.96, 468.18,\
            781.12 Q 458.06, 781.61, 447.94, 781.52 Q 437.82, 781.08, 427.71, 778.91 Q 417.59, 781.43, 407.47, 780.87 Q 397.35, 780.00,\
            387.24, 780.79 Q 377.12, 780.91, 367.00, 781.06 Q 356.88, 780.75, 346.76, 780.58 Q 336.65, 780.84, 326.53, 779.69 Q 316.41,\
            780.57, 306.29, 781.31 Q 296.18, 781.62, 286.06, 781.51 Q 275.94, 780.96, 265.82, 780.45 Q 255.71, 780.78, 245.59, 780.29\
            Q 235.47, 780.08, 225.35, 780.66 Q 215.24, 781.14, 205.12, 780.73 Q 195.00, 780.12, 184.88, 779.62 Q 174.76, 780.35, 164.65,\
            780.05 Q 154.53, 779.90, 144.41, 780.11 Q 134.29, 780.14, 124.18, 780.68 Q 114.06, 781.37, 103.94, 781.65 Q 93.82, 781.32,\
            83.71, 781.33 Q 73.59, 781.25, 63.47, 780.96 Q 53.35, 781.03, 43.24, 781.32 Q 33.12, 780.97, 22.62, 780.38 Q 22.39, 770.03,\
            22.04, 759.80 Q 21.72, 749.57, 21.69, 739.36 Q 21.83, 729.16, 22.27, 718.98 Q 21.83, 708.81, 21.95, 698.63 Q 22.35, 688.46,\
            21.96, 678.29 Q 22.18, 668.12, 22.16, 657.95 Q 22.44, 647.78, 22.07, 637.61 Q 22.88, 627.43, 22.11, 617.26 Q 22.33, 607.09,\
            23.29, 596.92 Q 23.61, 586.75, 23.92, 576.58 Q 23.29, 566.41, 23.39, 556.24 Q 23.10, 546.07, 22.57, 535.89 Q 22.42, 525.72,\
            22.53, 515.55 Q 22.66, 505.38, 22.57, 495.21 Q 22.89, 485.04, 22.51, 474.87 Q 22.47, 464.70, 22.91, 454.53 Q 23.55, 444.36,\
            23.01, 434.18 Q 22.40, 424.01, 22.45, 413.84 Q 23.41, 403.67, 24.30, 393.50 Q 22.51, 383.33, 22.57, 373.16 Q 22.77, 362.99,\
            23.23, 352.82 Q 22.88, 342.64, 21.88, 332.47 Q 22.37, 322.30, 22.61, 312.13 Q 23.35, 301.96, 22.42, 291.79 Q 22.28, 281.62,\
            22.25, 271.45 Q 22.58, 261.28, 21.90, 251.11 Q 22.14, 240.93, 22.65, 230.76 Q 22.51, 220.59, 22.55, 210.42 Q 22.11, 200.25,\
            23.01, 190.08 Q 22.73, 179.91, 24.28, 169.74 Q 23.71, 159.57, 22.98, 149.39 Q 22.73, 139.22, 22.32, 129.05 Q 22.12, 118.88,\
            21.44, 108.71 Q 23.31, 98.54, 22.81, 88.37 Q 23.10, 78.20, 23.06, 68.03 Q 22.51, 57.86, 21.83, 47.68 Q 21.66, 37.51, 22.37,\
            27.34 Q 23.00, 17.17, 23.00, 7.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 40.00, 11.00 Q 50.12, 10.47, 60.24, 10.42 Q 70.35, 10.28, 80.47, 10.41 Q 90.59,\
            9.96, 100.71, 10.18 Q 110.82, 9.95, 120.94, 10.43 Q 131.06, 9.96, 141.18, 9.69 Q 151.29, 9.89, 161.41, 10.02 Q 171.53, 9.78,\
            181.65, 9.63 Q 191.76, 10.32, 201.88, 10.66 Q 212.00, 10.52, 222.12, 9.86 Q 232.24, 9.69, 242.35, 9.61 Q 252.47, 9.47, 262.59,\
            10.17 Q 272.71, 10.18, 282.82, 10.56 Q 292.94, 10.02, 303.06, 9.67 Q 313.18, 9.55, 323.29, 9.91 Q 333.41, 10.18, 343.53, 10.31\
            Q 353.65, 11.21, 363.76, 10.93 Q 373.88, 10.77, 384.00, 11.25 Q 394.12, 10.85, 404.24, 10.41 Q 414.35, 10.54, 424.47, 10.42\
            Q 434.59, 10.68, 444.71, 10.49 Q 454.82, 10.47, 464.94, 10.01 Q 475.06, 9.92, 485.18, 10.31 Q 495.29, 9.68, 505.41, 9.34 Q\
            515.53, 9.08, 525.65, 10.14 Q 535.76, 9.43, 545.88, 9.91 Q 556.00, 9.84, 566.12, 9.51 Q 576.24, 10.33, 586.35, 9.95 Q 596.47,\
            10.46, 606.59, 9.90 Q 616.71, 9.86, 626.82, 10.18 Q 636.94, 9.78, 647.06, 9.45 Q 657.18, 9.87, 667.29, 10.89 Q 677.41, 10.04,\
            687.53, 10.51 Q 697.65, 9.81, 707.77, 10.50 Q 717.88, 10.71, 728.00, 10.70 Q 738.12, 10.54, 748.24, 10.19 Q 758.35, 10.45,\
            768.47, 9.91 Q 778.59, 10.50, 788.71, 10.38 Q 798.82, 10.24, 808.94, 10.54 Q 819.06, 10.91, 829.18, 10.78 Q 839.29, 10.19,\
            849.41, 10.44 Q 859.53, 10.09, 869.65, 11.02 Q 879.77, 10.59, 889.88, 10.30 Q 900.00, 9.56, 910.12, 10.35 Q 920.24, 11.24,\
            930.35, 10.66 Q 940.47, 10.93, 950.59, 9.48 Q 960.71, 9.61, 970.82, 9.26 Q 980.94, 8.96, 991.06, 8.91 Q 1001.18, 9.42, 1011.30,\
            10.44 Q 1021.41, 10.52, 1031.53, 9.58 Q 1041.65, 9.47, 1051.77, 10.34 Q 1061.88, 10.45, 1072.00, 10.55 Q 1082.12, 9.81, 1092.24,\
            10.21 Q 1102.35, 11.19, 1112.47, 11.03 Q 1122.59, 11.56, 1132.71, 10.31 Q 1142.83, 11.76, 1152.94, 11.49 Q 1163.06, 10.57,\
            1173.18, 10.80 Q 1183.30, 11.06, 1193.41, 10.91 Q 1203.53, 10.85, 1213.65, 11.24 Q 1223.77, 10.24, 1233.88, 10.84 Q 1244.00,\
            10.41, 1254.12, 10.30 Q 1264.24, 9.50, 1274.35, 9.30 Q 1284.47, 9.84, 1294.59, 10.47 Q 1304.71, 10.93, 1314.83, 9.41 Q 1324.94,\
            9.36, 1335.06, 10.00 Q 1345.18, 9.34, 1355.30, 8.79 Q 1365.41, 9.21, 1375.53, 10.27 Q 1385.65, 10.47, 1395.77, 10.67 Q 1405.88,\
            10.82, 1416.11, 10.90 Q 1416.45, 21.02, 1416.80, 31.23 Q 1417.51, 41.41, 1417.53, 51.64 Q 1417.13, 61.84, 1416.99, 72.02 Q\
            1417.13, 82.19, 1417.51, 92.37 Q 1416.99, 102.54, 1416.71, 112.71 Q 1416.71, 122.88, 1416.72, 133.05 Q 1416.07, 143.22, 1416.83,\
            153.39 Q 1416.77, 163.57, 1416.66, 173.74 Q 1416.16, 183.91, 1415.84, 194.08 Q 1415.62, 204.25, 1416.55, 214.42 Q 1417.22,\
            224.59, 1417.71, 234.76 Q 1417.15, 244.93, 1417.15, 255.11 Q 1417.60, 265.28, 1417.28, 275.45 Q 1416.45, 285.62, 1416.46,\
            295.79 Q 1417.03, 305.96, 1417.48, 316.13 Q 1417.57, 326.30, 1416.98, 336.47 Q 1417.10, 346.64, 1417.03, 356.82 Q 1417.03,\
            366.99, 1416.39, 377.16 Q 1416.28, 387.33, 1416.62, 397.50 Q 1417.45, 407.67, 1417.16, 417.84 Q 1416.14, 428.01, 1415.41,\
            438.18 Q 1415.54, 448.36, 1417.16, 458.53 Q 1416.79, 468.70, 1417.09, 478.87 Q 1417.23, 489.04, 1417.19, 499.21 Q 1416.91,\
            509.38, 1417.35, 519.55 Q 1417.49, 529.72, 1417.45, 539.89 Q 1417.64, 550.07, 1417.92, 560.24 Q 1417.82, 570.41, 1417.37,\
            580.58 Q 1417.25, 590.75, 1417.27, 600.92 Q 1417.55, 611.09, 1417.47, 621.26 Q 1416.87, 631.43, 1417.37, 641.61 Q 1416.71,\
            651.78, 1416.09, 661.95 Q 1416.74, 672.12, 1416.63, 682.29 Q 1416.22, 692.46, 1416.50, 702.63 Q 1416.52, 712.80, 1417.22,\
            722.97 Q 1417.53, 733.15, 1416.69, 743.32 Q 1416.89, 753.49, 1416.34, 763.66 Q 1417.38, 773.83, 1416.34, 784.34 Q 1405.86,\
            783.91, 1395.74, 783.80 Q 1385.66, 784.21, 1375.55, 784.59 Q 1365.42, 784.59, 1355.29, 783.36 Q 1345.17, 782.74, 1335.06,\
            783.47 Q 1324.94, 785.57, 1314.83, 784.98 Q 1304.71, 784.69, 1294.59, 785.37 Q 1284.47, 785.63, 1274.35, 785.33 Q 1264.24,\
            786.34, 1254.12, 785.33 Q 1244.00, 785.25, 1233.88, 785.29 Q 1223.77, 784.77, 1213.65, 784.31 Q 1203.53, 784.61, 1193.41,\
            785.10 Q 1183.30, 784.32, 1173.18, 784.16 Q 1163.06, 784.17, 1152.94, 784.54 Q 1142.83, 784.25, 1132.71, 784.87 Q 1122.59,\
            784.59, 1112.47, 785.49 Q 1102.35, 785.64, 1092.24, 786.05 Q 1082.12, 785.65, 1072.00, 785.84 Q 1061.88, 785.63, 1051.77,\
            785.71 Q 1041.65, 785.01, 1031.53, 784.28 Q 1021.41, 784.60, 1011.30, 785.54 Q 1001.18, 785.60, 991.06, 785.51 Q 980.94, 785.64,\
            970.82, 785.71 Q 960.71, 785.94, 950.59, 785.99 Q 940.47, 786.13, 930.35, 785.79 Q 920.24, 785.52, 910.12, 785.26 Q 900.00,\
            785.08, 889.88, 784.25 Q 879.77, 784.14, 869.65, 783.83 Q 859.53, 784.15, 849.41, 784.04 Q 839.29, 784.15, 829.18, 784.38\
            Q 819.06, 783.75, 808.94, 784.42 Q 798.82, 783.87, 788.71, 785.24 Q 778.59, 785.15, 768.47, 784.90 Q 758.35, 785.16, 748.24,\
            785.46 Q 738.12, 785.38, 728.00, 785.49 Q 717.88, 785.38, 707.77, 785.84 Q 697.65, 785.26, 687.53, 785.07 Q 677.41, 784.90,\
            667.29, 784.93 Q 657.18, 785.35, 647.06, 785.67 Q 636.94, 785.36, 626.82, 785.78 Q 616.71, 786.09, 606.59, 786.31 Q 596.47,\
            786.09, 586.35, 786.26 Q 576.24, 785.63, 566.12, 785.26 Q 556.00, 784.56, 545.88, 784.60 Q 535.76, 784.80, 525.65, 785.44\
            Q 515.53, 785.45, 505.41, 785.88 Q 495.29, 784.81, 485.18, 784.33 Q 475.06, 784.34, 464.94, 784.17 Q 454.82, 784.98, 444.71,\
            784.51 Q 434.59, 785.22, 424.47, 784.78 Q 414.35, 785.35, 404.24, 784.98 Q 394.12, 784.94, 384.00, 784.91 Q 373.88, 785.37,\
            363.76, 785.45 Q 353.65, 785.04, 343.53, 785.32 Q 333.41, 785.22, 323.29, 785.81 Q 313.18, 785.58, 303.06, 786.10 Q 292.94,\
            783.92, 282.82, 784.65 Q 272.71, 783.78, 262.59, 783.35 Q 252.47, 784.22, 242.35, 784.77 Q 232.24, 785.01, 222.12, 785.04\
            Q 212.00, 785.15, 201.88, 784.74 Q 191.76, 784.97, 181.65, 785.06 Q 171.53, 784.90, 161.41, 784.54 Q 151.29, 785.26, 141.18,\
            785.12 Q 131.06, 784.90, 120.94, 784.93 Q 110.82, 784.36, 100.71, 784.54 Q 90.59, 784.47, 80.47, 784.33 Q 70.35, 784.55, 60.24,\
            785.05 Q 50.12, 784.78, 39.57, 784.44 Q 39.13, 774.12, 38.94, 763.81 Q 38.72, 753.57, 38.94, 743.35 Q 39.40, 733.15, 39.07,\
            722.98 Q 38.88, 712.81, 39.91, 702.63 Q 40.53, 692.46, 40.14, 682.29 Q 39.37, 672.12, 38.81, 661.95 Q 38.83, 651.78, 39.80,\
            641.61 Q 40.15, 631.43, 39.73, 621.26 Q 39.32, 611.09, 39.40, 600.92 Q 39.75, 590.75, 39.53, 580.58 Q 39.77, 570.41, 39.99,\
            560.24 Q 39.02, 550.07, 39.20, 539.89 Q 39.13, 529.72, 39.17, 519.55 Q 39.69, 509.38, 39.38, 499.21 Q 39.21, 489.04, 39.08,\
            478.87 Q 38.76, 468.70, 38.28, 458.53 Q 39.25, 448.36, 39.01, 438.18 Q 39.38, 428.01, 39.80, 417.84 Q 40.05, 407.67, 39.87,\
            397.50 Q 39.61, 387.33, 39.73, 377.16 Q 38.96, 366.99, 39.28, 356.82 Q 39.13, 346.64, 39.44, 336.47 Q 40.29, 326.30, 40.13,\
            316.13 Q 39.40, 305.96, 39.26, 295.79 Q 39.41, 285.62, 39.66, 275.45 Q 40.07, 265.28, 40.03, 255.11 Q 39.95, 244.93, 39.62,\
            234.76 Q 40.06, 224.59, 39.84, 214.42 Q 40.34, 204.25, 40.83, 194.08 Q 39.76, 183.91, 40.31, 173.74 Q 39.65, 163.57, 40.39,\
            153.39 Q 40.10, 143.22, 39.57, 133.05 Q 38.96, 122.88, 39.48, 112.71 Q 39.95, 102.54, 39.93, 92.37 Q 39.94, 82.20, 38.74,\
            72.03 Q 38.96, 61.86, 39.68, 51.68 Q 39.92, 41.51, 38.73, 31.34 Q 40.00, 21.17, 40.00, 11.00" style=" fill:white;"/>\
         </svg:svg>\
      </div>\
   </div>\
</div>');