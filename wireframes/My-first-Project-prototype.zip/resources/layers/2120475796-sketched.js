rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__2120475796-layer" class="layer" name="__containerId__pageLayer" data-layer-id="2120475796" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-2120475796-layer-207635179" style="position: absolute; left: 5px; top: 0px; width: 1375px; height: 820px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="207635179" data-review-reference-id="207635179">\
            <div class="stencil-wrapper" style="width: 1375px; height: 820px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 820px;width:1375px;" width="1375" height="820">\
                     <svg:g width="1375" height="820"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 12.08, -0.50, 22.16, 0.13 Q 32.24, 1.16, 42.32, 1.26 Q\
                        52.40, 1.41, 62.49, 2.22 Q 72.57, 1.74, 82.65, 2.04 Q 92.73, 1.42, 102.81, 1.53 Q 112.89, 1.98, 122.97, 1.91 Q 133.05, 1.25,\
                        143.13, 0.74 Q 153.21, 1.21, 163.29, 1.36 Q 173.38, 1.25, 183.46, 0.58 Q 193.54, 0.33, 203.62, 0.41 Q 213.70, 0.59, 223.78,\
                        0.57 Q 233.86, 0.44, 243.94, 0.40 Q 254.02, 0.24, 264.10, 0.53 Q 274.18, 0.49, 284.26, 0.39 Q 294.35, 0.35, 304.43, 0.54 Q\
                        314.51, 1.40, 324.59, 0.75 Q 334.67, 0.92, 344.75, 0.62 Q 354.83, 1.06, 364.91, 0.51 Q 374.99, 0.90, 385.07, 1.03 Q 395.15,\
                        0.99, 405.24, 1.39 Q 415.32, 1.52, 425.40, 0.97 Q 435.48, 1.14, 445.56, 1.10 Q 455.64, 1.01, 465.72, 0.77 Q 475.80, 1.34,\
                        485.88, 1.34 Q 495.96, 1.10, 506.04, 1.25 Q 516.12, 1.03, 526.21, 1.18 Q 536.29, 1.36, 546.37, 1.12 Q 556.45, 1.40, 566.53,\
                        1.29 Q 576.61, 0.47, 586.69, 0.42 Q 596.77, 0.40, 606.85, 1.09 Q 616.93, 3.15, 627.01, 2.55 Q 637.10, 1.38, 647.18, 1.72 Q\
                        657.26, 1.86, 667.34, 2.42 Q 677.42, 1.70, 687.50, 2.13 Q 697.58, 1.58, 707.66, 2.44 Q 717.74, 2.41, 727.82, 1.21 Q 737.90,\
                        1.95, 747.98, 1.68 Q 758.07, 1.87, 768.15, 1.69 Q 778.23, 1.31, 788.31, 1.98 Q 798.39, 1.88, 808.47, 2.21 Q 818.55, 1.75,\
                        828.63, 1.56 Q 838.71, 0.79, 848.79, 0.44 Q 858.87, 0.82, 868.96, 1.82 Q 879.04, 0.85, 889.12, 0.82 Q 899.20, 0.78, 909.28,\
                        0.65 Q 919.36, 0.55, 929.44, 0.69 Q 939.52, 0.70, 949.60, 1.60 Q 959.68, 1.42, 969.76, 1.45 Q 979.84, 1.13, 989.93, 1.48 Q\
                        1000.01, 1.60, 1010.09, 1.78 Q 1020.17, 1.22, 1030.25, 1.38 Q 1040.33, 1.70, 1050.41, 1.41 Q 1060.49, 1.43, 1070.57, 1.58\
                        Q 1080.65, 1.70, 1090.73, 1.64 Q 1100.82, 1.50, 1110.90, 1.92 Q 1120.98, 2.25, 1131.06, 1.82 Q 1141.14, 0.43, 1151.22, 0.30\
                        Q 1161.30, 0.63, 1171.38, 0.92 Q 1181.46, 1.04, 1191.54, 0.95 Q 1201.63, 1.20, 1211.71, 0.75 Q 1221.79, 1.99, 1231.87, 2.74\
                        Q 1241.95, 2.87, 1252.03, 2.60 Q 1262.11, 2.46, 1272.19, 1.58 Q 1282.27, 1.94, 1292.35, 1.82 Q 1302.43, 2.92, 1312.52, 2.33\
                        Q 1322.60, 2.35, 1332.68, 2.64 Q 1342.76, 2.09, 1352.84, 1.26 Q 1362.92, 1.15, 1373.14, 1.87 Q 1373.47, 12.04, 1373.71, 22.30\
                        Q 1373.01, 32.60, 1372.69, 42.81 Q 1372.12, 53.01, 1372.53, 63.20 Q 1373.61, 73.40, 1374.22, 83.60 Q 1374.06, 93.80, 1373.19,\
                        104.00 Q 1372.69, 114.20, 1373.34, 124.40 Q 1373.19, 134.60, 1372.87, 144.80 Q 1372.76, 155.00, 1373.50, 165.20 Q 1374.21,\
                        175.40, 1374.07, 185.60 Q 1372.86, 195.80, 1372.94, 206.00 Q 1373.11, 216.20, 1372.63, 226.40 Q 1372.92, 236.60, 1372.94,\
                        246.80 Q 1373.21, 257.00, 1373.48, 267.20 Q 1373.38, 277.40, 1373.35, 287.60 Q 1373.39, 297.80, 1373.81, 308.00 Q 1373.95,\
                        318.20, 1374.24, 328.40 Q 1373.81, 338.60, 1374.24, 348.80 Q 1373.78, 359.00, 1372.76, 369.20 Q 1373.20, 379.40, 1373.81,\
                        389.60 Q 1373.97, 399.80, 1374.01, 410.00 Q 1374.16, 420.20, 1374.26, 430.40 Q 1374.10, 440.60, 1374.01, 450.80 Q 1374.07,\
                        461.00, 1374.22, 471.20 Q 1374.28, 481.40, 1373.97, 491.60 Q 1374.22, 501.80, 1374.14, 512.00 Q 1373.32, 522.20, 1372.30,\
                        532.40 Q 1373.32, 542.60, 1372.85, 552.80 Q 1372.72, 563.00, 1372.87, 573.20 Q 1372.73, 583.40, 1373.26, 593.60 Q 1372.45,\
                        603.80, 1372.39, 614.00 Q 1371.98, 624.20, 1372.29, 634.40 Q 1372.79, 644.60, 1372.13, 654.80 Q 1372.84, 665.00, 1372.72,\
                        675.20 Q 1373.68, 685.40, 1372.87, 695.60 Q 1373.22, 705.80, 1373.39, 716.00 Q 1373.82, 726.20, 1373.89, 736.40 Q 1373.98,\
                        746.60, 1373.92, 756.80 Q 1373.35, 767.00, 1372.95, 777.20 Q 1372.77, 787.40, 1373.16, 797.60 Q 1372.95, 807.80, 1373.07,\
                        818.07 Q 1363.12, 818.59, 1352.90, 818.45 Q 1342.74, 817.66, 1332.67, 817.70 Q 1322.60, 818.16, 1312.51, 816.69 Q 1302.43,\
                        817.77, 1292.35, 817.34 Q 1282.27, 818.78, 1272.19, 819.90 Q 1262.11, 819.31, 1252.03, 820.06 Q 1241.95, 818.86, 1231.87,\
                        819.13 Q 1221.79, 818.91, 1211.71, 818.50 Q 1201.63, 818.57, 1191.54, 818.67 Q 1181.46, 819.20, 1171.38, 819.33 Q 1161.30,\
                        819.14, 1151.22, 818.60 Q 1141.14, 819.69, 1131.06, 818.53 Q 1120.98, 818.27, 1110.90, 818.45 Q 1100.82, 818.77, 1090.73,\
                        818.55 Q 1080.65, 817.89, 1070.57, 818.49 Q 1060.49, 818.59, 1050.41, 818.42 Q 1040.33, 818.62, 1030.25, 817.99 Q 1020.17,\
                        819.14, 1010.09, 819.14 Q 1000.01, 818.90, 989.93, 818.45 Q 979.84, 817.87, 969.76, 819.00 Q 959.68, 818.20, 949.60, 817.88\
                        Q 939.52, 818.43, 929.44, 818.24 Q 919.36, 817.78, 909.28, 817.35 Q 899.20, 817.22, 889.12, 817.47 Q 879.04, 818.10, 868.96,\
                        818.69 Q 858.87, 820.09, 848.79, 819.50 Q 838.71, 818.81, 828.63, 819.18 Q 818.55, 818.60, 808.47, 817.82 Q 798.39, 817.51,\
                        788.31, 818.60 Q 778.23, 818.55, 768.15, 819.23 Q 758.07, 819.10, 747.98, 818.49 Q 737.90, 817.93, 727.82, 817.58 Q 717.74,\
                        817.53, 707.66, 816.86 Q 697.58, 817.91, 687.50, 817.78 Q 677.42, 818.40, 667.34, 819.32 Q 657.26, 819.35, 647.18, 819.72\
                        Q 637.10, 819.91, 627.01, 820.00 Q 616.93, 819.80, 606.85, 819.58 Q 596.77, 819.16, 586.69, 819.12 Q 576.61, 819.24, 566.53,\
                        819.33 Q 556.45, 819.47, 546.37, 818.64 Q 536.29, 819.25, 526.21, 818.93 Q 516.12, 819.46, 506.04, 819.07 Q 495.96, 820.02,\
                        485.88, 819.46 Q 475.80, 820.01, 465.72, 819.24 Q 455.64, 819.16, 445.56, 819.21 Q 435.48, 818.42, 425.40, 818.86 Q 415.32,\
                        818.46, 405.24, 818.99 Q 395.15, 818.92, 385.07, 817.60 Q 374.99, 818.92, 364.91, 817.74 Q 354.83, 819.04, 344.75, 819.28\
                        Q 334.67, 819.11, 324.59, 819.19 Q 314.51, 819.69, 304.43, 819.47 Q 294.35, 820.17, 284.26, 820.22 Q 274.18, 820.07, 264.10,\
                        819.77 Q 254.02, 819.66, 243.94, 819.99 Q 233.86, 819.02, 223.78, 819.29 Q 213.70, 819.67, 203.62, 818.96 Q 193.54, 818.93,\
                        183.46, 819.00 Q 173.38, 818.94, 163.29, 819.03 Q 153.21, 818.78, 143.13, 819.30 Q 133.05, 819.92, 122.97, 820.21 Q 112.89,\
                        820.11, 102.81, 819.66 Q 92.73, 818.26, 82.65, 817.64 Q 72.57, 817.31, 62.49, 818.22 Q 52.40, 818.36, 42.32, 819.38 Q 32.24,\
                        819.53, 22.16, 819.79 Q 12.08, 819.70, 1.15, 818.85 Q 0.98, 808.14, 0.42, 797.83 Q 0.26, 787.52, 0.04, 777.26 Q -0.04, 767.03,\
                        0.39, 756.81 Q 0.81, 746.61, 0.78, 736.40 Q 0.62, 726.20, 0.61, 716.00 Q 0.47, 705.80, 0.92, 695.60 Q 1.13, 685.40, 0.57,\
                        675.20 Q 0.62, 665.00, 1.08, 654.80 Q 0.84, 644.60, 0.81, 634.40 Q 0.72, 624.20, 0.70, 614.00 Q 0.52, 603.80, 0.85, 593.60\
                        Q 0.70, 583.40, 1.72, 573.20 Q 1.20, 563.00, 0.63, 552.80 Q 0.99, 542.60, 1.06, 532.40 Q 1.51, 522.20, 1.52, 512.00 Q 1.63,\
                        501.80, 1.15, 491.60 Q 0.98, 481.40, 0.67, 471.20 Q 0.82, 461.00, 0.60, 450.80 Q 1.55, 440.60, 2.96, 430.40 Q 2.65, 420.20,\
                        2.11, 410.00 Q 2.11, 399.80, 2.37, 389.60 Q 2.32, 379.40, 2.15, 369.20 Q 1.73, 359.00, 1.27, 348.80 Q 2.09, 338.60, 2.39,\
                        328.40 Q 2.01, 318.20, 1.76, 308.00 Q 2.37, 297.80, 1.96, 287.60 Q 1.61, 277.40, 0.95, 267.20 Q 2.09, 257.00, 2.12, 246.80\
                        Q 1.70, 236.60, 1.65, 226.40 Q 1.88, 216.20, 1.50, 206.00 Q 1.31, 195.80, 0.87, 185.60 Q 0.40, 175.40, 0.73, 165.20 Q 1.10,\
                        155.00, 1.37, 144.80 Q 1.55, 134.60, 0.49, 124.40 Q 1.38, 114.20, 1.03, 104.00 Q 1.25, 93.80, 1.36, 83.60 Q 1.13, 73.40, 1.68,\
                        63.20 Q 1.03, 53.00, 0.88, 42.80 Q 1.03, 32.60, 1.57, 22.40 Q 2.00, 12.20, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.49, 5.80, 19.91, 11.39 Q 28.48, 16.75, 37.22, 21.80 Q 45.91,\
                        26.95, 54.51, 32.24 Q 63.16, 37.45, 71.68, 42.88 Q 80.63, 47.57, 89.33, 52.70 Q 98.05, 57.79, 106.69, 63.02 Q 115.27, 68.35,\
                        124.02, 73.39 Q 132.52, 78.87, 140.95, 84.44 Q 149.92, 89.11, 158.66, 94.18 Q 167.43, 99.19, 176.14, 104.29 Q 184.89, 109.33,\
                        193.45, 114.69 Q 201.87, 120.29, 210.82, 125.00 Q 219.28, 130.53, 227.78, 135.99 Q 236.99, 140.27, 245.22, 146.18 Q 253.85,\
                        151.42, 262.53, 156.58 Q 270.90, 162.26, 279.56, 167.45 Q 288.32, 172.47, 297.19, 177.32 Q 305.91, 182.40, 314.59, 187.57\
                        Q 323.49, 192.37, 331.75, 198.23 Q 340.84, 202.69, 349.44, 207.99 Q 357.97, 213.40, 366.98, 218.01 Q 375.39, 223.63, 384.17,\
                        228.62 Q 392.97, 233.57, 401.53, 238.93 Q 410.15, 244.20, 419.31, 248.55 Q 427.96, 253.76, 436.22, 259.62 Q 444.69, 265.14,\
                        453.62, 269.88 Q 462.63, 274.48, 471.15, 279.91 Q 479.81, 285.10, 488.02, 291.05 Q 497.19, 295.38, 506.01, 300.31 Q 514.36,\
                        306.03, 523.42, 310.55 Q 531.57, 316.60, 540.68, 321.04 Q 549.44, 326.06, 558.00, 331.42 Q 566.53, 336.84, 575.10, 342.18\
                        Q 583.50, 347.81, 592.29, 352.79 Q 601.04, 357.84, 609.78, 362.89 Q 618.52, 367.95, 627.12, 373.25 Q 635.86, 378.30, 644.77,\
                        383.07 Q 652.89, 389.17, 661.21, 394.95 Q 670.53, 399.03, 679.40, 403.87 Q 688.03, 409.10, 696.31, 414.93 Q 705.02, 420.05,\
                        713.75, 425.13 Q 722.66, 429.90, 731.68, 434.48 Q 740.36, 439.65, 748.50, 445.72 Q 757.57, 450.23, 765.73, 456.25 Q 774.75,\
                        460.85, 783.32, 466.19 Q 791.66, 471.92, 800.60, 476.65 Q 808.83, 482.55, 818.00, 486.90 Q 827.01, 491.50, 835.75, 496.56\
                        Q 844.80, 501.10, 853.07, 506.94 Q 860.96, 513.44, 869.87, 518.21 Q 878.45, 523.53, 887.01, 528.89 Q 895.87, 533.75, 904.53,\
                        538.94 Q 913.90, 542.95, 922.39, 548.42 Q 930.74, 554.14, 939.40, 559.34 Q 948.16, 564.35, 956.58, 569.96 Q 965.04, 575.49,\
                        973.44, 581.11 Q 982.26, 586.04, 991.55, 590.18 Q 1000.37, 595.10, 1009.14, 600.11 Q 1017.48, 605.84, 1025.86, 611.50 Q 1034.57,\
                        616.62, 1043.68, 621.05 Q 1052.28, 626.35, 1060.33, 632.57 Q 1069.02, 637.71, 1078.38, 641.72 Q 1087.13, 646.77, 1095.88,\
                        651.81 Q 1104.41, 657.22, 1113.29, 662.05 Q 1122.03, 667.10, 1130.66, 672.35 Q 1139.27, 677.62, 1147.96, 682.78 Q 1156.40,\
                        688.33, 1164.96, 693.69 Q 1173.47, 699.13, 1182.26, 704.12 Q 1191.04, 709.11, 1199.75, 714.22 Q 1208.31, 719.58, 1217.34,\
                        724.15 Q 1225.91, 729.50, 1234.66, 734.53 Q 1243.31, 739.74, 1251.83, 745.18 Q 1260.20, 750.86, 1269.19, 755.50 Q 1277.97,\
                        760.48, 1286.81, 765.38 Q 1295.66, 770.25, 1303.67, 776.55 Q 1311.68, 782.82, 1320.57, 787.63 Q 1330.02, 791.51, 1338.76,\
                        796.56 Q 1346.69, 802.97, 1356.13, 806.87 Q 1364.33, 812.83, 1373.00, 818.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 818.00 Q 9.48, 810.80, 18.21, 805.70 Q 26.88, 800.50, 36.07, 796.18 Q\
                        44.23, 790.13, 53.11, 785.28 Q 62.55, 781.37, 71.20, 776.15 Q 79.28, 769.96, 88.00, 764.84 Q 96.67, 759.64, 105.60, 754.89\
                        Q 114.92, 750.77, 123.82, 745.97 Q 132.35, 740.54, 140.89, 735.12 Q 149.20, 729.31, 157.59, 723.65 Q 166.24, 718.41, 175.31,\
                        713.89 Q 184.09, 708.87, 192.69, 703.56 Q 201.30, 698.26, 209.91, 692.96 Q 218.61, 687.81, 227.48, 682.96 Q 236.07, 677.63,\
                        244.70, 672.36 Q 253.30, 667.04, 261.86, 661.66 Q 270.56, 656.51, 279.17, 651.21 Q 287.82, 645.98, 296.52, 640.83 Q 305.33,\
                        635.88, 313.95, 630.58 Q 322.57, 625.30, 331.31, 620.22 Q 340.20, 615.40, 349.20, 610.75 Q 357.97, 605.73, 366.62, 600.48\
                        Q 375.35, 595.39, 384.09, 590.32 Q 392.68, 584.98, 401.40, 579.88 Q 410.16, 574.82, 418.68, 569.37 Q 427.20, 563.91, 435.95,\
                        558.86 Q 444.82, 553.99, 453.57, 548.93 Q 462.63, 544.40, 471.02, 538.72 Q 479.66, 533.47, 488.33, 528.28 Q 496.98, 523.05,\
                        505.36, 517.36 Q 514.07, 512.23, 522.61, 506.81 Q 531.22, 501.51, 540.25, 496.92 Q 548.80, 491.52, 557.50, 486.38 Q 566.48,\
                        481.69, 574.58, 475.54 Q 583.53, 470.80, 591.99, 465.26 Q 601.20, 460.97, 609.71, 455.50 Q 618.29, 450.15, 626.92, 444.89\
                        Q 635.53, 439.59, 644.12, 434.25 Q 652.76, 429.00, 661.55, 424.01 Q 670.44, 419.18, 679.22, 414.17 Q 687.56, 408.42, 696.84,\
                        404.24 Q 705.36, 398.79, 714.08, 393.69 Q 723.10, 389.08, 731.45, 383.33 Q 740.43, 378.67, 749.01, 373.32 Q 757.59, 367.96,\
                        766.20, 362.65 Q 774.87, 357.47, 783.53, 352.24 Q 792.42, 347.41, 801.01, 342.09 Q 809.53, 336.64, 818.44, 331.85 Q 826.61,\
                        325.80, 835.56, 321.08 Q 843.96, 315.43, 853.07, 310.97 Q 861.55, 305.45, 870.37, 300.51 Q 879.63, 296.30, 887.87, 290.38\
                        Q 896.38, 284.91, 905.32, 280.16 Q 914.55, 275.91, 923.19, 270.67 Q 931.96, 265.64, 940.41, 260.07 Q 948.97, 254.67, 957.68,\
                        249.56 Q 966.09, 243.92, 975.17, 239.41 Q 983.41, 233.49, 992.36, 228.76 Q 1000.76, 223.10, 1009.45, 217.94 Q 1018.23, 212.93,\
                        1026.93, 207.77 Q 1035.54, 202.48, 1044.09, 197.09 Q 1052.97, 192.24, 1061.38, 186.61 Q 1070.58, 182.30, 1079.36, 177.28 Q\
                        1088.16, 172.30, 1096.52, 166.59 Q 1104.94, 160.97, 1114.13, 156.65 Q 1123.07, 151.89, 1131.85, 146.89 Q 1139.59, 140.12,\
                        1148.29, 134.98 Q 1157.33, 130.40, 1166.05, 125.29 Q 1174.67, 120.01, 1183.42, 114.95 Q 1192.54, 110.51, 1201.42, 105.66 Q\
                        1209.80, 99.97, 1218.36, 94.58 Q 1227.54, 90.25, 1235.72, 84.23 Q 1244.28, 78.84, 1253.04, 73.80 Q 1261.85, 68.84, 1270.39,\
                        63.43 Q 1279.08, 58.26, 1287.62, 52.85 Q 1296.24, 47.55, 1304.90, 42.34 Q 1313.61, 37.21, 1322.46, 32.31 Q 1330.98, 26.87,\
                        1339.87, 22.04 Q 1348.70, 17.11, 1357.42, 12.00 Q 1366.31, 7.17, 1375.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-707383384" style="position: absolute; left: 170px; top: 0px; width: 970px; height: 120px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="707383384" data-review-reference-id="707383384">\
            <div class="stencil-wrapper" style="width: 970px; height: 120px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 120px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 120px;width:970px;" width="970" height="120" viewBox="0 0 970 120">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="120" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1461639699" style="position: absolute; left: 455px; top: 15px; width: 410px; height: 48px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1461639699" data-review-reference-id="1461639699">\
            <div class="stencil-wrapper" style="width: 410px; height: 48px">\
               <div title="" style="width:415px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p class="none" style="font-size: 32px;"><span style="font-size: 42px;">MONDAY MORNING</span> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1228519717" style="position: absolute; left: 295px; top: 85px; width: 731px; height: 37px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1228519717" data-review-reference-id="1228519717">\
            <div class="stencil-wrapper" style="width: 731px; height: 37px">\
               <div title="" style="width:736px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12"><p><span style="font-size: 32px;">THE OFFICIAL MEDIA BODY OF NIT ROURKELA</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-79367415" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="79367415" data-review-reference-id="79367415">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e191" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e191</title>\
<path class="path1" d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM277.357 531.417q0 6.99 4.926 11.756t11.915 4.846h150.92v152.907q0 6.911 4.846 11.915t11.756 4.926h100.559q6.99 0 11.915-4.926t5.004-11.915v-152.907h150.601q6.911 0 11.915-4.846t4.926-11.756v-100.559q0-6.99-4.926-11.756t-11.915-4.846h-150.601v-150.92q0-6.911-5.004-11.915t-11.915-4.926h-100.559q-6.99 0-11.756 4.926t-4.846 11.915v150.92h-150.92q-6.911 0-11.915 4.846t-4.926 11.756v100.559z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e368" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e368</title>\
<path class="path1" d="M181.008 679.716v-364.035q0-54.969 38.921-93.729t93.491-38.682h364.035q54.969 0 93.729 38.682t38.682 93.729v364.035q0 54.969-38.682 93.65t-93.729 38.762h-364.035q-54.57 0-93.491-38.762t-38.921-93.65zM247.255 712.839q0 13.583 9.77 23.273t23.273 9.77h430.281q13.583 0 23.353-9.77t9.77-23.273v-430.281q0-13.583-9.77-23.353t-23.353-9.77h-430.281q-13.502 0-23.273 9.77t-9.77 23.353v430.281zM345.513 425.852q4.291-10.883 17.554-10.883h264.745q13.264 0 17.554 11.36t-3.972 22.4l-126.375 175.384q-7.944 10.961-19.539 11.756t-19.539-10.089l-126.455-178.086q-8.262-10.883-3.972-21.844z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path class="path1" d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e046" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e046</title>\
<path class="path1" d="M114.842 845.172v-529.492h761.193v529.492q0 13.583-9.77 23.353t-23.273 9.77h-695.028q-13.583 0-23.353-9.77t-9.77-23.353zM114.842 282.557v-99.289q0-13.583 9.77-23.353t23.353-9.77h66.167v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.044q13.583 0 23.353 9.77t9.77 23.353v33.044h364.035v-33.044q0-13.583 9.77-23.353t23.353-9.77h33.124q13.583 0 23.273 9.77t9.77 23.353v33.044h66.246q13.583 0 23.273 9.77t9.77 23.353v99.289h-761.193zM181.008 812.128h99.289v-99.289h-99.289v99.289zM181.008 679.716h99.289v-99.289h-99.289v99.289zM181.008 547.303h99.289v-99.289h-99.289v99.289zM313.421 812.128h99.289v-99.289h-99.289v99.289zM313.421 679.716h99.289v-99.289h-99.289v99.289zM313.421 547.303h99.289v-99.289h-99.289v99.289zM445.833 812.128h99.289v-99.289h-99.289v99.289zM445.833 679.716h99.289v-99.289h-99.289v99.289zM445.833 547.303h99.289v-99.289h-99.289v99.289zM578.167 812.128h99.289v-99.289h-99.289v99.289zM578.167 679.716h99.289v-99.289h-99.289v99.289zM578.167 547.303h99.289v-99.289h-99.289v99.289zM710.579 812.128h99.289v-99.289h-99.289v99.289zM710.579 679.716h99.289v-99.289h-99.289v99.289zM710.579 547.303h99.289v-99.289h-99.289v99.289z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e212" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e212</title>\
<path class="path1" d="M181.008 563.586v-164.821q0-6.674 5.163-11.756t11.756-5.163h280.95v-171.413q0-6.99 3.972-8.817t9.294 2.463l345.208 266.812q5.639 4.291 5.639 10.247t-5.639 10.247l-344.893 267.129q-5.639 3.972-9.612 2.145t-3.972-8.817v-171.413h-280.95q-6.592 0-11.756-5.164t-5.163-11.677z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-176780162" style="position: absolute; left: 170px; top: 120px; width: 970px; height: 60px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="176780162" data-review-reference-id="176780162">\
            <div class="stencil-wrapper" style="width: 970px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 60px; width:970px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 60px;width:970px;" width="970" height="60" viewBox="0 0 970 60">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="970" height="60" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-255672602" style="position: absolute; left: 240px; top: 135px; width: 52px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="255672602" data-review-reference-id="255672602">\
            <div class="stencil-wrapper" style="width: 52px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:56px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="56" height="34" viewBox="-2 -2 56 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 3.54, 27.42, 2.56, 27.44 Q 1.97, 26.67, 0.66, 26.11 Q 0.62, 14.06,\
                        1.30, 2.05 Q 1.69, 1.06, 2.05, 0.04 Q 2.52, -1.14, 4.10, -0.69 Q 15.46, -1.25, 27.04, -0.42 Q 38.48, -1.64, 50.01, -1.06 Q\
                        50.87, -0.13, 51.79, 0.24 Q 53.13, 0.52, 53.16, 1.95 Q 52.32, 14.10, 52.46, 25.91 Q 52.45, 26.99, 52.71, 28.63 Q 51.08, 28.61,\
                        49.88, 28.62 Q 38.46, 28.75, 27.02, 29.31 Q 15.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="26" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Home</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 52px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-2120475796-layer-255672602\', \'873198243\', {"button":"left","id":"469899381","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction425964047","options":"reloadOnly","target":"page353048828","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-2120475796-layer-580256433" style="position: absolute; left: 340px; top: 135px; width: 550px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="580256433" data-review-reference-id="580256433">\
            <div class="stencil-wrapper" style="width: 550px; height: 30px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 30px;width:550px;" width="550" height="30">\
                     <svg:g id="__containerId__-2120475796-layer-580256433svg" width="550" height="30"><svg:path id="__containerId__-2120475796-layer-580256433_input_svg_border" class=" svg_unselected_element" d="M 2.00, 2.00\
                        Q 12.11, 1.94, 22.22, 1.90 Q 32.33, 1.98, 42.44, 1.82 Q 52.56, 2.01, 62.67, 1.96 Q 72.78, 1.85, 82.89, 1.73 Q 93.00, 1.32,\
                        103.11, 2.09 Q 113.22, 2.84, 123.33, 1.98 Q 133.44, 2.13, 143.56, 2.09 Q 153.67, 1.66, 163.78, 2.40 Q 173.89, 0.99, 184.00,\
                        1.47 Q 194.11, 1.15, 204.22, 1.79 Q 214.33, 2.41, 224.44, 2.79 Q 234.56, 1.78, 244.67, 1.27 Q 254.78, 1.28, 264.89, 1.24 Q\
                        275.00, 1.04, 285.11, 1.27 Q 295.22, 0.60, 305.33, 1.02 Q 315.44, 2.58, 325.56, 2.86 Q 335.67, 1.18, 345.78, 1.41 Q 355.89,\
                        1.14, 366.00, 2.73 Q 376.11, 1.91, 386.22, 1.80 Q 396.33, 1.17, 406.44, 1.17 Q 416.56, 1.23, 426.67, 1.49 Q 436.78, 1.77,\
                        446.89, 1.45 Q 457.00, 0.73, 467.11, 0.36 Q 477.22, 0.28, 487.33, 0.53 Q 497.44, 0.88, 507.56, 1.36 Q 517.67, 1.52, 527.78,\
                        1.60 Q 537.89, 2.24, 547.92, 2.08 Q 547.42, 15.19, 547.67, 27.67 Q 538.04, 28.56, 527.81, 28.28 Q 517.75, 29.72, 507.59, 29.38\
                        Q 497.46, 28.93, 487.33, 27.64 Q 477.22, 26.06, 467.11, 27.04 Q 457.00, 28.20, 446.89, 29.44 Q 436.78, 29.79, 426.67, 29.28\
                        Q 416.56, 30.20, 406.44, 29.73 Q 396.33, 28.07, 386.22, 26.72 Q 376.11, 26.60, 366.00, 27.49 Q 355.89, 28.25, 345.78, 28.51\
                        Q 335.67, 29.62, 325.56, 29.53 Q 315.44, 29.18, 305.33, 29.04 Q 295.22, 29.02, 285.11, 28.96 Q 275.00, 28.82, 264.89, 28.60\
                        Q 254.78, 28.10, 244.67, 28.33 Q 234.56, 28.04, 224.44, 28.42 Q 214.33, 28.82, 204.22, 29.64 Q 194.11, 29.95, 184.00, 30.12\
                        Q 173.89, 30.23, 163.78, 30.28 Q 153.67, 29.96, 143.56, 29.58 Q 133.44, 28.81, 123.33, 29.17 Q 113.22, 29.45, 103.11, 28.35\
                        Q 93.00, 28.62, 82.89, 29.12 Q 72.78, 28.45, 62.67, 29.05 Q 52.56, 28.81, 42.44, 27.97 Q 32.33, 27.65, 22.22, 28.65 Q 12.11,\
                        28.80, 1.99, 28.01 Q 2.00, 15.00, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-2120475796-layer-580256433_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 2.79,\
                        23.15, 3.18 Q 33.22, 2.69, 43.30, 3.04 Q 53.37, 1.68, 63.44, 1.17 Q 73.52, 1.52, 83.59, 1.74 Q 93.67, 1.87, 103.74, 1.43 Q\
                        113.81, 1.42, 123.89, 1.21 Q 133.96, 0.89, 144.04, 0.88 Q 154.11, 2.03, 164.19, 0.74 Q 174.26, 1.78, 184.33, 1.80 Q 194.41,\
                        1.14, 204.48, 1.05 Q 214.56, 1.08, 224.63, 0.98 Q 234.70, 0.83, 244.78, 1.13 Q 254.85, 0.98, 264.93, 1.03 Q 275.00, 0.78,\
                        285.07, 1.09 Q 295.15, 2.75, 305.22, 2.89 Q 315.30, 2.40, 325.37, 1.11 Q 335.44, 2.40, 345.52, 2.44 Q 355.59, 2.38, 365.67,\
                        2.52 Q 375.74, 1.78, 385.81, 1.54 Q 395.89, 1.59, 405.96, 1.79 Q 416.04, 1.73, 426.11, 1.65 Q 436.18, 1.48, 446.26, 1.32 Q\
                        456.33, 1.29, 466.41, 1.84 Q 476.48, 1.81, 486.56, 1.94 Q 496.63, 2.19, 506.70, 1.75 Q 516.78, 1.79, 526.85, 1.89 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-2120475796-layer-580256433_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/><svg:path id="__containerId__-2120475796-layer-580256433_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q 13.07, 3.62,\
                        23.15, 3.35 Q 33.22, 3.00, 43.30, 2.54 Q 53.37, 2.00, 63.44, 1.35 Q 73.52, 1.46, 83.59, 1.32 Q 93.67, 1.26, 103.74, 1.23 Q\
                        113.81, 1.04, 123.89, 1.11 Q 133.96, 1.66, 144.04, 2.02 Q 154.11, 1.97, 164.19, 1.98 Q 174.26, 1.09, 184.33, 1.11 Q 194.41,\
                        1.40, 204.48, 1.52 Q 214.56, 1.55, 224.63, 1.62 Q 234.70, 0.99, 244.78, 1.15 Q 254.85, 1.70, 264.93, 1.86 Q 275.00, 2.61,\
                        285.07, 2.76 Q 295.15, 2.59, 305.22, 2.54 Q 315.30, 2.26, 325.37, 2.59 Q 335.44, 1.42, 345.52, 1.16 Q 355.59, 1.56, 365.67,\
                        1.28 Q 375.74, 1.80, 385.81, 1.95 Q 395.89, 2.09, 405.96, 1.97 Q 416.04, 2.59, 426.11, 2.00 Q 436.18, 3.03, 446.26, 2.58 Q\
                        456.33, 1.69, 466.41, 1.68 Q 476.48, 1.53, 486.56, 2.25 Q 496.63, 2.62, 506.70, 2.53 Q 516.78, 3.19, 526.85, 2.40 Q 536.93,\
                        3.00, 547.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-2120475796-layer-580256433_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q 3.00, 15.00,\
                        3.00, 27.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><input id="__containerId__-2120475796-layer-580256433input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-2120475796-layer-580256433_input_svg_border\',\'__containerId__-2120475796-layer-580256433_line1\',\'__containerId__-2120475796-layer-580256433_line2\',\'__containerId__-2120475796-layer-580256433_line3\',\'__containerId__-2120475796-layer-580256433_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-2120475796-layer-580256433_input_svg_border\',\'__containerId__-2120475796-layer-580256433_line1\',\'__containerId__-2120475796-layer-580256433_line2\',\'__containerId__-2120475796-layer-580256433_line3\',\'__containerId__-2120475796-layer-580256433_line4\'))" value="Search Box" style="width:543px;height:28px;padding: 0px;" type="text" /></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-446376350" style="position: absolute; left: 955px; top: 135px; width: 50px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="446376350" data-review-reference-id="446376350">\
            <div class="stencil-wrapper" style="width: 50px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:54px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="54" height="34" viewBox="-2 -2 54 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 2.38, 29.75, 0.96, 29.04 Q 0.31, 27.85, -0.45, 26.46 Q -0.32,\
                        14.20, -0.19, 1.80 Q 0.69, 0.73, 1.03, -0.85 Q 2.25, -1.49, 3.61, -2.23 Q 14.80, -2.33, 25.91, -2.29 Q 36.97, -1.91, 48.07,\
                        -1.32 Q 49.26, -1.23, 50.67, -0.74 Q 51.32, 0.38, 51.84, 1.73 Q 51.82, 13.88, 51.66, 26.11 Q 50.76, 27.09, 50.57, 28.50 Q\
                        49.57, 29.25, 48.37, 30.16 Q 37.18, 30.19, 26.06, 29.80 Q 15.00, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="25" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Login</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-78246833" style="position: absolute; left: 1045px; top: 135px; width: 59px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="78246833" data-review-reference-id="78246833">\
            <div class="stencil-wrapper" style="width: 59px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:63px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="63" height="34" viewBox="-2 -2 63 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 1.92, 30.65, 0.59, 29.41 Q -0.07, 28.12, -0.42, 26.45 Q -0.51,\
                        14.22, -0.41, 1.76 Q 0.53, 0.68, 1.78, -0.19 Q 2.62, -1.00, 3.81, -1.58 Q 17.13, -1.79, 30.42, -2.07 Q 43.71, -2.13, 57.23,\
                        -2.04 Q 58.09, -0.75, 59.30, -0.33 Q 59.92, 0.68, 60.47, 1.85 Q 60.76, 13.89, 60.65, 26.11 Q 60.23, 27.24, 59.70, 28.62 Q\
                        58.61, 29.32, 57.34, 30.05 Q 43.94, 30.23, 30.57, 30.00 Q 17.25, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="29.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1.5em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">SignUp</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-2001994705" style="position: absolute; left: 850px; top: 135px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="2001994705" data-review-reference-id="2001994705">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1202713320" style="position: absolute; left: 0px; top: 778px; width: 1375px; height: 40px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1202713320" data-review-reference-id="1202713320">\
            <div class="stencil-wrapper" style="width: 1375px; height: 40px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 40px; width:1375px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 40px;width:1375px;" width="1375" height="40" viewBox="0 0 1375 40">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="1375" height="40" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-762553459" style="position: absolute; left: 455px; top: 783px; width: 403px; height: 20px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="762553459" data-review-reference-id="762553459">\
            <div class="stencil-wrapper" style="width: 403px; height: 20px">\
               <div title="" style="width:408px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline32"><p class="none" style="font-size: 18px;">Fixed footer for ASK A QUESTION AND FORUM </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-textinput195912019" style="position: absolute; left: 210px; top: 210px; width: 865px; height: 55px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput195912019" data-review-reference-id="textinput195912019">\
            <div class="stencil-wrapper" style="width: 865px; height: 55px">\
               <div>\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" style="height: 55px;width:865px;" width="865" height="55">\
                     <svg:g id="__containerId__-2120475796-layer-textinput195912019svg" width="865" height="55"><svg:path id="__containerId__-2120475796-layer-textinput195912019_input_svg_border" class=" svg_unselected_element" d="M 2.00,\
                        2.00 Q 12.01, 0.26, 22.02, 1.06 Q 32.03, 1.38, 42.05, 2.15 Q 52.06, 2.24, 62.07, 2.02 Q 72.08, 2.30, 82.09, 2.09 Q 92.10,\
                        2.08, 102.12, 2.32 Q 112.13, 2.30, 122.14, 1.85 Q 132.15, 1.42, 142.16, 1.30 Q 152.17, 0.87, 162.19, 1.00 Q 172.20, 0.64,\
                        182.21, 1.70 Q 192.22, 0.87, 202.23, 2.02 Q 212.24, 1.63, 222.26, 2.39 Q 232.27, 1.93, 242.28, 1.58 Q 252.29, 1.30, 262.30,\
                        0.63 Q 272.31, 1.47, 282.33, 1.15 Q 292.34, 1.05, 302.35, 0.61 Q 312.36, 0.19, 322.37, 0.29 Q 332.38, 0.07, 342.40, -0.21\
                        Q 352.41, 1.28, 362.42, 1.32 Q 372.43, 0.54, 382.44, 0.73 Q 392.45, 0.82, 402.47, 2.52 Q 412.48, 2.04, 422.49, 1.06 Q 432.50,\
                        1.08, 442.51, 1.90 Q 452.52, 2.12, 462.53, 2.11 Q 472.55, 1.95, 482.56, 1.80 Q 492.57, 1.89, 502.58, 1.84 Q 512.59, 1.04,\
                        522.60, 0.78 Q 532.62, 0.96, 542.63, 1.40 Q 552.64, 1.40, 562.65, 1.59 Q 572.66, 1.05, 582.67, 1.90 Q 592.69, 1.88, 602.70,\
                        1.21 Q 612.71, 0.87, 622.72, 0.75 Q 632.73, 0.74, 642.74, 0.53 Q 652.76, 0.12, 662.77, -0.01 Q 672.78, 0.43, 682.79, 0.06\
                        Q 692.80, 0.61, 702.81, 1.80 Q 712.83, 2.13, 722.84, 1.49 Q 732.85, 1.06, 742.86, 1.42 Q 752.87, 1.02, 762.88, 2.43 Q 772.90,\
                        1.51, 782.91, 1.07 Q 792.92, 1.45, 802.93, 2.08 Q 812.94, 2.15, 822.95, 1.20 Q 832.97, 0.84, 842.98, 0.92 Q 852.99, 1.02,\
                        863.48, 1.53 Q 863.56, 14.56, 862.88, 27.52 Q 863.13, 40.24, 863.15, 53.15 Q 853.11, 53.38, 843.03, 53.41 Q 833.03, 54.02,\
                        822.97, 53.47 Q 812.95, 53.60, 802.94, 53.70 Q 792.92, 53.87, 782.91, 54.11 Q 772.90, 53.94, 762.89, 54.36 Q 752.87, 54.90,\
                        742.86, 55.03 Q 732.85, 54.52, 722.84, 54.50 Q 712.83, 54.26, 702.81, 54.13 Q 692.80, 54.30, 682.79, 53.91 Q 672.78, 54.11,\
                        662.77, 54.04 Q 652.76, 53.92, 642.74, 53.01 Q 632.73, 53.28, 622.72, 54.32 Q 612.71, 53.55, 602.70, 53.48 Q 592.69, 52.94,\
                        582.67, 53.05 Q 572.66, 53.94, 562.65, 53.36 Q 552.64, 53.21, 542.63, 53.34 Q 532.62, 53.24, 522.60, 53.33 Q 512.59, 53.76,\
                        502.58, 54.34 Q 492.57, 53.60, 482.56, 54.15 Q 472.55, 54.87, 462.53, 54.96 Q 452.52, 54.59, 442.51, 54.88 Q 432.50, 53.94,\
                        422.49, 53.95 Q 412.48, 53.85, 402.47, 54.48 Q 392.45, 53.84, 382.44, 54.60 Q 372.43, 54.36, 362.42, 54.43 Q 352.41, 54.09,\
                        342.40, 54.50 Q 332.38, 53.92, 322.37, 54.54 Q 312.36, 54.47, 302.35, 54.00 Q 292.34, 54.38, 282.33, 53.12 Q 272.31, 53.16,\
                        262.30, 53.55 Q 252.29, 53.15, 242.28, 52.33 Q 232.27, 52.40, 222.26, 53.79 Q 212.24, 53.85, 202.23, 53.48 Q 192.22, 53.53,\
                        182.21, 53.59 Q 172.20, 53.61, 162.19, 53.52 Q 152.17, 53.48, 142.16, 53.73 Q 132.15, 54.21, 122.14, 54.71 Q 112.13, 54.39,\
                        102.12, 54.45 Q 92.10, 54.59, 82.09, 54.62 Q 72.08, 54.55, 62.07, 54.92 Q 52.06, 55.02, 42.05, 55.19 Q 32.03, 54.75, 22.02,\
                        54.44 Q 12.01, 54.47, 1.81, 53.19 Q 1.67, 40.36, 1.18, 27.62 Q 2.00, 14.75, 2.00, 2.00" style=" fill:white;"/><svg:path id="__containerId__-2120475796-layer-textinput195912019_line1" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.23, 2.55, 23.45, 2.48 Q 33.68, 2.39, 43.90, 2.62 Q 54.13, 2.46, 64.36, 2.04 Q 74.58, 2.85, 84.81, 2.39 Q 95.04, 2.75, 105.26,\
                        2.47 Q 115.49, 2.37, 125.71, 2.31 Q 135.94, 2.63, 146.17, 2.56 Q 156.39, 2.69, 166.62, 2.08 Q 176.85, 2.08, 187.07, 2.92 Q\
                        197.30, 3.11, 207.52, 2.89 Q 217.75, 2.52, 227.98, 2.87 Q 238.20, 2.62, 248.43, 2.66 Q 258.65, 2.21, 268.88, 2.62 Q 279.11,\
                        2.14, 289.33, 2.45 Q 299.56, 3.00, 309.79, 1.99 Q 320.01, 1.78, 330.24, 0.69 Q 340.46, 1.83, 350.69, 0.92 Q 360.92, 0.93,\
                        371.14, 1.71 Q 381.37, 2.37, 391.60, 1.79 Q 401.82, 2.49, 412.05, 1.84 Q 422.27, 1.76, 432.50, 2.43 Q 442.73, 2.15, 452.95,\
                        2.66 Q 463.18, 2.64, 473.40, 2.98 Q 483.63, 3.02, 493.86, 3.06 Q 504.08, 2.63, 514.31, 1.81 Q 524.54, 2.30, 534.76, 2.34 Q\
                        544.99, 2.26, 555.21, 1.74 Q 565.44, 1.19, 575.67, 1.41 Q 585.89, 1.72, 596.12, 1.62 Q 606.35, 0.96, 616.57, 1.19 Q 626.80,\
                        1.80, 637.02, 1.90 Q 647.25, 1.20, 657.48, 0.59 Q 667.70, 1.35, 677.93, 2.77 Q 688.16, 2.36, 698.38, 1.42 Q 708.61, 1.31,\
                        718.83, 1.60 Q 729.06, 1.50, 739.29, 1.76 Q 749.51, 1.64, 759.74, 2.09 Q 769.96, 2.33, 780.19, 2.12 Q 790.42, 2.11, 800.64,\
                        2.95 Q 810.87, 2.62, 821.10, 2.03 Q 831.32, 1.45, 841.55, 2.09 Q 851.77, 3.00, 862.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-2120475796-layer-textinput195912019_line2" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        4.24, 15.25, 3.63, 27.50 Q 3.00, 39.75, 3.00, 52.00" style=" fill:none;"/><svg:path id="__containerId__-2120475796-layer-textinput195912019_line3" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        13.23, 1.37, 23.45, 2.02 Q 33.68, 2.45, 43.90, 2.38 Q 54.13, 2.05, 64.36, 2.39 Q 74.58, 2.09, 84.81, 1.71 Q 95.04, 2.17, 105.26,\
                        2.01 Q 115.49, 1.98, 125.71, 2.64 Q 135.94, 2.69, 146.17, 2.24 Q 156.39, 2.54, 166.62, 1.29 Q 176.85, 2.39, 187.07, 1.92 Q\
                        197.30, 2.04, 207.52, 2.23 Q 217.75, 2.62, 227.98, 2.20 Q 238.20, 2.47, 248.43, 2.97 Q 258.65, 2.43, 268.88, 2.58 Q 279.11,\
                        2.24, 289.33, 2.12 Q 299.56, 2.89, 309.79, 3.32 Q 320.01, 2.55, 330.24, 0.71 Q 340.46, 2.63, 350.69, 2.60 Q 360.92, 2.98,\
                        371.14, 1.80 Q 381.37, 2.05, 391.60, 2.11 Q 401.82, 2.28, 412.05, 2.39 Q 422.27, 1.91, 432.50, 3.46 Q 442.73, 2.67, 452.95,\
                        2.80 Q 463.18, 2.66, 473.40, 2.91 Q 483.63, 3.13, 493.86, 2.72 Q 504.08, 2.32, 514.31, 1.62 Q 524.54, 2.80, 534.76, 2.69 Q\
                        544.99, 2.76, 555.21, 3.12 Q 565.44, 3.21, 575.67, 2.57 Q 585.89, 2.44, 596.12, 2.33 Q 606.35, 2.03, 616.57, 3.03 Q 626.80,\
                        2.82, 637.02, 3.08 Q 647.25, 2.70, 657.48, 1.59 Q 667.70, 2.28, 677.93, 2.86 Q 688.16, 2.45, 698.38, 1.44 Q 708.61, 2.40,\
                        718.83, 2.03 Q 729.06, 1.98, 739.29, 1.64 Q 749.51, 1.24, 759.74, 1.38 Q 769.96, 1.52, 780.19, 1.37 Q 790.42, 1.28, 800.64,\
                        2.03 Q 810.87, 2.40, 821.10, 2.26 Q 831.32, 1.50, 841.55, 1.49 Q 851.77, 3.00, 862.00, 3.00" style=" fill:none;"/><svg:path id="__containerId__-2120475796-layer-textinput195912019_line4" class=" svg_unselected_element" d="M 3.00, 3.00 Q\
                        3.37, 15.25, 2.71, 27.50 Q 3.00, 39.75, 3.00, 52.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
                  <div style="position:absolute;left: 6px; top: 1px;" title=""><textarea id="__containerId__-2120475796-layer-textinput195912019input" onblur="rabbit.facade.raiseEvent(rabbit.events.svgBlur, new Array(\'__containerId__-2120475796-layer-textinput195912019_input_svg_border\',\'__containerId__-2120475796-layer-textinput195912019_line1\',\'__containerId__-2120475796-layer-textinput195912019_line2\',\'__containerId__-2120475796-layer-textinput195912019_line3\',\'__containerId__-2120475796-layer-textinput195912019_line4\'))" onfocus="rabbit.facade.raiseEvent(rabbit.events.svgFocus, new Array(\'__containerId__-2120475796-layer-textinput195912019_input_svg_border\',\'__containerId__-2120475796-layer-textinput195912019_line1\',\'__containerId__-2120475796-layer-textinput195912019_line2\',\'__containerId__-2120475796-layer-textinput195912019_line3\',\'__containerId__-2120475796-layer-textinput195912019_line4\'))" rows="" cols="" style="width:858px;height:49px;">*Entered query *</textarea></div>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1306687622" style="position: absolute; left: 1025px; top: 220px; width: 39px; height: 39px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1306687622" data-review-reference-id="1306687622">\
            <div class="stencil-wrapper" style="width: 39px; height: 39px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:39px;height:39px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="39" height="39" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e028-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1587265112" style="position: absolute; left: 175px; top: 287px; width: 700px; height: 444px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1587265112" data-review-reference-id="1587265112">\
            <div class="stencil-wrapper" style="width: 700px; height: 444px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 444px; width:700px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 444px;width:700px;" width="700" height="444" viewBox="0 0 700 444">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="700" height="444" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1944081321" style="position: absolute; left: 875px; top: 287px; width: 270px; height: 442px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1944081321" data-review-reference-id="1944081321">\
            <div class="stencil-wrapper" style="width: 270px; height: 442px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 442px; width:270px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 442px;width:270px;" width="270" height="442" viewBox="0 0 270 442">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="270" height="442" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1878280266" style="position: absolute; left: 910px; top: 327px; width: 188px; height: 184px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1878280266" data-review-reference-id="1878280266">\
            <div class="stencil-wrapper" style="width: 188px; height: 184px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textblock2"><p style="font-size: 14px;"><span style="font-size: 18px;"><strong>POLL</strong><br /><br />Lorem ipsum dolor sit amet, consetetur\
                        sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-578471091" style="position: absolute; left: 695px; top: 362px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="578471091" data-review-reference-id="578471091">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105">\
                     <svg:g width="160" height="105"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.14, 1.74, 24.29, 1.42 Q 35.43, 0.87, 46.57, 0.69 Q\
                        57.71, 0.61, 68.86, 0.98 Q 80.00, 0.97, 91.14, 1.07 Q 102.29, 0.88, 113.43, 0.93 Q 124.57, 1.20, 135.71, 0.77 Q 146.86, 0.23,\
                        159.16, 0.84 Q 159.80, 11.50, 159.64, 21.97 Q 159.57, 32.20, 158.90, 42.37 Q 159.61, 52.47, 159.74, 62.59 Q 159.70, 72.69,\
                        159.88, 82.80 Q 160.04, 92.90, 158.85, 103.85 Q 147.31, 104.36, 135.94, 104.55 Q 124.70, 104.95, 113.50, 105.25 Q 102.32,\
                        105.39, 91.16, 105.14 Q 80.01, 104.71, 68.86, 104.22 Q 57.72, 104.69, 46.57, 104.54 Q 35.43, 103.29, 24.29, 103.53 Q 13.14,\
                        103.86, 1.52, 103.48 Q 1.02, 93.23, 0.82, 82.97 Q 0.70, 72.79, 0.58, 62.65 Q 0.37, 52.53, 0.39, 42.41 Q 0.59, 32.31, 0.53,\
                        22.20 Q 2.00, 12.10, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.61, 6.15, 20.40, 11.58 Q 28.81, 17.58, 37.71, 22.83 Q 46.34,\
                        28.50, 54.45, 34.98 Q 63.95, 39.30, 72.44, 45.18 Q 81.10, 50.80, 89.77, 56.40 Q 97.70, 63.16, 106.08, 69.21 Q 115.22, 74.10,\
                        124.38, 78.94 Q 133.07, 84.51, 141.47, 90.53 Q 149.33, 97.39, 158.00, 103.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 103.00 Q 10.09, 96.32, 19.30, 91.39 Q 28.37, 86.23, 37.28, 80.82 Q 45.73,\
                        74.70, 54.38, 68.89 Q 63.03, 63.07, 71.88, 57.57 Q 80.87, 52.29, 89.59, 46.60 Q 98.16, 40.65, 106.95, 35.07 Q 115.65, 29.33,\
                        124.15, 23.29 Q 132.71, 17.33, 141.76, 12.15 Q 151.22, 7.61, 160.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-2053049038" style="position: absolute; left: 475px; top: 362px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="2053049038" data-review-reference-id="2053049038">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105">\
                     <svg:g width="160" height="105"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.14, -0.05, 24.29, -0.22 Q 35.43, -0.31, 46.57, -0.25\
                        Q 57.71, 0.13, 68.86, -0.11 Q 80.00, -0.27, 91.14, -0.19 Q 102.29, 0.24, 113.43, 0.13 Q 124.57, -0.09, 135.71, 0.17 Q 146.86,\
                        0.56, 158.57, 1.43 Q 159.46, 11.61, 159.67, 21.96 Q 159.48, 32.20, 159.36, 42.36 Q 159.66, 52.47, 159.22, 62.59 Q 159.42,\
                        72.69, 159.52, 82.80 Q 159.54, 92.90, 158.56, 103.56 Q 147.24, 104.14, 135.79, 103.55 Q 124.56, 102.87, 113.42, 102.78 Q 102.30,\
                        103.82, 91.15, 104.28 Q 80.01, 104.36, 68.86, 104.53 Q 57.72, 104.64, 46.57, 104.78 Q 35.43, 104.80, 24.29, 104.45 Q 13.14,\
                        104.80, 1.01, 103.99 Q 0.81, 93.30, 0.98, 82.95 Q 0.66, 72.79, 0.09, 62.66 Q 0.17, 52.53, 0.16, 42.41 Q 0.62, 32.31, 0.73,\
                        22.20 Q 2.00, 12.10, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.11, 6.93, 19.84, 12.45 Q 28.67, 17.80, 37.15, 23.70 Q 45.63,\
                        29.60, 54.67, 34.64 Q 62.97, 40.81, 71.70, 46.32 Q 80.31, 52.02, 88.80, 57.90 Q 97.72, 63.13, 106.69, 68.27 Q 114.75, 74.82,\
                        123.33, 80.56 Q 132.03, 86.13, 140.64, 91.81 Q 149.33, 97.39, 158.00, 103.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 103.00 Q 9.32, 95.11, 18.32, 89.85 Q 27.30, 84.55, 36.16, 79.06 Q 45.09,\
                        73.70, 53.98, 68.26 Q 62.85, 62.79, 71.67, 57.25 Q 80.43, 51.61, 89.11, 45.84 Q 97.83, 40.14, 106.88, 34.96 Q 115.95, 29.80,\
                        124.51, 23.85 Q 133.35, 18.33, 141.85, 12.30 Q 151.22, 7.61, 160.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1084387657" style="position: absolute; left: 255px; top: 362px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1084387657" data-review-reference-id="1084387657">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105">\
                     <svg:g width="160" height="105"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.14, 1.60, 24.29, 1.72 Q 35.43, 1.68, 46.57, 2.09 Q\
                        57.71, 2.08, 68.86, 1.96 Q 80.00, 2.56, 91.14, 2.35 Q 102.29, 2.33, 113.43, 2.18 Q 124.57, 1.95, 135.71, 2.16 Q 146.86, 2.11,\
                        157.68, 2.32 Q 158.24, 12.02, 157.58, 22.26 Q 157.20, 32.35, 157.45, 42.42 Q 157.34, 52.51, 157.61, 62.60 Q 157.79, 72.70,\
                        157.55, 82.80 Q 156.38, 92.90, 158.10, 103.10 Q 146.56, 102.11, 135.75, 103.23 Q 124.59, 103.21, 113.43, 103.13 Q 102.31,\
                        104.40, 91.16, 104.92 Q 80.00, 104.25, 68.86, 103.82 Q 57.72, 104.32, 46.57, 103.12 Q 35.43, 103.64, 24.29, 103.79 Q 13.14,\
                        103.83, 1.57, 103.43 Q 1.05, 93.22, 1.18, 82.92 Q 2.52, 72.67, 1.83, 62.61 Q 2.40, 52.49, 1.89, 42.40 Q 2.92, 32.30, 2.94,\
                        22.20 Q 2.00, 12.10, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.72, 5.99, 20.22, 11.86 Q 28.85, 17.53, 37.27, 23.52 Q 45.93,\
                        29.13, 54.59, 34.76 Q 63.22, 40.43, 71.24, 47.04 Q 80.19, 52.20, 88.85, 57.83 Q 97.52, 63.43, 106.29, 68.89 Q 115.11, 74.26,\
                        123.99, 79.54 Q 132.62, 85.20, 140.65, 91.80 Q 149.33, 97.39, 158.00, 103.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 103.00 Q 9.68, 95.67, 18.45, 90.04 Q 27.14, 84.30, 35.90, 78.67 Q 44.67,\
                        73.04, 53.54, 67.58 Q 62.32, 61.97, 71.02, 56.24 Q 79.79, 50.61, 88.68, 45.18 Q 97.58, 39.76, 106.54, 34.42 Q 115.26, 28.73,\
                        124.04, 23.12 Q 132.76, 17.42, 141.33, 11.48 Q 151.22, 7.61, 160.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-863147732" style="position: absolute; left: 250px; top: 532px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="863147732" data-review-reference-id="863147732">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105">\
                     <svg:g width="160" height="105"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.14, 4.13, 24.29, 3.23 Q 35.43, 2.79, 46.57, 2.38 Q\
                        57.71, 2.39, 68.86, 2.22 Q 80.00, 1.86, 91.14, 1.80 Q 102.29, 1.51, 113.43, 1.21 Q 124.57, 1.18, 135.71, 1.22 Q 146.86, 1.04,\
                        158.41, 1.59 Q 158.72, 11.86, 158.21, 22.17 Q 158.34, 32.28, 158.08, 42.40 Q 157.91, 52.50, 158.08, 62.60 Q 158.71, 72.70,\
                        158.54, 82.80 Q 158.89, 92.90, 158.30, 103.30 Q 146.88, 103.07, 135.79, 103.51 Q 124.57, 102.97, 113.43, 103.15 Q 102.29,\
                        103.29, 91.15, 103.76 Q 80.00, 103.54, 68.86, 102.59 Q 57.71, 103.17, 46.57, 102.98 Q 35.43, 103.05, 24.29, 102.21 Q 13.14,\
                        102.05, 2.29, 102.71 Q 2.26, 92.81, 2.22, 82.77 Q 1.07, 72.76, 1.22, 62.63 Q 2.35, 52.49, 2.26, 42.40 Q 2.61, 32.30, 1.49,\
                        22.20 Q 2.00, 12.10, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 10.95, 7.17, 19.68, 12.69 Q 28.39, 18.23, 37.16, 23.68 Q 45.99,\
                        29.04, 54.66, 34.65 Q 63.38, 40.18, 72.10, 45.71 Q 80.67, 51.46, 89.52, 56.79 Q 98.10, 62.54, 106.82, 68.06 Q 115.57, 73.56,\
                        124.32, 79.04 Q 132.88, 84.80, 141.51, 90.47 Q 149.33, 97.39, 158.00, 103.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 103.00 Q 10.57, 97.07, 19.26, 91.32 Q 28.18, 85.93, 36.91, 80.24 Q 45.57,\
                        74.44, 54.75, 69.47 Q 63.40, 63.65, 72.20, 58.08 Q 80.24, 51.31, 89.33, 46.19 Q 98.28, 40.85, 107.40, 35.76 Q 116.14, 30.10,\
                        125.15, 24.86 Q 134.08, 19.47, 142.69, 13.60 Q 151.22, 7.61, 160.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1216323317" style="position: absolute; left: 470px; top: 532px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1216323317" data-review-reference-id="1216323317">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105">\
                     <svg:g width="160" height="105"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.14, 1.57, 24.29, 1.38 Q 35.43, 1.29, 46.57, 1.12 Q\
                        57.71, 1.62, 68.86, 1.52 Q 80.00, 1.65, 91.14, 1.09 Q 102.29, 1.00, 113.43, 1.69 Q 124.57, 1.56, 135.71, 1.69 Q 146.86, 2.03,\
                        157.92, 2.08 Q 157.83, 12.16, 158.59, 22.12 Q 158.69, 32.25, 158.88, 42.37 Q 158.09, 52.50, 158.11, 62.60 Q 158.04, 72.70,\
                        157.90, 82.80 Q 157.99, 92.90, 157.83, 102.83 Q 146.78, 102.77, 135.61, 102.29 Q 124.55, 102.66, 113.40, 102.14 Q 102.27,\
                        101.93, 91.14, 102.39 Q 80.00, 102.85, 68.86, 103.83 Q 57.71, 103.01, 46.57, 102.76 Q 35.43, 103.14, 24.29, 103.42 Q 13.14,\
                        103.08, 2.13, 102.87 Q 2.14, 92.85, 1.36, 82.89 Q 1.04, 72.76, 1.11, 62.63 Q 1.27, 52.51, 1.62, 42.40 Q 1.15, 32.30, 1.50,\
                        22.20 Q 2.00, 12.10, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 10.78, 7.44, 19.20, 13.43 Q 27.80, 19.15, 36.50, 24.70 Q 45.67,\
                        29.53, 53.98, 35.71 Q 62.85, 40.99, 71.34, 46.88 Q 80.14, 52.29, 89.35, 57.06 Q 98.08, 62.56, 106.38, 68.75 Q 114.82, 74.71,\
                        124.00, 79.52 Q 132.64, 85.18, 141.24, 90.89 Q 149.33, 97.39, 158.00, 103.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 103.00 Q 9.41, 95.25, 18.58, 90.26 Q 27.45, 84.78, 36.51, 79.61 Q 45.13,\
                        73.75, 54.03, 68.33 Q 63.05, 63.11, 71.96, 57.70 Q 80.51, 51.74, 89.11, 45.85 Q 97.91, 40.26, 106.62, 34.55 Q 115.77, 29.52,\
                        124.51, 23.86 Q 133.49, 18.56, 141.98, 12.50 Q 151.22, 7.61, 160.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1017474405" style="position: absolute; left: 690px; top: 532px; width: 160px; height: 105px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1017474405" data-review-reference-id="1017474405">\
            <div class="stencil-wrapper" style="width: 160px; height: 105px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 105px;width:160px;" width="160" height="105">\
                     <svg:g width="160" height="105"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.14, -0.59, 24.29, -0.30 Q 35.43, -0.21, 46.57, 0.23\
                        Q 57.71, 0.24, 68.86, 0.29 Q 80.00, 0.48, 91.14, 1.35 Q 102.29, 1.19, 113.43, 1.16 Q 124.57, 1.04, 135.71, 0.95 Q 146.86,\
                        0.75, 158.55, 1.45 Q 158.95, 11.78, 158.00, 22.20 Q 158.34, 32.28, 158.65, 42.38 Q 158.82, 52.49, 158.90, 62.59 Q 158.92,\
                        72.70, 159.01, 82.80 Q 159.38, 92.90, 158.20, 103.20 Q 147.15, 103.88, 135.87, 104.08 Q 124.61, 103.60, 113.46, 103.94 Q 102.30,\
                        103.74, 91.15, 104.07 Q 80.00, 103.63, 68.86, 102.18 Q 57.71, 103.46, 46.57, 102.55 Q 35.43, 103.58, 24.29, 103.11 Q 13.14,\
                        103.12, 1.76, 103.24 Q 1.75, 92.98, 1.85, 82.82 Q 1.17, 72.76, 1.94, 62.60 Q 1.06, 52.51, 1.19, 42.41 Q 1.36, 32.30, 0.97,\
                        22.20 Q 2.00, 12.10, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.51, 6.31, 20.23, 11.84 Q 29.00, 17.28, 37.28, 23.50 Q 46.23,\
                        28.68, 54.94, 34.22 Q 63.35, 40.22, 71.79, 46.19 Q 81.32, 50.47, 89.55, 56.74 Q 98.25, 62.30, 106.99, 67.80 Q 115.50, 73.65,\
                        123.79, 79.85 Q 131.90, 86.32, 140.74, 91.66 Q 149.33, 97.39, 158.00, 103.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 103.00 Q 10.54, 97.02, 19.30, 91.38 Q 28.30, 86.11, 37.20, 80.70 Q 45.64,\
                        74.56, 54.84, 69.61 Q 63.54, 63.86, 72.63, 58.75 Q 80.67, 51.98, 89.50, 46.46 Q 99.30, 42.44, 107.59, 36.07 Q 116.95, 31.37,\
                        125.58, 25.53 Q 134.24, 19.73, 143.31, 14.57 Q 151.22, 7.61, 160.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-2120475796-layer-1789137582" style="position: absolute; left: 175px; top: 15px; width: 95px; height: 80px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="1789137582" data-review-reference-id="1789137582">\
            <div class="stencil-wrapper" style="width: 95px; height: 80px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 80px;width:95px;" width="95" height="80">\
                     <svg:g width="95" height="80"><svg:path id="id" class=" svg_unselected_element" d="M 2.00, 2.00 Q 13.38, 2.09, 24.75, 1.47 Q 36.12, 1.24, 47.50, 1.46 Q\
                        58.88, 2.45, 70.25, 1.90 Q 81.62, 1.14, 93.16, 1.84 Q 92.93, 14.69, 92.83, 27.36 Q 92.98, 40.00, 93.17, 52.66 Q 93.93, 65.32,\
                        93.36, 78.36 Q 81.76, 78.40, 70.27, 78.16 Q 58.86, 77.79, 47.47, 77.08 Q 36.11, 77.33, 24.75, 77.61 Q 13.37, 77.67, 1.98,\
                        78.02 Q 1.89, 65.37, 1.71, 52.71 Q 1.14, 40.06, 1.12, 27.36 Q 2.00, 14.67, 2.00, 2.00" style="fill:white;stroke-width:1.5;"/><svg:path class=" svg_unselected_element" d="M 2.00, 2.00 Q 11.58, 9.02, 20.79, 16.49 Q 29.73, 24.29, 39.06, 31.61 Q 48.08,\
                        39.30, 56.89, 47.25 Q 66.22, 54.57, 75.42, 62.06 Q 83.90, 70.40, 93.00, 78.00" style=" fill:none;"/><svg:path class=" svg_unselected_element" d="M 2.00, 78.00 Q 9.24, 71.05, 17.60, 65.46 Q 25.34, 59.11, 33.66, 53.48 Q 40.43,\
                        45.94, 48.39, 39.86 Q 56.49, 33.96, 64.76, 28.26 Q 71.91, 21.20, 79.52, 14.69 Q 87.25, 8.33, 95.00, 2.00" style=" fill:none;"/>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="2120475796"] .border-wrapper, body[data-current-page-id="2120475796"] .simulation-container{\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="2120475796"] .border-wrapper, body.has-frame[data-current-page-id="2120475796"] .simulation-container{\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="2120475796"] .svg-border-1366-768{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="2120475796"] .border-wrapper .border-div{\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "2120475796",\
      			"name": "search results",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
   <div id="border-wrapper">\
      <div xmlns="http://www.w3.org/1999/xhtml" xmlns:json="http://json.org/" class="svg-border svg-border-1366-768" style="display: none;">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="svg_border" style="position:absolute;left:-43px;top:-13px;width:1423px;height:792px;"><svg:path class=" svg_unselected_element" d="M 32.00, 3.00 Q 42.12, 2.19, 52.24, 2.80 Q 62.35, 2.89, 72.47, 2.94 Q 82.59,\
            0.87, 92.71, 2.60 Q 102.82, 3.07, 112.94, 2.61 Q 123.06, 1.32, 133.18, 0.96 Q 143.29, 2.54, 153.41, 3.23 Q 163.53, 3.56, 173.65,\
            3.23 Q 183.76, 3.13, 193.88, 2.61 Q 204.00, 2.20, 214.12, 1.94 Q 224.24, 1.77, 234.35, 1.56 Q 244.47, 1.76, 254.59, 3.14 Q\
            264.71, 3.66, 274.82, 2.60 Q 284.94, 2.47, 295.06, 2.44 Q 305.18, 2.42, 315.29, 1.47 Q 325.41, 1.24, 335.53, 1.08 Q 345.65,\
            1.06, 355.76, 1.02 Q 365.88, 1.95, 376.00, 2.48 Q 386.12, 2.88, 396.24, 3.06 Q 406.35, 3.10, 416.47, 3.12 Q 426.59, 2.65,\
            436.71, 1.82 Q 446.82, 1.57, 456.94, 1.75 Q 467.06, 2.27, 477.18, 2.77 Q 487.29, 2.95, 497.41, 2.52 Q 507.53, 1.19, 517.65,\
            1.00 Q 527.76, 1.05, 537.88, 1.54 Q 548.00, 1.85, 558.12, 1.74 Q 568.24, 2.17, 578.35, 2.73 Q 588.47, 2.05, 598.59, 1.70 Q\
            608.71, 1.74, 618.82, 0.99 Q 628.94, 1.31, 639.06, 1.19 Q 649.18, 1.28, 659.29, 1.36 Q 669.41, 1.57, 679.53, 1.10 Q 689.65,\
            1.60, 699.77, 1.64 Q 709.88, 1.58, 720.00, 1.72 Q 730.12, 2.12, 740.24, 2.16 Q 750.35, 2.39, 760.47, 2.64 Q 770.59, 2.42,\
            780.71, 2.34 Q 790.82, 2.63, 800.94, 2.79 Q 811.06, 2.04, 821.18, 2.42 Q 831.29, 1.39, 841.41, 1.30 Q 851.53, 1.56, 861.65,\
            1.64 Q 871.77, 1.79, 881.88, 2.44 Q 892.00, 2.53, 902.12, 1.61 Q 912.24, 1.88, 922.35, 1.62 Q 932.47, 0.96, 942.59, 1.15 Q\
            952.71, 0.74, 962.82, 1.71 Q 972.94, 1.65, 983.06, 0.85 Q 993.18, 0.83, 1003.30, 1.17 Q 1013.41, 0.86, 1023.53, 0.93 Q 1033.65,\
            1.70, 1043.77, 2.06 Q 1053.88, 2.44, 1064.00, 2.35 Q 1074.12, 1.91, 1084.24, 2.35 Q 1094.35, 3.15, 1104.47, 3.30 Q 1114.59,\
            3.95, 1124.71, 4.10 Q 1134.83, 3.88, 1144.94, 2.52 Q 1155.06, 1.98, 1165.18, 2.32 Q 1175.30, 2.78, 1185.41, 2.81 Q 1195.53,\
            1.40, 1205.65, 1.31 Q 1215.77, 1.54, 1225.88, 1.78 Q 1236.00, 1.46, 1246.12, 1.94 Q 1256.24, 2.39, 1266.35, 1.95 Q 1276.47,\
            2.40, 1286.59, 1.92 Q 1296.71, 2.30, 1306.83, 2.04 Q 1316.94, 1.73, 1327.06, 1.46 Q 1337.18, 2.08, 1347.30, 2.55 Q 1357.41,\
            2.15, 1367.53, 2.50 Q 1377.65, 2.07, 1387.77, 2.26 Q 1397.88, 2.54, 1408.28, 2.72 Q 1408.53, 13.00, 1408.44, 23.28 Q 1408.32,\
            33.49, 1408.79, 43.66 Q 1408.04, 53.85, 1407.88, 64.03 Q 1408.41, 74.20, 1407.72, 84.37 Q 1407.82, 94.54, 1408.36, 104.71\
            Q 1408.45, 114.88, 1408.48, 125.05 Q 1408.77, 135.22, 1408.16, 145.39 Q 1408.45, 155.57, 1407.24, 165.74 Q 1408.44, 175.91,\
            1408.82, 186.08 Q 1408.72, 196.25, 1408.23, 206.42 Q 1408.77, 216.59, 1409.45, 226.76 Q 1409.76, 236.93, 1409.08, 247.11 Q\
            1409.69, 257.28, 1409.00, 267.45 Q 1409.44, 277.62, 1408.96, 287.79 Q 1408.80, 297.96, 1409.06, 308.13 Q 1408.30, 318.30,\
            1407.55, 328.47 Q 1408.00, 338.64, 1407.20, 348.82 Q 1409.10, 358.99, 1409.19, 369.16 Q 1408.60, 379.33, 1408.70, 389.50 Q\
            1408.79, 399.67, 1409.12, 409.84 Q 1408.86, 420.01, 1410.06, 430.18 Q 1409.65, 440.36, 1409.34, 450.53 Q 1409.41, 460.70,\
            1409.95, 470.87 Q 1408.94, 481.04, 1408.72, 491.21 Q 1409.20, 501.38, 1408.82, 511.55 Q 1409.63, 521.72, 1409.40, 531.89 Q\
            1409.62, 542.07, 1408.89, 552.24 Q 1409.12, 562.41, 1409.28, 572.58 Q 1409.63, 582.75, 1409.91, 592.92 Q 1409.45, 603.09,\
            1409.85, 613.26 Q 1409.24, 623.43, 1408.69, 633.61 Q 1408.56, 643.78, 1408.56, 653.95 Q 1408.76, 664.12, 1408.40, 674.29 Q\
            1408.51, 684.46, 1408.61, 694.63 Q 1408.58, 704.80, 1408.77, 714.97 Q 1409.06, 725.15, 1408.89, 735.32 Q 1408.12, 745.49,\
            1408.51, 755.66 Q 1408.73, 765.83, 1408.08, 776.08 Q 1397.89, 776.02, 1387.69, 775.48 Q 1377.67, 776.35, 1367.52, 775.69 Q\
            1357.41, 775.70, 1347.29, 775.32 Q 1337.18, 775.83, 1327.06, 776.46 Q 1316.94, 776.83, 1306.83, 776.43 Q 1296.71, 776.64,\
            1286.59, 776.25 Q 1276.47, 775.55, 1266.35, 775.61 Q 1256.24, 774.82, 1246.12, 775.36 Q 1236.00, 776.94, 1225.88, 777.36 Q\
            1215.77, 777.43, 1205.65, 777.51 Q 1195.53, 777.24, 1185.41, 777.24 Q 1175.30, 777.04, 1165.18, 776.67 Q 1155.06, 776.27,\
            1144.94, 776.88 Q 1134.83, 776.65, 1124.71, 776.27 Q 1114.59, 775.68, 1104.47, 775.73 Q 1094.35, 776.84, 1084.24, 776.25 Q\
            1074.12, 775.60, 1064.00, 775.14 Q 1053.88, 775.70, 1043.77, 776.14 Q 1033.65, 775.57, 1023.53, 775.96 Q 1013.41, 775.73,\
            1003.30, 776.03 Q 993.18, 776.18, 983.06, 776.30 Q 972.94, 776.08, 962.82, 776.58 Q 952.71, 776.29, 942.59, 776.72 Q 932.47,\
            776.58, 922.35, 776.67 Q 912.24, 777.50, 902.12, 776.98 Q 892.00, 776.48, 881.88, 776.75 Q 871.77, 777.37, 861.65, 777.51\
            Q 851.53, 777.42, 841.41, 776.97 Q 831.29, 777.13, 821.18, 776.67 Q 811.06, 776.57, 800.94, 776.59 Q 790.82, 776.21, 780.71,\
            776.59 Q 770.59, 776.54, 760.47, 776.27 Q 750.35, 775.86, 740.24, 776.57 Q 730.12, 777.18, 720.00, 777.13 Q 709.88, 776.89,\
            699.77, 775.76 Q 689.65, 775.30, 679.53, 775.44 Q 669.41, 776.46, 659.29, 776.37 Q 649.18, 775.87, 639.06, 775.41 Q 628.94,\
            775.61, 618.82, 775.35 Q 608.71, 775.51, 598.59, 775.46 Q 588.47, 776.12, 578.35, 776.22 Q 568.24, 775.94, 558.12, 776.38\
            Q 548.00, 776.93, 537.88, 776.94 Q 527.76, 775.81, 517.65, 776.01 Q 507.53, 776.82, 497.41, 777.16 Q 487.29, 776.01, 477.18,\
            775.18 Q 467.06, 776.09, 456.94, 776.43 Q 446.82, 776.37, 436.71, 776.55 Q 426.59, 776.77, 416.47, 776.94 Q 406.35, 777.03,\
            396.24, 776.72 Q 386.12, 776.82, 376.00, 776.85 Q 365.88, 776.61, 355.76, 776.98 Q 345.65, 777.75, 335.53, 777.42 Q 325.41,\
            776.97, 315.29, 776.12 Q 305.18, 777.14, 295.06, 777.29 Q 284.94, 776.93, 274.82, 776.90 Q 264.71, 776.76, 254.59, 777.67\
            Q 244.47, 776.86, 234.35, 776.45 Q 224.24, 776.81, 214.12, 777.06 Q 204.00, 776.77, 193.88, 777.70 Q 183.76, 777.72, 173.65,\
            776.42 Q 163.53, 775.04, 153.41, 775.19 Q 143.29, 776.43, 133.18, 775.98 Q 123.06, 775.17, 112.94, 774.85 Q 102.82, 776.81,\
            92.71, 777.47 Q 82.59, 776.77, 72.47, 777.36 Q 62.35, 776.79, 52.24, 776.71 Q 42.12, 777.07, 31.50, 776.50 Q 31.60, 765.96,\
            31.60, 755.72 Q 30.70, 745.57, 31.13, 735.34 Q 31.71, 725.15, 31.53, 714.98 Q 30.15, 704.81, 29.28, 694.64 Q 29.78, 684.46,\
            30.81, 674.29 Q 30.97, 664.12, 30.66, 653.95 Q 31.78, 643.78, 30.49, 633.61 Q 29.70, 623.43, 29.69, 613.26 Q 30.19, 603.09,\
            31.52, 592.92 Q 31.91, 582.75, 31.66, 572.58 Q 31.13, 562.41, 30.96, 552.24 Q 31.46, 542.07, 31.38, 531.89 Q 30.50, 521.72,\
            30.26, 511.55 Q 31.80, 501.38, 30.90, 491.21 Q 30.90, 481.04, 30.46, 470.87 Q 30.92, 460.70, 31.37, 450.53 Q 31.43, 440.36,\
            31.04, 430.18 Q 30.38, 420.01, 30.37, 409.84 Q 30.19, 399.67, 29.91, 389.50 Q 30.18, 379.33, 30.36, 369.16 Q 30.32, 358.99,\
            30.82, 348.82 Q 29.86, 338.64, 29.98, 328.47 Q 30.33, 318.30, 30.33, 308.13 Q 30.47, 297.96, 30.82, 287.79 Q 31.53, 277.62,\
            31.20, 267.45 Q 31.26, 257.28, 31.17, 247.11 Q 30.88, 236.93, 30.68, 226.76 Q 31.27, 216.59, 31.41, 206.42 Q 31.43, 196.25,\
            31.76, 186.08 Q 31.62, 175.91, 31.43, 165.74 Q 31.53, 155.57, 30.98, 145.39 Q 31.12, 135.22, 30.84, 125.05 Q 30.64, 114.88,\
            30.67, 104.71 Q 31.09, 94.54, 31.10, 84.37 Q 31.94, 74.20, 32.23, 64.03 Q 32.12, 53.86, 31.27, 43.68 Q 30.91, 33.51, 30.84,\
            23.34 Q 32.00, 13.17, 32.00, 3.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 23.00, 7.00 Q 33.12, 5.45, 43.24, 5.42 Q 53.35, 5.29, 63.47, 5.16 Q 73.59,\
            5.37, 83.71, 5.84 Q 93.82, 5.87, 103.94, 5.97 Q 114.06, 5.16, 124.18, 5.49 Q 134.29, 5.77, 144.41, 6.01 Q 154.53, 5.17, 164.65,\
            6.14 Q 174.76, 5.86, 184.88, 6.40 Q 195.00, 5.99, 205.12, 5.18 Q 215.24, 6.43, 225.35, 5.85 Q 235.47, 6.53, 245.59, 6.53 Q\
            255.71, 6.79, 265.82, 6.77 Q 275.94, 6.11, 286.06, 5.29 Q 296.18, 5.41, 306.29, 6.64 Q 316.41, 6.55, 326.53, 6.32 Q 336.65,\
            7.33, 346.76, 7.45 Q 356.88, 7.33, 367.00, 6.82 Q 377.12, 5.61, 387.24, 5.32 Q 397.35, 6.87, 407.47, 7.36 Q 417.59, 6.60,\
            427.71, 5.72 Q 437.82, 6.41, 447.94, 6.35 Q 458.06, 5.95, 468.18, 5.51 Q 478.29, 5.54, 488.41, 5.72 Q 498.53, 5.88, 508.65,\
            5.74 Q 518.76, 5.61, 528.88, 5.52 Q 539.00, 5.53, 549.12, 4.92 Q 559.24, 4.89, 569.35, 4.68 Q 579.47, 5.10, 589.59, 5.56 Q\
            599.71, 5.64, 609.82, 5.22 Q 619.94, 5.32, 630.06, 5.21 Q 640.18, 5.59, 650.29, 5.77 Q 660.41, 6.03, 670.53, 5.87 Q 680.65,\
            6.25, 690.77, 6.41 Q 700.88, 6.35, 711.00, 6.25 Q 721.12, 6.11, 731.24, 5.60 Q 741.35, 5.43, 751.47, 5.00 Q 761.59, 5.43,\
            771.71, 5.65 Q 781.82, 6.12, 791.94, 6.48 Q 802.06, 5.40, 812.18, 5.96 Q 822.29, 5.64, 832.41, 5.73 Q 842.53, 6.70, 852.65,\
            7.31 Q 862.77, 7.12, 872.88, 7.15 Q 883.00, 6.98, 893.12, 6.40 Q 903.24, 6.58, 913.35, 6.14 Q 923.47, 6.54, 933.59, 6.54 Q\
            943.71, 6.84, 953.82, 6.76 Q 963.94, 6.25, 974.06, 6.44 Q 984.18, 6.39, 994.30, 6.20 Q 1004.41, 6.23, 1014.53, 6.02 Q 1024.65,\
            5.96, 1034.77, 5.82 Q 1044.88, 6.48, 1055.00, 6.10 Q 1065.12, 6.07, 1075.24, 5.45 Q 1085.35, 5.83, 1095.47, 5.26 Q 1105.59,\
            5.58, 1115.71, 4.72 Q 1125.83, 5.83, 1135.94, 5.56 Q 1146.06, 5.64, 1156.18, 5.50 Q 1166.30, 5.26, 1176.41, 6.10 Q 1186.53,\
            5.48, 1196.65, 5.80 Q 1206.77, 5.65, 1216.88, 6.27 Q 1227.00, 5.86, 1237.12, 5.79 Q 1247.24, 5.96, 1257.35, 5.67 Q 1267.47,\
            5.83, 1277.59, 5.86 Q 1287.71, 7.14, 1297.83, 6.36 Q 1307.94, 5.78, 1318.06, 5.73 Q 1328.18, 6.06, 1338.30, 6.30 Q 1348.41,\
            6.08, 1358.53, 6.51 Q 1368.65, 6.09, 1378.77, 7.05 Q 1388.88, 6.76, 1399.20, 6.80 Q 1399.57, 16.98, 1399.15, 27.32 Q 1399.34,\
            37.49, 1400.29, 47.64 Q 1399.56, 57.85, 1400.33, 68.02 Q 1399.94, 78.19, 1400.33, 88.37 Q 1401.01, 98.54, 1399.68, 108.71\
            Q 1400.07, 118.88, 1399.92, 129.05 Q 1400.36, 139.22, 1399.53, 149.39 Q 1399.44, 159.57, 1398.63, 169.74 Q 1399.30, 179.91,\
            1399.61, 190.08 Q 1399.20, 200.25, 1398.98, 210.42 Q 1399.35, 220.59, 1399.99, 230.76 Q 1400.00, 240.93, 1400.13, 251.11 Q\
            1399.27, 261.28, 1398.58, 271.45 Q 1399.71, 281.62, 1399.18, 291.79 Q 1399.30, 301.96, 1399.80, 312.13 Q 1400.27, 322.30,\
            1399.46, 332.47 Q 1399.30, 342.64, 1399.52, 352.82 Q 1400.20, 362.99, 1399.41, 373.16 Q 1398.90, 383.33, 1399.38, 393.50 Q\
            1400.61, 403.67, 1400.20, 413.84 Q 1400.37, 424.01, 1399.65, 434.18 Q 1400.49, 444.36, 1399.92, 454.53 Q 1399.90, 464.70,\
            1399.47, 474.87 Q 1399.56, 485.04, 1399.43, 495.21 Q 1399.46, 505.38, 1399.95, 515.55 Q 1399.07, 525.72, 1399.84, 535.89 Q\
            1399.55, 546.07, 1400.15, 556.24 Q 1400.20, 566.41, 1399.59, 576.58 Q 1400.11, 586.75, 1399.70, 596.92 Q 1400.25, 607.09,\
            1400.25, 617.26 Q 1400.41, 627.43, 1400.45, 637.61 Q 1400.60, 647.78, 1400.31, 657.95 Q 1400.35, 668.12, 1399.30, 678.29 Q\
            1399.76, 688.46, 1399.58, 698.63 Q 1398.52, 708.80, 1399.32, 718.97 Q 1400.37, 729.15, 1400.71, 739.32 Q 1399.86, 749.49,\
            1399.85, 759.66 Q 1400.39, 769.83, 1399.83, 780.83 Q 1389.22, 781.00, 1378.92, 781.05 Q 1368.74, 781.36, 1358.61, 782.39 Q\
            1348.45, 781.97, 1338.30, 780.52 Q 1328.18, 781.49, 1318.06, 781.25 Q 1307.94, 780.53, 1297.83, 780.57 Q 1287.71, 779.43,\
            1277.59, 780.64 Q 1267.47, 781.08, 1257.35, 781.47 Q 1247.24, 780.43, 1237.12, 780.27 Q 1227.00, 780.39, 1216.88, 780.77 Q\
            1206.77, 780.32, 1196.65, 780.22 Q 1186.53, 780.21, 1176.41, 780.54 Q 1166.30, 779.84, 1156.18, 779.91 Q 1146.06, 779.78,\
            1135.94, 780.39 Q 1125.83, 780.33, 1115.71, 780.02 Q 1105.59, 780.08, 1095.47, 779.99 Q 1085.35, 780.62, 1075.24, 781.45 Q\
            1065.12, 781.69, 1055.00, 781.74 Q 1044.88, 781.68, 1034.77, 781.75 Q 1024.65, 781.33, 1014.53, 780.07 Q 1004.41, 780.60,\
            994.30, 780.97 Q 984.18, 781.01, 974.06, 781.20 Q 963.94, 781.00, 953.82, 781.13 Q 943.71, 781.04, 933.59, 781.29 Q 923.47,\
            780.59, 913.35, 780.98 Q 903.24, 781.29, 893.12, 781.36 Q 883.00, 779.83, 872.88, 779.81 Q 862.77, 780.10, 852.65, 780.97\
            Q 842.53, 780.33, 832.41, 779.66 Q 822.29, 780.06, 812.18, 780.26 Q 802.06, 780.44, 791.94, 779.81 Q 781.82, 779.60, 771.71,\
            780.21 Q 761.59, 780.38, 751.47, 779.89 Q 741.35, 779.55, 731.24, 780.23 Q 721.12, 780.46, 711.00, 781.65 Q 700.88, 779.91,\
            690.77, 780.30 Q 680.65, 780.66, 670.53, 781.28 Q 660.41, 781.26, 650.29, 780.34 Q 640.18, 780.34, 630.06, 780.43 Q 619.94,\
            781.31, 609.82, 781.40 Q 599.71, 780.92, 589.59, 780.24 Q 579.47, 780.62, 569.35, 781.52 Q 559.24, 780.49, 549.12, 781.15\
            Q 539.00, 780.91, 528.88, 781.04 Q 518.76, 779.70, 508.65, 780.28 Q 498.53, 780.89, 488.41, 780.27 Q 478.29, 779.99, 468.18,\
            779.70 Q 458.06, 779.75, 447.94, 780.23 Q 437.82, 780.64, 427.71, 780.00 Q 417.59, 780.01, 407.47, 780.04 Q 397.35, 780.60,\
            387.24, 780.80 Q 377.12, 780.77, 367.00, 781.07 Q 356.88, 781.60, 346.76, 781.68 Q 336.65, 781.05, 326.53, 780.83 Q 316.41,\
            780.96, 306.29, 781.02 Q 296.18, 781.14, 286.06, 780.32 Q 275.94, 779.87, 265.82, 779.69 Q 255.71, 780.67, 245.59, 781.42\
            Q 235.47, 780.63, 225.35, 780.68 Q 215.24, 781.76, 205.12, 780.84 Q 195.00, 781.35, 184.88, 781.45 Q 174.76, 781.62, 164.65,\
            781.59 Q 154.53, 781.09, 144.41, 780.28 Q 134.29, 780.78, 124.18, 780.28 Q 114.06, 781.12, 103.94, 780.70 Q 93.82, 780.78,\
            83.71, 781.24 Q 73.59, 781.40, 63.47, 780.75 Q 53.35, 780.77, 43.24, 780.41 Q 33.12, 782.07, 22.45, 780.55 Q 21.42, 770.36,\
            21.42, 759.88 Q 21.93, 749.56, 22.13, 739.34 Q 22.43, 729.15, 22.94, 718.97 Q 22.58, 708.80, 24.01, 698.63 Q 22.32, 688.46,\
            21.85, 678.29 Q 21.96, 668.12, 22.15, 657.95 Q 21.89, 647.78, 22.08, 637.61 Q 22.18, 627.43, 22.62, 617.26 Q 22.55, 607.09,\
            21.90, 596.92 Q 21.47, 586.75, 21.97, 576.58 Q 23.43, 566.41, 22.77, 556.24 Q 22.10, 546.07, 22.24, 535.89 Q 22.90, 525.72,\
            22.53, 515.55 Q 21.58, 505.38, 21.10, 495.21 Q 21.45, 485.04, 21.80, 474.87 Q 21.78, 464.70, 21.42, 454.53 Q 21.31, 444.36,\
            21.25, 434.18 Q 21.47, 424.01, 21.78, 413.84 Q 20.90, 403.67, 21.81, 393.50 Q 22.54, 383.33, 22.30, 373.16 Q 21.87, 362.99,\
            21.32, 352.82 Q 21.34, 342.64, 21.12, 332.47 Q 21.29, 322.30, 21.40, 312.13 Q 21.48, 301.96, 21.28, 291.79 Q 21.15, 281.62,\
            21.07, 271.45 Q 21.52, 261.28, 21.18, 251.11 Q 21.40, 240.93, 21.16, 230.76 Q 22.02, 220.59, 23.14, 210.42 Q 23.44, 200.25,\
            22.30, 190.08 Q 21.92, 179.91, 21.42, 169.74 Q 21.94, 159.57, 22.33, 149.39 Q 22.17, 139.22, 22.09, 129.05 Q 22.90, 118.88,\
            22.44, 108.71 Q 22.56, 98.54, 21.62, 88.37 Q 21.89, 78.20, 21.89, 68.03 Q 21.71, 57.86, 22.27, 47.68 Q 21.61, 37.51, 22.05,\
            27.34 Q 23.00, 17.17, 23.00, 7.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 40.00, 11.00 Q 50.12, 9.94, 60.24, 10.43 Q 70.35, 10.66, 80.47, 10.54 Q 90.59,\
            10.51, 100.71, 10.59 Q 110.82, 10.19, 120.94, 10.51 Q 131.06, 10.45, 141.18, 10.52 Q 151.29, 10.41, 161.41, 10.27 Q 171.53,\
            9.94, 181.65, 9.74 Q 191.76, 9.58, 201.88, 10.26 Q 212.00, 10.14, 222.12, 10.65 Q 232.24, 10.48, 242.35, 10.49 Q 252.47, 10.98,\
            262.59, 10.47 Q 272.71, 10.44, 282.82, 10.14 Q 292.94, 9.61, 303.06, 9.96 Q 313.18, 9.94, 323.29, 10.00 Q 333.41, 9.80, 343.53,\
            9.89 Q 353.65, 9.86, 363.76, 10.15 Q 373.88, 9.89, 384.00, 9.86 Q 394.12, 10.51, 404.24, 11.37 Q 414.35, 11.41, 424.47, 11.17\
            Q 434.59, 11.12, 444.71, 10.96 Q 454.82, 11.11, 464.94, 11.50 Q 475.06, 10.92, 485.18, 10.39 Q 495.29, 11.26, 505.41, 10.60\
            Q 515.53, 9.72, 525.65, 9.77 Q 535.76, 9.57, 545.88, 9.31 Q 556.00, 9.28, 566.12, 10.37 Q 576.24, 9.81, 586.35, 10.62 Q 596.47,\
            10.20, 606.59, 10.95 Q 616.71, 10.42, 626.82, 10.03 Q 636.94, 10.02, 647.06, 10.83 Q 657.18, 10.75, 667.29, 9.91 Q 677.41,\
            10.05, 687.53, 9.49 Q 697.65, 10.01, 707.77, 9.27 Q 717.88, 9.33, 728.00, 10.16 Q 738.12, 10.40, 748.24, 10.69 Q 758.35, 10.68,\
            768.47, 11.08 Q 778.59, 10.44, 788.71, 10.63 Q 798.82, 10.27, 808.94, 10.77 Q 819.06, 10.76, 829.18, 11.03 Q 839.29, 10.75,\
            849.41, 10.40 Q 859.53, 10.94, 869.65, 10.00 Q 879.77, 11.45, 889.88, 11.03 Q 900.00, 10.88, 910.12, 10.97 Q 920.24, 10.52,\
            930.35, 10.92 Q 940.47, 11.04, 950.59, 11.61 Q 960.71, 11.38, 970.82, 10.53 Q 980.94, 10.03, 991.06, 9.29 Q 1001.18, 9.69,\
            1011.30, 9.43 Q 1021.41, 9.18, 1031.53, 9.47 Q 1041.65, 9.33, 1051.77, 9.15 Q 1061.88, 9.00, 1072.00, 8.90 Q 1082.12, 10.05,\
            1092.24, 10.71 Q 1102.35, 10.19, 1112.47, 9.99 Q 1122.59, 10.06, 1132.71, 11.24 Q 1142.83, 11.03, 1152.94, 11.12 Q 1163.06,\
            11.06, 1173.18, 12.28 Q 1183.30, 12.42, 1193.41, 10.97 Q 1203.53, 10.28, 1213.65, 10.36 Q 1223.77, 10.41, 1233.88, 10.46 Q\
            1244.00, 12.00, 1254.12, 12.09 Q 1264.24, 12.21, 1274.35, 11.63 Q 1284.47, 10.78, 1294.59, 10.52 Q 1304.71, 10.50, 1314.83,\
            10.59 Q 1324.94, 10.46, 1335.06, 10.28 Q 1345.18, 9.50, 1355.30, 10.91 Q 1365.41, 10.34, 1375.53, 9.71 Q 1385.65, 9.31, 1395.77,\
            9.38 Q 1405.88, 9.53, 1416.46, 10.54 Q 1416.60, 20.97, 1416.58, 31.26 Q 1416.40, 41.49, 1415.86, 51.69 Q 1416.33, 61.85, 1416.36,\
            72.02 Q 1416.25, 82.20, 1416.54, 92.37 Q 1417.18, 102.54, 1417.70, 112.71 Q 1416.98, 122.88, 1416.74, 133.05 Q 1416.76, 143.22,\
            1417.11, 153.39 Q 1417.30, 163.57, 1416.53, 173.74 Q 1416.19, 183.91, 1416.54, 194.08 Q 1415.99, 204.25, 1415.35, 214.42 Q\
            1415.55, 224.59, 1415.46, 234.76 Q 1416.34, 244.93, 1416.88, 255.11 Q 1416.48, 265.28, 1416.22, 275.45 Q 1416.81, 285.62,\
            1417.64, 295.79 Q 1416.78, 305.96, 1415.54, 316.13 Q 1415.55, 326.30, 1416.65, 336.47 Q 1417.09, 346.64, 1416.44, 356.82 Q\
            1416.21, 366.99, 1416.57, 377.16 Q 1417.08, 387.33, 1417.02, 397.50 Q 1416.84, 407.67, 1416.55, 417.84 Q 1416.71, 428.01,\
            1417.00, 438.18 Q 1416.72, 448.36, 1416.17, 458.53 Q 1415.76, 468.70, 1415.97, 478.87 Q 1416.35, 489.04, 1416.26, 499.21 Q\
            1415.70, 509.38, 1416.06, 519.55 Q 1417.18, 529.72, 1417.54, 539.89 Q 1417.56, 550.07, 1417.32, 560.24 Q 1417.86, 570.41,\
            1418.02, 580.58 Q 1418.22, 590.75, 1418.33, 600.92 Q 1417.71, 611.09, 1417.17, 621.26 Q 1417.34, 631.43, 1417.47, 641.61 Q\
            1417.60, 651.78, 1417.46, 661.95 Q 1417.35, 672.12, 1418.03, 682.29 Q 1417.16, 692.46, 1418.23, 702.63 Q 1417.78, 712.80,\
            1416.49, 722.97 Q 1415.81, 733.15, 1416.13, 743.32 Q 1416.33, 753.49, 1417.19, 763.66 Q 1417.35, 773.83, 1416.73, 784.73 Q\
            1406.26, 785.12, 1395.97, 785.41 Q 1385.68, 784.46, 1375.52, 783.77 Q 1365.42, 784.36, 1355.30, 784.46 Q 1345.18, 784.35,\
            1335.06, 783.54 Q 1324.94, 783.33, 1314.83, 783.94 Q 1304.71, 783.85, 1294.59, 782.89 Q 1284.47, 782.39, 1274.35, 783.55 Q\
            1264.24, 784.26, 1254.12, 785.27 Q 1244.00, 785.86, 1233.88, 785.93 Q 1223.77, 785.61, 1213.65, 785.65 Q 1203.53, 785.76,\
            1193.41, 785.94 Q 1183.30, 786.01, 1173.18, 786.07 Q 1163.06, 785.67, 1152.94, 784.17 Q 1142.83, 783.70, 1132.71, 784.13 Q\
            1122.59, 783.86, 1112.47, 783.97 Q 1102.35, 783.71, 1092.24, 784.81 Q 1082.12, 784.73, 1072.00, 785.38 Q 1061.88, 784.49,\
            1051.77, 784.81 Q 1041.65, 784.87, 1031.53, 784.99 Q 1021.41, 785.35, 1011.30, 784.51 Q 1001.18, 784.71, 991.06, 784.42 Q\
            980.94, 785.25, 970.82, 784.32 Q 960.71, 785.21, 950.59, 785.83 Q 940.47, 786.27, 930.35, 784.77 Q 920.24, 784.77, 910.12,\
            785.44 Q 900.00, 784.62, 889.88, 785.24 Q 879.77, 784.87, 869.65, 785.48 Q 859.53, 785.22, 849.41, 785.00 Q 839.29, 784.84,\
            829.18, 784.80 Q 819.06, 784.96, 808.94, 784.18 Q 798.82, 784.40, 788.71, 783.80 Q 778.59, 784.34, 768.47, 784.00 Q 758.35,\
            783.96, 748.24, 784.21 Q 738.12, 784.10, 728.00, 784.02 Q 717.88, 784.06, 707.77, 784.75 Q 697.65, 784.03, 687.53, 784.47\
            Q 677.41, 784.60, 667.29, 784.75 Q 657.18, 784.93, 647.06, 785.34 Q 636.94, 785.72, 626.82, 785.95 Q 616.71, 785.74, 606.59,\
            785.40 Q 596.47, 784.82, 586.35, 784.87 Q 576.24, 785.32, 566.12, 785.12 Q 556.00, 784.65, 545.88, 785.77 Q 535.76, 785.78,\
            525.65, 785.72 Q 515.53, 785.53, 505.41, 785.68 Q 495.29, 785.43, 485.18, 784.86 Q 475.06, 784.73, 464.94, 785.47 Q 454.82,\
            786.04, 444.71, 785.69 Q 434.59, 785.55, 424.47, 784.62 Q 414.35, 784.58, 404.24, 783.46 Q 394.12, 784.08, 384.00, 784.50\
            Q 373.88, 784.52, 363.76, 784.35 Q 353.65, 784.40, 343.53, 784.88 Q 333.41, 785.11, 323.29, 784.94 Q 313.18, 785.14, 303.06,\
            784.92 Q 292.94, 785.48, 282.82, 786.04 Q 272.71, 785.87, 262.59, 785.48 Q 252.47, 785.81, 242.35, 785.46 Q 232.24, 785.36,\
            222.12, 784.86 Q 212.00, 784.53, 201.88, 784.21 Q 191.76, 783.92, 181.65, 783.81 Q 171.53, 784.44, 161.41, 784.76 Q 151.29,\
            784.86, 141.18, 784.86 Q 131.06, 784.94, 120.94, 784.43 Q 110.82, 784.68, 100.71, 784.83 Q 90.59, 784.49, 80.47, 784.53 Q\
            70.35, 784.71, 60.24, 784.74 Q 50.12, 784.86, 39.56, 784.44 Q 39.61, 773.96, 39.74, 763.70 Q 39.98, 753.49, 39.72, 743.33\
            Q 39.46, 733.15, 39.71, 722.98 Q 39.13, 712.81, 38.96, 702.63 Q 38.79, 692.46, 38.86, 682.29 Q 38.73, 672.12, 39.03, 661.95\
            Q 39.48, 651.78, 39.73, 641.61 Q 39.90, 631.43, 40.72, 621.26 Q 40.37, 611.09, 39.58, 600.92 Q 39.36, 590.75, 38.86, 580.58\
            Q 38.27, 570.41, 39.29, 560.24 Q 38.54, 550.07, 39.33, 539.89 Q 38.63, 529.72, 38.92, 519.55 Q 38.21, 509.38, 38.85, 499.21\
            Q 38.70, 489.04, 38.92, 478.87 Q 39.09, 468.70, 39.34, 458.53 Q 39.15, 448.36, 38.79, 438.18 Q 38.74, 428.01, 38.17, 417.84\
            Q 38.67, 407.67, 37.77, 397.50 Q 37.78, 387.33, 38.18, 377.16 Q 38.29, 366.99, 38.35, 356.82 Q 39.89, 346.64, 39.74, 336.47\
            Q 39.32, 326.30, 39.42, 316.13 Q 39.27, 305.96, 39.10, 295.79 Q 39.04, 285.62, 38.86, 275.45 Q 38.80, 265.28, 39.57, 255.11\
            Q 39.59, 244.93, 39.39, 234.76 Q 38.85, 224.59, 38.63, 214.42 Q 38.54, 204.25, 39.64, 194.08 Q 38.35, 183.91, 37.97, 173.74\
            Q 38.59, 163.57, 39.00, 153.39 Q 38.75, 143.22, 40.09, 133.05 Q 40.28, 122.88, 40.04, 112.71 Q 40.00, 102.54, 40.16, 92.37\
            Q 40.43, 82.20, 40.25, 72.03 Q 40.44, 61.86, 38.98, 51.68 Q 38.63, 41.51, 38.99, 31.34 Q 40.00, 21.17, 40.00, 11.00" style="\
            fill:white;"/>\
         </svg:svg>\
      </div>\
   </div>\
</div>');